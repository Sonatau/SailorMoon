(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["member-checkin-member-checkin-module"],{

/***/ "0cFA":
/*!*************************************************************************!*\
  !*** ./src/app/pages/member-list/member-checkin/member-checkin.page.ts ***!
  \*************************************************************************/
/*! exports provided: MemberCheckinPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MemberCheckinPage", function() { return MemberCheckinPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_member_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./member-checkin.page.html */ "cXwf");
/* harmony import */ var _member_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./member-checkin.page.scss */ "BUx+");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");






let MemberCheckinPage = class MemberCheckinPage {
    constructor(activatedRoute, httpService, router) {
        this.activatedRoute = activatedRoute;
        this.httpService = httpService;
        this.router = router;
        this.failList = [];
        this.failTotal = 0;
        this.successList = [];
        this.successTotal = 0;
        this.noList = [];
        this.noTotal = 0;
        this.checkinType = ['定位签到', '限时签到'];
    }
    ngOnInit() {
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------列表信息展示-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.stuId = localStorage.getItem('UserId');
        this.initList();
    }
    initList() {
        this.failList = [];
        this.failTotal = 0;
        this.successList = [];
        this.successTotal = 0;
        this.noList = [];
        this.noTotal = 0;
        this.getData();
    }
    getData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //获取
            var param = {
                courseId: localStorage.getItem('courseId')
            };
            var api = '/attendance-history';
            this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                // console.log(response);
                this.successList = response.data.data.success;
                this.successTotal = response.data.data.success.length;
                this.failList = response.data.data.fail;
                this.failTotal = response.data.data.fail.length;
                this.noList = response.data.data.no;
                this.noTotal = response.data.data.no.length;
            }));
        });
    }
    gotoMemberList() {
        this.router.navigate(['/member-list']);
    }
};
MemberCheckinPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_5__["HttpService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
MemberCheckinPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-member-checkin',
        template: _raw_loader_member_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_member_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MemberCheckinPage);



/***/ }),

/***/ "BUx+":
/*!***************************************************************************!*\
  !*** ./src/app/pages/member-list/member-checkin/member-checkin.page.scss ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".row-text {\n  background: #80808026;\n  width: 100%;\n  height: 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbWVtYmVyLWNoZWNraW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNKIiwiZmlsZSI6Im1lbWJlci1jaGVja2luLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yb3ctdGV4dCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjODA4MDgwMjY7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogNDBweDtcclxufSJdfQ== */");

/***/ }),

/***/ "QCxY":
/*!***************************************************************************!*\
  !*** ./src/app/pages/member-list/member-checkin/member-checkin.module.ts ***!
  \***************************************************************************/
/*! exports provided: MemberCheckinPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MemberCheckinPageModule", function() { return MemberCheckinPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _member_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./member-checkin-routing.module */ "jYmz");
/* harmony import */ var _member_checkin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./member-checkin.page */ "0cFA");







let MemberCheckinPageModule = class MemberCheckinPageModule {
};
MemberCheckinPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _member_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__["MemberCheckinPageRoutingModule"]
        ],
        declarations: [_member_checkin_page__WEBPACK_IMPORTED_MODULE_6__["MemberCheckinPage"]]
    })
], MemberCheckinPageModule);



/***/ }),

/***/ "cXwf":
/*!*****************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/member-list/member-checkin/member-checkin.page.html ***!
  \*****************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n    <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n        <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"gotoMemberList()\">\r\n            <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n        </ion-button>\r\n        </ion-buttons>\r\n      <ion-title style=\"text-align:center;\">签到记录</ion-title>\r\n    </ion-toolbar>\r\n  </ion-header>\r\n  \r\n  <ion-content>\r\n  \r\n    <ion-item-divider class=\"row-text\">\r\n        <ion-label>您缺勤的签到</ion-label>\r\n        <ion-note slot=\"end\" color=\"tertiary\" style=\"padding: 10px 0 0 0;font-size: 15px;margin-right: 10px;\">{{failTotal+noTotal}}次</ion-note>\r\n    </ion-item-divider>\r\n\r\n    <ion-list>\r\n        <ion-item *ngFor=\"let item of noList; let i = index\" style=\"width:100%\">\r\n            <ion-grid>\r\n                <ion-row>\r\n                    <ion-col size=\"10\">\r\n                        <ion-label>\r\n                            <ion-text style=\"color: #7468be;\">{{checkinType[item.type]}}</ion-text>\r\n                            <p>{{item.startTimeStr}}&nbsp;&nbsp;&nbsp;经验值&nbsp;{{item.exp}}</p>\r\n                        </ion-label>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"2\">\r\n                      <ion-label style=\"text-align: -webkit-right;color:#ed9c57;\">\r\n                          <h2>缺勤</h2>\r\n                      </ion-label>\r\n                    </ion-col>\r\n\r\n                </ion-row>\r\n            </ion-grid>\r\n        </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-list>\r\n        <ion-item *ngFor=\"let item of failList; let i = index\" style=\"width:100%\">\r\n            <ion-grid>\r\n                <ion-row>\r\n                    <ion-col size=\"10\">\r\n                        <ion-label>\r\n                            <ion-text style=\"color: #7468be;\">{{checkinType[item.type]}}</ion-text>\r\n                            <p>{{item.attendanceTimeStr}}&nbsp;&nbsp;&nbsp;经验值&nbsp;{{item.exp}}</p>\r\n                        </ion-label>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"2\">\r\n                      <ion-label style=\"text-align: -webkit-right;color:#ed9c57;\">\r\n                          <h2>缺勤</h2>\r\n                      </ion-label>\r\n                    </ion-col>\r\n\r\n                </ion-row>\r\n            </ion-grid>\r\n        </ion-item>\r\n    </ion-list>\r\n\r\n    <ion-item-divider class=\"row-text\">\r\n        <ion-label>您出勤的签到</ion-label>\r\n        <ion-note slot=\"end\" color=\"tertiary\" style=\"padding: 10px 0 0 0;font-size: 15px;margin-right: 10px;\">{{successTotal}}次</ion-note>\r\n    </ion-item-divider>\r\n\r\n    <ion-list>\r\n        <ion-item *ngFor=\"let item of successList; let i = index\" style=\"width:100%\">\r\n            <ion-grid>\r\n                <ion-row>\r\n                    <ion-col size=\"10\">\r\n                        <ion-label>\r\n                            <ion-text style=\"color: #7468be;\">{{checkinType[item.type]}}</ion-text>\r\n                            <p>{{item.attendanceTimeStr}}&nbsp;&nbsp;&nbsp;经验值&nbsp;{{item.exp}}</p>\r\n                        </ion-label>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"2\">\r\n                      <ion-label style=\"text-align: -webkit-right;color:#ed9c57;\">\r\n                          <h2>出勤</h2>\r\n                      </ion-label>\r\n                    </ion-col>\r\n\r\n                </ion-row>\r\n            </ion-grid>\r\n        </ion-item>\r\n    </ion-list>\r\n  \r\n  </ion-content>");

/***/ }),

/***/ "jYmz":
/*!***********************************************************************************!*\
  !*** ./src/app/pages/member-list/member-checkin/member-checkin-routing.module.ts ***!
  \***********************************************************************************/
/*! exports provided: MemberCheckinPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MemberCheckinPageRoutingModule", function() { return MemberCheckinPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _member_checkin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./member-checkin.page */ "0cFA");




const routes = [
    {
        path: '',
        component: _member_checkin_page__WEBPACK_IMPORTED_MODULE_3__["MemberCheckinPage"]
    }
];
let MemberCheckinPageRoutingModule = class MemberCheckinPageRoutingModule {
};
MemberCheckinPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MemberCheckinPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=member-checkin-member-checkin-module.js.map