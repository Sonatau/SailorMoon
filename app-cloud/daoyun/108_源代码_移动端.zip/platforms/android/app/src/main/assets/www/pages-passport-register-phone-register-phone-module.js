(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-passport-register-phone-register-phone-module"],{

/***/ "Dys3":
/*!********************************************************************************!*\
  !*** ./src/app/pages/passport/register-phone/register-phone-routing.module.ts ***!
  \********************************************************************************/
/*! exports provided: RegisterPhonePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPhonePageRoutingModule", function() { return RegisterPhonePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _register_phone_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register-phone.page */ "r7cD");




const routes = [
    {
        path: '',
        component: _register_phone_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPhonePage"]
    }
];
let RegisterPhonePageRoutingModule = class RegisterPhonePageRoutingModule {
};
RegisterPhonePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterPhonePageRoutingModule);



/***/ }),

/***/ "J/kQ":
/*!**************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passport/register-phone/register-phone.page.html ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-icon slot=\"start\" name=\"chevron-back-outline\" [routerLink]=\"['/login']\"></ion-icon>\r\n    <ion-title class=\"ion-text-center\">快速注册</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"background\">\r\n    <form (ngSubmit)=\"onRegister(registerForm)\" #registerForm=\"ngForm\" novalidate>\r\n      <ion-grid>\r\n        <ion-row class=\"row\" style=\"margin-top:30px;display: block;text-align: center;\"></ion-row>\r\n        \r\n\r\n        <!-- 手机 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"phone\" type=\"text\" class=\"text_input\" placeholder=\"请输入手机号\"\r\n            required pattern=\"^((13[0-9])|(14[5-9])|(15([0-3]|[5-9]))|(16[6-7])|(17[1-8])|(18[0-9])|(19[1|3])|(19[5|6])|(19[8|9]))\\d{8}$\"\r\n            [(ngModel)]=\"register_phone\" #phone=\"ngModel\">\r\n            <ion-icon name=\"call-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"phone.invalid && phone.touched\">\r\n            <p class=\"warn\" [hidden]=\"!phone.errors?.required\" padding-start>必填：请输入手机号</p>\r\n            <p class=\"warn\" [hidden]=\"!phone.errors?.pattern\" padding-start>您输入的手机号格式不正确</p>\r\n          </ion-text>\r\n        </div>\r\n        \r\n        <!-- 验证码 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"code\" type=\"text\" class=\"verify_input\" placeholder=\"请输入验证码\"\r\n          [(ngModel)]=\"verify_code\" #code=\"ngModel\" required>\r\n            <ion-icon name=\"mail-open-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n          <ion-button color=\"primary\" (click)=\"onSendSMS()\" [disabled]=\"!verifyCode.disable\">\r\n            {{verifyCode.verifyCodeTips}}</ion-button>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"code.invalid && code.touched\">\r\n            <p class=\"warn\" [hidden]=\"!code.errors?.required\" padding-start>请输入验证码</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <!-- 身份选择 -->\r\n        <ion-radio-group name=\"role\" [(ngModel)]=\"roleID\" mode=\"md\" required>\r\n          <ion-row class=\"row\">\r\n            <ion-col>\r\n              <ion-label style=\"margin-left: 15px; font-weight: bold;\" color=\"light\">身份</ion-label>\r\n            </ion-col>\r\n            <ion-col>\r\n              <ion-radio color=\"success\" value=1></ion-radio>\r\n              <ion-label style=\"margin-left: 15px;\" color=\"light\">教师</ion-label>\r\n            </ion-col>\r\n            <ion-col>\r\n              <ion-radio color=\"warning\" value=2></ion-radio>\r\n              <ion-label style=\"margin-left: 15px;\" color=\"light\">学生</ion-label>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-radio-group>\r\n  \r\n        <ion-row class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n            [disabled]=\"registerForm.invalid\"> 注册</ion-button>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </form>\r\n  </div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "dIkU":
/*!************************************************************************!*\
  !*** ./src/app/pages/passport/register-phone/register-phone.module.ts ***!
  \************************************************************************/
/*! exports provided: RegisterPhonePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPhonePageModule", function() { return RegisterPhonePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _register_phone_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-phone-routing.module */ "Dys3");
/* harmony import */ var _register_phone_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register-phone.page */ "r7cD");







let RegisterPhonePageModule = class RegisterPhonePageModule {
};
RegisterPhonePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _register_phone_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPhonePageRoutingModule"]
        ],
        declarations: [_register_phone_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPhonePage"]]
    })
], RegisterPhonePageModule);



/***/ }),

/***/ "r7cD":
/*!**********************************************************************!*\
  !*** ./src/app/pages/passport/register-phone/register-phone.page.ts ***!
  \**********************************************************************/
/*! exports provided: RegisterPhonePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPhonePage", function() { return RegisterPhonePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_register_phone_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./register-phone.page.html */ "J/kQ");
/* harmony import */ var _register_phone_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./register-phone.page.scss */ "ydz/");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let RegisterPhonePage = class RegisterPhonePage {
    constructor(httpService, http, router, alertController, toastController, loadingController) {
        this.httpService = httpService;
        this.http = http;
        this.router = router;
        this.alertController = alertController;
        this.toastController = toastController;
        this.loadingController = loadingController;
        this.register_phone = '';
        this.verify_code = '';
        this.verifyCode = {
            verifyCodeTips: "获取验证码",
            countdown: 60,
            disable: true
        };
        this.temp_name = "name_null";
        this.temp_sno = -1;
        this.temp_image = "image_null";
    }
    ngOnInit() {
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------获取验证码-------------------------------------//
    //----------------------------------------------------------------------------------//
    onSendSMS() {
        //请求后台发送验证码
        if (this.verifyCode.disable == true) {
            this.verifyCode.disable = false;
            this.settime();
            var params = {
                phone: this.register_phone,
            };
            var api = '/send-message';
            // console.log(params);
            this.httpService.get_withoutToken(api, params).then((response) => {
                // console.log(response);
                this.return_code = response.data.respCode;
                // console.log(this.return_code);
            });
        }
    }
    settime() {
        if (this.verifyCode.countdown == 1) {
            this.verifyCode.countdown = 60;
            this.verifyCode.verifyCodeTips = "获取验证码";
            this.verifyCode.disable = true;
            return;
        }
        else {
            this.verifyCode.countdown--;
        }
        this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
        setTimeout(() => {
            this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
            this.settime();
        }, 1000);
    }
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //-----------------------------------提交注册信息------------------------------------//
    //----------------------------------------------------------------------------------//
    onRegister(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '请稍等...',
            });
            yield loading.present();
            if (form.invalid) { //检验输入信息是否有效
                yield loading.dismiss();
                let toast = yield this.toastController.create({
                    message: '请输入有效信息！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                if (this.return_code == -1) { //检验是否成功发送验证码
                    yield loading.dismiss();
                    let toast = yield this.toastController.create({
                        message: '请先获取验证码！',
                        duration: 2000
                    });
                    toast.present();
                }
                else {
                    var api = '/register-phone'; //-------------------------后台接口
                    var params = {
                        telephone: this.register_phone,
                        verificationCode: this.verify_code,
                        roleId: this.roleID,
                        name: this.temp_name,
                        sno: this.temp_sno,
                        image: this.temp_image
                    };
                    // console.log(params);
                    this.httpService.post_withoutToken(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                        yield loading.dismiss();
                        // console.log(response);
                        if (response.data.respCode == -1) {
                            let alert = yield this.alertController.create({
                                header: '提示',
                                message: response.data.msg,
                                buttons: ['确定']
                            });
                            alert.present();
                        }
                        else if (response.data.respCode == 1) {
                            let alert = yield this.alertController.create({
                                header: '提示',
                                message: '注册成功！',
                                buttons: [{
                                        text: '确认',
                                        cssClass: 'primary',
                                        handler: (blah) => {
                                            this.login();
                                        }
                                    }]
                            });
                            alert.present();
                        }
                    }));
                }
            }
        });
    }
    login() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '登陆中...',
            });
            var api = '/login-code'; //后台接口
            var params = {
                phone: this.register_phone,
                code: this.verify_code,
                device: 0
            };
            this.httpService.post_withoutToken(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                // console.log(response);
                this.return_code = response.data.respCode;
                // console.log(this.return_code);
                if (this.return_code == '1') {
                    localStorage.setItem("token", response.data.data.token);
                    if (response.data.data.role == '1')
                        localStorage.setItem("isTeacher", '1');
                    else
                        localStorage.setItem("isTeacher", '0');
                    if (response.data.data.admin.course == '1')
                        localStorage.setItem("course-admin", '1');
                    else
                        localStorage.setItem("course-admin", '0');
                    if (response.data.data.admin.checkin == '1')
                        localStorage.setItem("checkin-admin", '1');
                    else
                        localStorage.setItem("checkin-admin", '0');
                    localStorage.setItem("isLogin", "1");
                    this.router.navigateByUrl('/tabs/course');
                    this.setLoginTime();
                }
                else {
                    yield loading.dismiss();
                    let alert = yield this.alertController.create({
                        header: '提示',
                        message: '登录失败',
                        buttons: ['确定']
                    });
                    alert.present();
                }
            }));
        });
    }
    setLoginTime() {
        let myDate = new Date();
        //获取当前年
        var year = myDate.getFullYear();
        //获取当前月
        var month = myDate.getMonth() + 1;
        //获取当前日
        var date = myDate.getDate();
        var h = myDate.getHours() < 10 ? '0' + myDate.getHours() : '' + myDate.getHours(); //获取当前小时数(0-23)
        var m = myDate.getMinutes() < 10 ? '0' + myDate.getMinutes() : '' + myDate.getMinutes(); //获取当前分钟数(0-59)
        var s = myDate.getSeconds() < 10 ? '0' + myDate.getSeconds() : '' + myDate.getSeconds();
        localStorage.setItem("loginTime", year + "/" + month + "/" + date + " " + h + ":" + m + ":" + s);
    }
};
RegisterPhonePage.ctorParameters = () => [
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
RegisterPhonePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-register-phone',
        template: _raw_loader_register_phone_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_register_phone_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RegisterPhonePage);



/***/ }),

/***/ "ydz/":
/*!************************************************************************!*\
  !*** ./src/app/pages/passport/register-phone/register-phone.page.scss ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".background {\n  height: 100%;\n  width: 100%;\n  background-image: url(\"/assets/img/login/login.png\");\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.img-tel {\n  height: 28px;\n}\n\nion-segment-button {\n  background-color: rgba(225, 225, 225, 0) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmVnaXN0ZXItcGhvbmUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxvREFBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7QUFBSjs7QUFJQTtFQUNJLFlBQUE7QUFESjs7QUFHQTtFQUNJLG1EQUFBO0FBQUoiLCJmaWxlIjoicmVnaXN0ZXItcGhvbmUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy/pobXpnaLog4zmma9cclxuLmJhY2tncm91bmR7XHJcbiAgICBoZWlnaHQ6MTAwJTtcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOnVybChcIi9hc3NldHMvaW1nL2xvZ2luL2xvZ2luLnBuZ1wiKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0Om5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtc2l6ZToxMDAlIDEwMCU7XHJcbn1cclxuXHJcbi8v6KGM6auY562J5p2C6aG5XHJcbi5pbWctdGVse1xyXG4gICAgaGVpZ2h0OiAyOHB4O1xyXG59XHJcbmlvbi1zZWdtZW50LWJ1dHRvbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjI1LDIyNSwyMjUsMCkgIWltcG9ydGFudDtcclxufSJdfQ== */");

/***/ })

}]);
//# sourceMappingURL=pages-passport-register-phone-register-phone-module.js.map