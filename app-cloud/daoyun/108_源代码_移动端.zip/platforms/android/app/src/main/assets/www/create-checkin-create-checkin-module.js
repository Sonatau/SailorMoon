(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["create-checkin-create-checkin-module"],{

/***/ "5OpY":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin.module.ts ***!
  \***********************************************************************/
/*! exports provided: CreateCheckinPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCheckinPageModule", function() { return CreateCheckinPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./create-checkin-routing.module */ "v79b");
/* harmony import */ var _create_checkin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-checkin.page */ "atnx");







let CreateCheckinPageModule = class CreateCheckinPageModule {
};
CreateCheckinPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _create_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateCheckinPageRoutingModule"]
        ],
        declarations: [_create_checkin_page__WEBPACK_IMPORTED_MODULE_6__["CreateCheckinPage"]]
    })
], CreateCheckinPageModule);



/***/ }),

/***/ "5fTR":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/checkin/create-checkin/create-checkin.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"gotodetail()\">\r\n          <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n      </ion-button>\r\n      </ion-buttons>\r\n    <ion-title>时限设置</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form (ngSubmit)=\"onSubmit(checkinForm)\" #checkinForm=\"ngForm\" novalidate>\r\n      <ion-item lines=\"none\"></ion-item>\r\n\r\n      <!-- <ion-item lines=\"none\" *ngIf=\"type==2\">\r\n          <ion-input name=\"str\" type=\"text\" style=\"border-bottom: solid 1px #7468BE\" placeholder=\"请输入口令\"\r\n          [(ngModel)]=\"pass\" #str=\"ngModel\"></ion-input>\r\n      </ion-item> -->\r\n\r\n      <ion-item lines=\"none\">\r\n        <ion-note>请选择限定时间：</ion-note>\r\n      </ion-item>\r\n      <ion-radio-group name=\"time\" #time=\"ngModel\" [(ngModel)]=\"timeLimit\">\r\n        <ion-item>\r\n          <ion-label>1分钟</ion-label>\r\n          <ion-radio value=60 slot=\"end\"></ion-radio>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label>3分钟</ion-label>\r\n          <ion-radio value=180 slot=\"end\"></ion-radio>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label>5分钟</ion-label>\r\n          <ion-radio value=300 slot=\"end\"></ion-radio>\r\n        </ion-item>\r\n    </ion-radio-group>\r\n\r\n    <ion-item lines=\"none\"></ion-item>\r\n      <ion-row class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n          [disabled]=\"checkinForm.invalid\">发起签到</ion-button>\r\n      </ion-row>\r\n\r\n  </form>\r\n</ion-content>\r\n");

/***/ }),

/***/ "YDyG":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtY2hlY2tpbi5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "atnx":
/*!*********************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin.page.ts ***!
  \*********************************************************************/
/*! exports provided: CreateCheckinPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCheckinPage", function() { return CreateCheckinPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-checkin.page.html */ "5fTR");
/* harmony import */ var _create_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-checkin.page.scss */ "YDyG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");







let CreateCheckinPage = class CreateCheckinPage {
    constructor(router, toastController, httpService, alertController) {
        this.router = router;
        this.toastController = toastController;
        this.httpService = httpService;
        this.alertController = alertController;
    }
    ngOnInit() {
    }
    ionViewWillEnter() {
        this.code = localStorage.getItem('courseCode');
        // this.type = this.activatedRoute.snapshot.queryParams['type'];
        this.courseId = localStorage.getItem('courseId');
    }
    onSubmit(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // if(this.type==2 && (this.pass=="" || this.pass==null)){
            //   let toast = await this.toastController.create({
            //     message: '请输入口令！',
            //     duration: 2000
            //   });
            //   toast.present();
            if (this.timeLimit == null) {
                let toast = yield this.toastController.create({
                    message: '请选择签到持续时间！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                var begin = Date.now() / 1000;
                this.beginStr = this.getTimeStr(begin);
                // if(this.type==1){//0-定位 1-限时 2-口令
                var end = Number(this.getTimeStamp(this.beginStr)) + Number(this.timeLimit);
                this.endStr = this.getTimeStr(end);
                var param_1 = {
                    type: 1,
                    courseId: this.courseId,
                    startTimeStr: this.beginStr,
                    expectEndTimeStr: this.endStr,
                    local: 'null'
                };
                this.post(param_1);
                // } else if(this.type==2){
                //   var param_2 = {
                //     type: this.type,
                //     courseId: this.courseId,
                //     startTimeStr: this.beginStr,
                //     code: this.pass
                //   }
                //   this.post(param_2);
                // }
            }
        });
    }
    post(param) {
        var api = '/attendance';
        // console.log(param);
        this.httpService.post_data(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            if (response.data.respCode == 1) {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: '签到发起成功！',
                    buttons: [{
                            text: '确认',
                            cssClass: 'primary',
                            handler: (blah) => {
                                this.router.navigate(['/checkin']);
                            }
                        }]
                });
                alert.present();
            }
            else {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: "签到发起失败！",
                    buttons: ['确定']
                });
                alert.present();
            }
        }));
    }
    gotodetail() {
        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.code } });
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------JS时间转换-------------------------------------//
    //----------------------------------------------------------------------------------//
    getTimeStr(timestamp) {
        var time = new Date(timestamp * 1000);
        var date = ((time.getFullYear()) + "-" +
            (time.getMonth() + 1).toString().padStart(2, '0') + "-" +
            (time.getDate()).toString().padStart(2, '0') + " " +
            (time.getHours()).toString().padStart(2, '0') + ":" +
            (time.getMinutes()).toString().padStart(2, '0') + ":" +
            (time.getSeconds()).toString().padStart(2, '0'));
        return date;
    }
    getTimeStamp(dateStr) {
        dateStr = dateStr.substring(0, 19);
        dateStr = dateStr.replace(/-/g, '/');
        var timeTamp = new Date(dateStr).getTime() / 1000;
        return timeTamp;
    }
};
CreateCheckinPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__["HttpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] }
];
CreateCheckinPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-create-checkin',
        template: _raw_loader_create_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateCheckinPage);



/***/ }),

/***/ "v79b":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: CreateCheckinPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCheckinPageRoutingModule", function() { return CreateCheckinPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_checkin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-checkin.page */ "atnx");




const routes = [
    {
        path: '',
        component: _create_checkin_page__WEBPACK_IMPORTED_MODULE_3__["CreateCheckinPage"]
    }
];
let CreateCheckinPageRoutingModule = class CreateCheckinPageRoutingModule {
};
CreateCheckinPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateCheckinPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=create-checkin-create-checkin-module.js.map