(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["create-course-create-course-module"],{

/***/ "4nSL":
/*!********************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course.module.ts ***!
  \********************************************************************/
/*! exports provided: CreateCoursePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCoursePageModule", function() { return CreateCoursePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_course_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./create-course-routing.module */ "sfRM");
/* harmony import */ var _create_course_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-course.page */ "c2xb");







let CreateCoursePageModule = class CreateCoursePageModule {
};
CreateCoursePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _create_course_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateCoursePageRoutingModule"]
        ],
        declarations: [_create_course_page__WEBPACK_IMPORTED_MODULE_6__["CreateCoursePage"]]
    })
], CreateCoursePageModule);



/***/ }),

/***/ "KEsy":
/*!********************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course.page.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".cover_img {\n  width: 21rem;\n  height: auto;\n}\n\n.signup_warn {\n  width: 90%;\n  margin: 0 auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY3JlYXRlLWNvdXJzZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0ksVUFBQTtFQUNBLGNBQUE7QUFDSiIsImZpbGUiOiJjcmVhdGUtY291cnNlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb3Zlcl9pbWcge1xyXG4gICAgd2lkdGg6IDIxcmVtOyAgICBcclxuICAgIGhlaWdodDogYXV0bztcclxufVxyXG5cclxuLnNpZ251cF93YXJuIHtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBtYXJnaW46IDAgYXV0bztcclxuICB9Il19 */");

/***/ }),

/***/ "c2xb":
/*!******************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course.page.ts ***!
  \******************************************************************/
/*! exports provided: CreateCoursePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCoursePage", function() { return CreateCoursePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_course_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-course.page.html */ "ovBZ");
/* harmony import */ var _create_course_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-course.page.scss */ "KEsy");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");
/* harmony import */ var src_app_shared_services_picker_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/picker.service */ "JSqg");
/* harmony import */ var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/image-picker/ngx */ "tAfe");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");











let CreateCoursePage = class CreateCoursePage {
    constructor(router, httpService, pickerService, http, alertController, toastController, pickerController, platform, actionSheetCtrl, camera, imagePicker) {
        this.router = router;
        this.httpService = httpService;
        this.pickerService = pickerService;
        this.http = http;
        this.alertController = alertController;
        this.toastController = toastController;
        this.pickerController = pickerController;
        this.platform = platform;
        this.actionSheetCtrl = actionSheetCtrl;
        this.camera = camera;
        this.imagePicker = imagePicker;
        this.course_cover = "image_null";
        this.schoolList = {
            total: 0,
            options: []
        };
        this.academyList = {
            total: 0,
            options: []
        };
        this.lessonList = {
            total: 0,
            options: []
        };
        this.termList = {
            total: 0,
            options: []
        };
        this.schoolChoosed = {
            name: "请选择",
            id: -1
        };
        this.academyChoosed = {
            name: "请选择",
            id: -1
        };
        this.lessonChoosed = {
            name: "请选择",
            id: -1
        };
        this.termChoosed = {
            name: "请选择",
            id: -1
        };
    }
    ngOnInit() { }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------各种列表初始化---------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.initList();
        this.course_name = null;
        this.course_lesson = null;
    }
    initList() {
        this.setTermList();
        this.setSchoolList();
        this.setLessonList();
    }
    setSchoolList() {
        this.schoolList.options = [];
        this.schoolList.total = 0;
        this.schoolChoosed = {
            name: "请选择",
            id: -1
        };
        var param = {
            page: 1
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.schoolList.options.push({
                    id: response.data.data.list[i].id,
                    name: response.data.data.list[i].name
                });
            }
            this.schoolList.total = response.data.data.total;
            //console.log(this.schoolList);
        }));
    }
    setAcademyList() {
        this.academyList.options = [];
        this.academyList.total = 0;
        this.academyChoosed = {
            name: "请选择",
            id: -1
        };
        var param = {
            page: 1,
            parentId: this.schoolChoosed.id
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.academyList.options.push({
                    id: response.data.data.list[i].id,
                    name: response.data.data.list[i].name
                });
            }
            this.academyList.total = response.data.data.total;
        }));
    }
    setTermList() {
        //根据lable取对应的id
        var param_id = {
            page: 1,
            label: 'semester'
        };
        var api = '/dictionary';
        this.httpService.get(api, param_id).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            this.termId = response.data.data.list[0].id;
            //根据id取学期的列表，并更新默认值
            var param_term = {
                page: 1,
                id: this.termId
            };
            var api = '/dictionary-detail';
            this.httpService.get(api, param_term).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                // console.log(response);
                for (let i = 0; i < response.data.data.total; i++) {
                    this.termList.options.push({
                        id: response.data.data.list[i].id,
                        name: response.data.data.list[i].name
                    });
                    if (response.data.data.list[i].isDefault == 1) {
                        this.termChoosed.name = response.data.data.list[i].name;
                        this.termChoosed.id = response.data.data.list[i].id;
                    }
                }
                this.termList.total = response.data.data.total;
            }));
        }));
    }
    setLessonList() {
        this.lessonList.options = [];
        this.lessonList.total = 0;
        this.lessonChoosed = {
            name: "请选择",
            id: -1
        };
        var param = {};
        var api = '/lesson';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            this.lessonList.options = response.data.data.list;
            this.lessonList.total = response.data.data.list.length;
            // console.log(this.lessonList);
        }));
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------------请求学校/学院/专业列表------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    openPicker(type, listName) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (type == 1 && this.schoolChoosed.id == -1) {
                const alert = yield this.alertController.create({
                    header: '警告',
                    message: '请先选择学校！',
                    buttons: ['确认']
                });
                yield alert.present();
            }
            else {
                if (listName == 'term') {
                    this.termChoosed = yield this.pickerService.createPicker(this.termList);
                }
                else if (listName == 'school') {
                    const picker = yield this.pickerController.create({
                        columns: this.getColumns(),
                        buttons: [
                            {
                                text: '取消',
                                role: 'cancel'
                            },
                            {
                                text: '确认',
                                handler: (value) => {
                                    var selected = this.getColumns();
                                    //console.log(value);
                                    this.schoolChoosed.name = selected[0].options[value.daoyun108.value].text;
                                    this.schoolChoosed.id = selected[0].options[value.daoyun108.value].id;
                                    this.setAcademyList();
                                }
                            }
                        ]
                    });
                    yield picker.present();
                }
                else if (listName == 'academy') {
                    // console.log(this.academyList);
                    this.academyChoosed = yield this.pickerService.createPicker(this.academyList);
                }
                else if (listName == 'lesson') {
                    this.lessonChoosed = yield this.pickerService.createPicker(this.lessonList);
                }
            }
        });
    }
    getColumns() {
        let options = [];
        for (let i = 0; i < this.schoolList.total; i++) {
            options.push({
                text: this.schoolList.options[i].name,
                id: this.schoolList.options[i].id,
                value: i
            });
        }
        let columns = [];
        columns.push({
            name: `daoyun108`,
            options: options
        });
        //console.log(options);
        return columns;
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------选择班课封面-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    /**
     * 上传图片
     * @returns {Promise<void>}
     */
    onPresentActiveSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetCtrl.create({
                header: '选择您的操作',
                buttons: [
                    {
                        text: '拍照',
                        // role: 'destructive',
                        handler: () => {
                            console.log('进入相机');
                            this.onCamera();
                        }
                    }, {
                        text: '相册',
                        handler: () => {
                            console.log('进入相册');
                            this.onImagePicker();
                        }
                    }, {
                        text: '取消',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    /**
     * 拍照
     */
    onCamera() {
        const options = {
            quality: 10,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then((imageData) => {
            this.course_cover = 'data:image/jpeg;base64,' + imageData;
        }, (err) => {
        });
    }
    /**
     * 相册
     */
    onImagePicker() {
        const options = {
            maximumImagesCount: 1,
            quality: 10,
            outputType: 1
        };
        console.log('in imagePicker');
        this.imagePicker.getPictures(options).then((results) => {
            for (let i = 0; i < results.length; i++) {
                //console.log('Image URI: ' + results[i]);
                this.course_cover = 'data:image/jpeg;base64,' + results[i];
            }
        }, (err) => { console.log(err); });
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-------------------------------------------------------创建班课------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    onCreate(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (form.valid) {
                if (this.schoolChoosed.id == -1 || this.academyChoosed.id == -1) {
                    let toast = yield this.toastController.create({
                        message: '请选择学校和学院！',
                        duration: 2000
                    });
                    toast.present();
                }
                else if (this.lessonChoosed.id == -1 && this.course_lesson == null) {
                    let toast = yield this.toastController.create({
                        message: '请选择课程或自定义课程！',
                        duration: 2000
                    });
                    toast.present();
                }
                else {
                    if (this.course_lesson != null && this.course_lesson != "") {
                        //如果自定义课程
                        var param_add = {
                            name: this.course_lesson
                        };
                        var api = '/lesson';
                        this.httpService.post_data(api, param_add).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            // console.log(response);
                            this.lessonChoosed.id = response.data.data.id;
                            this.lessonChoosed.name = this.course_lesson;
                            this.createCourse();
                        }));
                    }
                    else {
                        this.createCourse();
                    }
                }
            }
        });
    }
    createCourse() {
        var param_creat = {
            image: this.course_cover,
            name: this.lessonChoosed.name + '-' + this.course_name,
            schoolId: this.schoolChoosed.id,
            acadeId: this.academyChoosed.id,
            termId: this.termChoosed.id,
            lessonId: this.lessonChoosed.id,
            state: 1,
            okJoin: 1
        };
        var api = '/course';
        this.httpService.post_data(api, param_creat).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            this.course_code = response.data.data.code;
            const alert = yield this.alertController.create({
                message: '班课创建成功！',
                buttons: [
                    {
                        text: '确认',
                        cssClass: 'secondary',
                        handler: (blah) => {
                            localStorage.setItem('courseCode', this.course_code);
                            localStorage.setItem('courseName', this.lessonChoosed.name + '-' + this.course_name);
                            this.router.navigate(['/course/create-success']);
                        }
                    }
                ]
            });
            yield alert.present();
        }));
    }
};
CreateCoursePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: src_app_shared_services_picker_service__WEBPACK_IMPORTED_MODULE_8__["PickerService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PickerController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_10__["Camera"] },
    { type: _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_9__["ImagePicker"] }
];
CreateCoursePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-create-course',
        template: _raw_loader_create_course_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_course_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateCoursePage);



/***/ }),

/***/ "ovBZ":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/create-course/create-course.page.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/tabs/course']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">创建班课</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form (ngSubmit)=\"onCreate(createForm)\" #createForm=\"ngForm\" novalidate>\r\n      <ion-list lines=\"full\">\r\n \r\n        <ion-item-divider color=\"stable\">\r\n          <!-- <ion-thumbnail *ngIf=\"course_cover != 'image_null'\" slot=\"start\"> -->\r\n            <img *ngIf=\"course_cover != 'image_null'\" slot=\"start\" class=\"cover_img\"\r\n              src={{course_cover}}>\r\n          <!-- </ion-thumbnail> -->\r\n          <!-- <ion-thumbnail slot=\"start\" (click)=\"onPresentActiveSheet()\"> -->\r\n            <img *ngIf=\"course_cover == 'image_null'\" slot=\"start\" class=\"cover_img\"\r\n            (click)=\"addPicture()\" src=\"assets/img/course/add.png\">\r\n          <!-- </ion-thumbnail> -->\r\n        </ion-item-divider>\r\n\r\n        <ion-item (click)=\"openPicker(0,'term')\">\r\n          <ion-label slot=\"start\">班课学期</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{termChoosed.name}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(0, 'lesson')\">\r\n          <ion-label slot=\"start\">选择已有课程</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{lessonChoosed.name}}</ion-note>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-label slot=\"start\">(或)自定义课程</ion-label>\r\n          <ion-input name=\"lesson\" type=\"text\" class=\"my_inf\" slot=\"end\"\r\n            placeholder=\"未设置\" [(ngModel)]=\"course_lesson\" #lesson=\"ngModel\">\r\n          </ion-input>\r\n        </ion-item>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"(lesson.touched) && (course_lesson==null && lessonChoosed.name=='请选择')\">\r\n            <p class=\"warn\" padding-start>请选择课程或自定义课程！</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <ion-item>\r\n          <ion-label slot=\"start\">班级名称</ion-label>\r\n          <ion-input name=\"name\" type=\"text\" class=\"my_inf\" slot=\"end\"\r\n            placeholder=\"未设置\" [(ngModel)]=\"course_name\" #name=\"ngModel\" required>\r\n          </ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(0, 'school')\">\r\n          <ion-label slot=\"start\">开设学校</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{schoolChoosed.name}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(1, 'academy')\">\r\n          <ion-label slot=\"start\">开设学院</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{academyChoosed.name}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-row style=\"margin: top 30px;\" class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n          [disabled]=\"createForm.invalid\"> 创建班课 </ion-button>\r\n        </ion-row>\r\n      </ion-list>\r\n  </form>\r\n\r\n</ion-content>");

/***/ }),

/***/ "sfRM":
/*!****************************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course-routing.module.ts ***!
  \****************************************************************************/
/*! exports provided: CreateCoursePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCoursePageRoutingModule", function() { return CreateCoursePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_course_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-course.page */ "c2xb");




const routes = [
    {
        path: '',
        component: _create_course_page__WEBPACK_IMPORTED_MODULE_3__["CreateCoursePage"]
    }
];
let CreateCoursePageRoutingModule = class CreateCoursePageRoutingModule {
};
CreateCoursePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateCoursePageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=create-course-create-course-module.js.map