(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["course-checkin-course-checkin-module"],{

/***/ "/hqZ":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/checkin/course-checkin/course-checkin.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"returndetail()\">\r\n          <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n      </ion-button>\r\n      </ion-buttons>\r\n    <ion-title>签到历史</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\r\n    <ion-refresher-content \r\n     pullingIcon=\"chevron-down\">\r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n  <div *ngIf=\"total!=0\">\r\n    <ion-list id=\"list\" lines=\"full\" *ngFor=\"let item of list; let i=index\">\r\n\r\n        <ion-item style=\"width:100%\">\r\n            <ion-grid>\r\n                <ion-row (click)=\"gotoResult(i)\">\r\n\r\n                    <ion-col size=\"11\">\r\n                        <ion-label>\r\n                            <ion-text style=\"color: #7468be;\">{{checkinType[item.type]}}</ion-text>\r\n                            <p>{{item.startTimeStr}}&nbsp;&nbsp;&nbsp;活动经验&nbsp;{{item.exp}}</p>\r\n                        </ion-label>\r\n                    </ion-col>\r\n\r\n                    <ion-col size=\"1\">\r\n                        <ion-icon solt=\"end\" name=\"chevron-forward-outline\" color=\"primary\"\r\n                        style=\"margin-top: 50%; font-size: large;\"></ion-icon>\r\n                    </ion-col>\r\n\r\n                </ion-row>\r\n            </ion-grid>\r\n        </ion-item>\r\n\r\n    </ion-list>\r\n\r\n    <ion-item *ngIf=\"flag==1\" lines=\"none\">\r\n        <ion-label style=\"text-align: center;\">\r\n             <p>你已经看到我的底线啦~</p>\r\n        </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-infinite-scroll threshold=\"10%\" id=\"infinite-scroll\" (ionInfinite)=\"loadData($event)\">\r\n        <ion-infinite-scroll-content\r\n            loading-spinner=\"bubbles\" loading-text=\"加载中...\">\r\n        </ion-infinite-scroll-content>\r\n    </ion-infinite-scroll>\r\n\r\n</div>\r\n\r\n<div *ngIf=\"total==0 && flag==1\">\r\n    <ion-grid>\r\n        <ion-item lines=\"none\"></ion-item>\r\n        <ion-item lines=\"none\"></ion-item>\r\n        \r\n        <ion-row>\r\n            <ion-col></ion-col>\r\n            <ion-col><img src=\"assets/img/components/empty.png\"></ion-col>\r\n            <ion-col></ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n            <ion-col>\r\n                <ion-label style=\"text-align: center;\">\r\n                    <p>当前班课没有历史签到~</p>\r\n                </ion-label>\r\n            </ion-col>\r\n        </ion-row>\r\n\r\n    </ion-grid>\r\n\r\n  </div>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "DBTF":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/course-checkin/course-checkin.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjb3Vyc2UtY2hlY2tpbi5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "EGl3":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/checkin/course-checkin/course-checkin-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: CourseCheckinPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseCheckinPageRoutingModule", function() { return CourseCheckinPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _course_checkin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./course-checkin.page */ "rT+R");




const routes = [
    {
        path: '',
        component: _course_checkin_page__WEBPACK_IMPORTED_MODULE_3__["CourseCheckinPage"]
    }
];
let CourseCheckinPageRoutingModule = class CourseCheckinPageRoutingModule {
};
CourseCheckinPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CourseCheckinPageRoutingModule);



/***/ }),

/***/ "I5I9":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/course-checkin/course-checkin.module.ts ***!
  \***********************************************************************/
/*! exports provided: CourseCheckinPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseCheckinPageModule", function() { return CourseCheckinPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _course_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./course-checkin-routing.module */ "EGl3");
/* harmony import */ var _course_checkin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./course-checkin.page */ "rT+R");







let CourseCheckinPageModule = class CourseCheckinPageModule {
};
CourseCheckinPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _course_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__["CourseCheckinPageRoutingModule"]
        ],
        declarations: [_course_checkin_page__WEBPACK_IMPORTED_MODULE_6__["CourseCheckinPage"]]
    })
], CourseCheckinPageModule);



/***/ }),

/***/ "rT+R":
/*!*********************************************************************!*\
  !*** ./src/app/pages/checkin/course-checkin/course-checkin.page.ts ***!
  \*********************************************************************/
/*! exports provided: CourseCheckinPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseCheckinPage", function() { return CourseCheckinPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-checkin.page.html */ "/hqZ");
/* harmony import */ var _course_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-checkin.page.scss */ "DBTF");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");







let CourseCheckinPage = class CourseCheckinPage {
    constructor(loadingController, httpService, activatedRoute, router) {
        this.loadingController = loadingController;
        this.httpService = httpService;
        this.activatedRoute = activatedRoute;
        this.router = router;
        this.list = [];
        this.page_max = 10;
        this.page = 1;
        this.total = 0;
        this.flag = 0; //标记是否抓取完全
        this.checkinType = ['定位签到', '限时签到'];
    }
    ngOnInit() {
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------列表信息展示-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.courseId = localStorage.getItem('courseId');
        this.courseCode = localStorage.getItem('courseCode');
        this.initData();
    }
    initData() {
        this.list = [];
        this.page = 1;
        this.total = 0;
        this.flag = 0;
        this.getCheckinList();
    }
    getCheckinList() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            var params = {
                page: this.page,
                courseId: this.courseId
            };
            var api = '/attendance';
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                // console.log(response);
                if (response.data.data.list.length < this.page_max) {
                    this.flag = 1;
                }
                for (let i = 0; i < response.data.data.list.length; i++) {
                    if (response.data.data.list[i].state != 0) {
                        this.list.push(response.data.data.list[i]);
                        this.total = this.total + 1;
                    }
                }
            })).catch(function (error) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    const alert = yield this.alertController.create({
                        header: '警告',
                        message: '请求失败！',
                        buttons: ['确认']
                    });
                    yield alert.present();
                });
            });
        });
    }
    loadData(event) {
        setTimeout(() => {
            if (this.flag == 1) {
                event.target.disabled = true;
            }
            else {
                this.page = this.page + 1;
                this.getCheckinList();
            }
            event.target.complete();
        }, 500);
    }
    doRefresh(event) {
        this.initData();
        setTimeout(() => {
            event.target.complete();
        }, 500);
    }
    gotoResult(index) {
        this.router.navigate(['/checkin/checkin-result'], { queryParams: { checkinId: this.list[index].id } });
    }
    returndetail() {
        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.courseCode } });
    }
};
CourseCheckinPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__["HttpService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
CourseCheckinPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-course-checkin',
        template: _raw_loader_course_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseCheckinPage);



/***/ })

}]);
//# sourceMappingURL=course-checkin-course-checkin-module.js.map