(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["checkin-result-checkin-result-module"],{

/***/ "+3v+":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result.module.ts ***!
  \***********************************************************************/
/*! exports provided: CheckinResultPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinResultPageModule", function() { return CheckinResultPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _checkin_result_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./checkin-result-routing.module */ "+LgT");
/* harmony import */ var _checkin_result_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./checkin-result.page */ "GbYZ");







let CheckinResultPageModule = class CheckinResultPageModule {
};
CheckinResultPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _checkin_result_routing_module__WEBPACK_IMPORTED_MODULE_5__["CheckinResultPageRoutingModule"]
        ],
        declarations: [_checkin_result_page__WEBPACK_IMPORTED_MODULE_6__["CheckinResultPage"]]
    })
], CheckinResultPageModule);



/***/ }),

/***/ "+LgT":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: CheckinResultPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinResultPageRoutingModule", function() { return CheckinResultPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _checkin_result_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./checkin-result.page */ "GbYZ");




const routes = [
    {
        path: '',
        component: _checkin_result_page__WEBPACK_IMPORTED_MODULE_3__["CheckinResultPage"]
    }
];
let CheckinResultPageRoutingModule = class CheckinResultPageRoutingModule {
};
CheckinResultPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CheckinResultPageRoutingModule);



/***/ }),

/***/ "GbYZ":
/*!*********************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result.page.ts ***!
  \*********************************************************************/
/*! exports provided: CheckinResultPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinResultPage", function() { return CheckinResultPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_checkin_result_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./checkin-result.page.html */ "uaBc");
/* harmony import */ var _checkin_result_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./checkin-result.page.scss */ "Gq5T");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");







let CheckinResultPage = class CheckinResultPage {
    constructor(activatedRoute, httpService, router, actionSheetController, toastController) {
        this.activatedRoute = activatedRoute;
        this.httpService = httpService;
        this.router = router;
        this.actionSheetController = actionSheetController;
        this.toastController = toastController;
        this.failList = [];
        this.failTotal = 0;
        this.successList = [];
        this.successTotal = 0;
        this.noList = [];
        this.noTotal = 0;
    }
    ngOnInit() {
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------列表信息展示-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.checkinId = this.activatedRoute.snapshot.queryParams['checkinId'];
        this.initList();
    }
    initList() {
        this.failList = [];
        this.failTotal = 0;
        this.successList = [];
        this.successTotal = 0;
        this.noList = [];
        this.noTotal = 0;
        this.getData();
    }
    getData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //获取
            var param = {
                attendanceId: this.checkinId,
                realTime: false
            };
            var api = '/attendance-result';
            this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                // console.log(response);
                this.successList = response.data.data.success;
                this.successTotal = response.data.data.success.length;
                this.failList = response.data.data.fail;
                this.failTotal = response.data.data.fail.length;
                this.noList = response.data.data.no;
                this.noTotal = response.data.data.no.length;
            }));
        });
    }
    gotoCheckinList() {
        this.router.navigate(['/checkin/course-checkin']);
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------修改签到状态-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    makeSuccess(index, type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (type == 'no') {
                const actionSheet = yield this.actionSheetController.create({
                    mode: "ios",
                    buttons: [
                        {
                            text: '手动补签',
                            handler: () => {
                                this.timeNow = this.getTimeStr(Date.now() / 1000);
                                var param = {
                                    studentId: this.noList[index].id,
                                    attendanceId: this.checkinId,
                                    state: 0,
                                    attendanceTimeStr: this.timeNow
                                };
                                var api = '/attendance-result';
                                this.httpService.post_data(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                                    // console.log(response);
                                    if (response.data.respCode != -1) {
                                        let toast = yield this.toastController.create({
                                            message: '记录出勤成功！',
                                            duration: 2000
                                        });
                                        toast.present();
                                        this.initList();
                                    }
                                    else {
                                        let toast = yield this.toastController.create({
                                            message: '记录出勤失败！',
                                            duration: 2000
                                        });
                                        toast.present();
                                    }
                                }));
                            }
                        },
                        {
                            text: '取消',
                            role: 'destructive'
                        }
                    ]
                });
                yield actionSheet.present();
            }
            else {
                const actionSheet = yield this.actionSheetController.create({
                    mode: "ios",
                    buttons: [
                        {
                            text: '手动补签',
                            handler: () => {
                                var param = {
                                    id: this.failList[index].attendanceResultId,
                                    studentId: this.failList[index].id,
                                    attendanceId: this.checkinId,
                                    state: 0
                                };
                                this.putState(param, '出勤');
                            }
                        },
                        {
                            text: '取消',
                            role: 'destructive'
                        }
                    ]
                });
                yield actionSheet.present();
            }
        });
    }
    makeFail(index) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: "ios",
                buttons: [
                    {
                        text: '记录缺勤',
                        handler: () => {
                            var param = {
                                id: this.successList[index].attendanceResultId,
                                studentId: this.successList[index].id,
                                attendanceId: this.checkinId,
                                state: 1
                            };
                            this.putState(param, '缺勤');
                        }
                    },
                    {
                        text: '取消',
                        role: 'destructive'
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    putState(param, option) {
        var api = '/attendance-result';
        this.httpService.put(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            if (response.data.respCode != -1) {
                let toast = yield this.toastController.create({
                    message: '记录' + option + '成功！',
                    duration: 2000
                });
                toast.present();
                this.initList();
            }
            else {
                let toast = yield this.toastController.create({
                    message: '记录' + option + '失败！',
                    duration: 2000
                });
                toast.present();
            }
        }));
    }
    getTimeStr(timestamp) {
        var time = new Date(timestamp * 1000);
        var date = ((time.getFullYear()) + "-" +
            (time.getMonth() + 1).toString().padStart(2, '0') + "-" +
            (time.getDate()).toString().padStart(2, '0') + " " +
            (time.getHours()).toString().padStart(2, '0') + ":" +
            (time.getMinutes()).toString().padStart(2, '0') + ":" +
            (time.getSeconds()).toString().padStart(2, '0'));
        return date;
    }
};
CheckinResultPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__["HttpService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
CheckinResultPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-checkin-result',
        template: _raw_loader_checkin_result_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_checkin_result_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CheckinResultPage);



/***/ }),

/***/ "Gq5T":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".row-text {\n  background: #80808026;\n  width: 100%;\n  height: 40px;\n}\n\n.row-label {\n  margin: 10px 0px 0px 10px;\n}\n\n.my-thum {\n  text-align: center;\n  background-color: #7468be;\n  width: 50px;\n  height: 50px;\n  margin: auto;\n}\n\n.my-thum-image {\n  width: 50px;\n  height: 50px;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY2hlY2tpbi1yZXN1bHQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0kseUJBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0EseUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFDSjs7QUFFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtBQUNKIiwiZmlsZSI6ImNoZWNraW4tcmVzdWx0LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5yb3ctdGV4dCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjODA4MDgwMjY7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogNDBweDtcclxufVxyXG5cclxuLnJvdy1sYWJlbCB7XHJcbiAgICBtYXJnaW46IDEwcHggMHB4IDBweCAxMHB4O1xyXG59XHJcblxyXG4ubXktdGh1bXtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICM3NDY4YmU7XHJcbiAgICB3aWR0aDogNTBweDtcclxuICAgIGhlaWdodDo1MHB4O1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcblxyXG4ubXktdGh1bS1pbWFnZXtcclxuICAgIHdpZHRoOiA1MHB4O1xyXG4gICAgaGVpZ2h0OjUwcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbn0iXX0= */");

/***/ }),

/***/ "uaBc":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/checkin/checkin-result/checkin-result.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"gotoCheckinList()\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center\">签到结果</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-item-divider class=\"row-text\">\r\n      <ion-label>缺勤列表</ion-label>\r\n      <ion-note slot=\"end\" color=\"tertiary\" style=\"padding: 10px 0 0 0;font-size: 15px;margin-right: 10px;\">{{failTotal+noTotal}}人</ion-note>\r\n  </ion-item-divider>\r\n  <ion-list>\r\n      <ion-item *ngFor=\"let item of noList; let i = index\" (click)=\"makeSuccess(i, 'no')\">\r\n        <ion-avatar class=\"my-thum\" *ngIf=\"item.image!='image_null'\">\r\n            <img class=\"my-thum\" src={{item.image}}>\r\n        </ion-avatar>\r\n        <ion-avatar class=\"my-thum\" *ngIf=\"item.image=='image_null'\">\r\n            <img class=\"my-thum-image\" src=\"assets/icon/head.png\">\r\n        </ion-avatar>\r\n        <ion-label>\r\n            <h3>\r\n                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.name}}&nbsp;&nbsp;\r\n                <ion-icon *ngIf=\"item.sex=='1'\" name=\"female-outline\" style=\"color:#ed576b\"></ion-icon>\r\n                <ion-icon *ngIf=\"item.sex=='0'\" name=\"male-outline\" style=\"color:#3dc2ff\"></ion-icon>\r\n            </h3>\r\n            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.sno}}</p>\r\n        </ion-label>\r\n      </ion-item>\r\n  </ion-list>\r\n\r\n  <ion-list>\r\n    <ion-item *ngFor=\"let item of failList; let i = index\" (click)=\"makeSuccess(i, 'fail')\">\r\n      <ion-avatar class=\"my-thum\" *ngIf=\"item.image!='image_null'\">\r\n          <img class=\"my-thum\" src={{item.image}}>\r\n      </ion-avatar>\r\n      <ion-avatar class=\"my-thum\" *ngIf=\"item.image=='image_null'\">\r\n          <img class=\"my-thum-image\" src=\"assets/icon/head.png\">\r\n      </ion-avatar>\r\n      <ion-label>\r\n          <h3>\r\n              &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.name}}&nbsp;&nbsp;\r\n              <ion-icon *ngIf=\"item.sex=='1'\" name=\"female-outline\" style=\"color:#ed576b\"></ion-icon>\r\n              <ion-icon *ngIf=\"item.sex=='0'\" name=\"male-outline\" style=\"color:#3dc2ff\"></ion-icon>\r\n          </h3>\r\n          <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.sno}}</p>\r\n      </ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <ion-item-divider class=\"row-text\">\r\n      <ion-label>出勤列表</ion-label>\r\n      <ion-note slot=\"end\" color=\"tertiary\" style=\"padding: 10px 0 0 0;font-size: 15px;margin-right: 10px;\">{{successTotal}}人</ion-note>\r\n  </ion-item-divider>\r\n  <ion-list>\r\n      <ion-item *ngFor=\"let item of successList; let i = index\" (click)=\"makeFail(i)\">\r\n        \r\n        <ion-avatar class=\"my-thum\" *ngIf=\"item.image!='image_null'\">\r\n            <img class=\"my-thum\" src={{item.image}}>\r\n        </ion-avatar>\r\n        <ion-avatar class=\"my-thum\" *ngIf=\"item.image=='image_null'\">\r\n            <img class=\"my-thum-image\" src=\"assets/icon/head.png\">\r\n        </ion-avatar>\r\n        \r\n        <ion-label>\r\n            <h3>\r\n                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.name}}&nbsp;&nbsp;\r\n                <ion-icon *ngIf=\"item.sex=='1'\" name=\"female-outline\" style=\"color:#ed576b\"></ion-icon>\r\n                <ion-icon *ngIf=\"item.sex=='0'\" name=\"male-outline\" style=\"color:#3dc2ff\"></ion-icon>\r\n            </h3>\r\n            <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{{item.sno}}</p>\r\n        </ion-label>\r\n      </ion-item>\r\n\r\n  </ion-list>\r\n\r\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=checkin-result-checkin-result-module.js.map