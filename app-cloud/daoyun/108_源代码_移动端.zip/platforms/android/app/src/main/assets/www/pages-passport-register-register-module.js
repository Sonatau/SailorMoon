(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-passport-register-register-module"],{

/***/ "Ksc6":
/*!********************************************************************!*\
  !*** ./src/app/pages/passport/register/register-routing.module.ts ***!
  \********************************************************************/
/*! exports provided: RegisterPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageRoutingModule", function() { return RegisterPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./register.page */ "mzgz");




const routes = [
    {
        path: '',
        component: _register_page__WEBPACK_IMPORTED_MODULE_3__["RegisterPage"]
    }
];
let RegisterPageRoutingModule = class RegisterPageRoutingModule {
};
RegisterPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RegisterPageRoutingModule);



/***/ }),

/***/ "NxEW":
/*!************************************************************!*\
  !*** ./src/app/pages/passport/register/register.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".background {\n  height: 100%;\n  width: 100%;\n  background-image: url(\"/assets/img/login/login.png\");\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.img-tel {\n  height: 28px;\n}\n\nion-segment-button {\n  background-color: rgba(225, 225, 225, 0) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxccmVnaXN0ZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxvREFBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7QUFBSjs7QUFJQTtFQUNJLFlBQUE7QUFESjs7QUFHQTtFQUNJLG1EQUFBO0FBQUoiLCJmaWxlIjoicmVnaXN0ZXIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy/pobXpnaLog4zmma9cclxuLmJhY2tncm91bmR7XHJcbiAgICBoZWlnaHQ6MTAwJTtcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOnVybChcIi9hc3NldHMvaW1nL2xvZ2luL2xvZ2luLnBuZ1wiKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0Om5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtc2l6ZToxMDAlIDEwMCU7XHJcbn1cclxuXHJcbi8v6KGM6auY562J5p2C6aG5XHJcbi5pbWctdGVse1xyXG4gICAgaGVpZ2h0OiAyOHB4O1xyXG59XHJcbmlvbi1zZWdtZW50LWJ1dHRvbntcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMjI1LDIyNSwyMjUsMCkgIWltcG9ydGFudDtcclxufSJdfQ== */");

/***/ }),

/***/ "d+vn":
/*!************************************************************!*\
  !*** ./src/app/pages/passport/register/register.module.ts ***!
  \************************************************************/
/*! exports provided: RegisterPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPageModule", function() { return RegisterPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _register_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./register-routing.module */ "Ksc6");
/* harmony import */ var _register_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./register.page */ "mzgz");
/* harmony import */ var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/shared.module */ "PCNd");








let RegisterPageModule = class RegisterPageModule {
};
RegisterPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"],
            _register_routing_module__WEBPACK_IMPORTED_MODULE_5__["RegisterPageRoutingModule"]
        ],
        declarations: [_register_page__WEBPACK_IMPORTED_MODULE_6__["RegisterPage"]]
    })
], RegisterPageModule);



/***/ }),

/***/ "haLz":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passport/register/register.page.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/login']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">注册</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n  <div class=\"background\">\r\n    <form (ngSubmit)=\"onRegister(registerForm)\" #registerForm=\"ngForm\" novalidate>\r\n      <ion-grid>\r\n        <ion-row class=\"row\" style=\"margin-top:30px;display: block;text-align: center;\"></ion-row>\r\n        \r\n        <!-- 姓名 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"name\" type=\"text\" class=\"text_input\" placeholder=\"请输入姓名\"\r\n            [(ngModel)]=\"register_name\" #name=\"ngModel\" required>\r\n            <ion-icon name=\"person-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"name.invalid && name.touched\">\r\n            <p class=\"warn\" [hidden]=\"!email.errors?.required\" padding-start>必填：请输入姓名</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <!-- 学号/工号 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"no\" type=\"text\" class=\"text_input\" placeholder=\"请输入学号/工号\"\r\n            [(ngModel)]=\"register_no\" #no=\"ngModel\" required>\r\n            <ion-icon name=\"ribbon-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"no.invalid && no.touched\">\r\n            <p class=\"warn\" [hidden]=\"!email.errors?.required\" padding-start>必填：请输入学号/工号</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <!-- 邮箱 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"email\" type=\"text\" class=\"text_input\" placeholder=\"请输入邮箱\"\r\n            required pattern=\"\\w+@([0-9a-zA-Z]+[-0-9a-zA-Z]*)(\\.[0-9a-zA-Z]+[-0-9a-zA-Z]*)+\"\r\n            [(ngModel)]=\"register_email\" #email=\"ngModel\">\r\n            <ion-icon name=\"mail-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"email.invalid && email.touched\">\r\n            <p class=\"warn\" [hidden]=\"!email.errors?.required\" padding-start>必填：请输入邮箱地址</p>\r\n            <p class=\"warn\" [hidden]=\"!email.errors?.pattern\" padding-start>您输入的邮箱格式不正确</p>\r\n          </ion-text>\r\n        </div>\r\n        \r\n        <!-- 验证码 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"code\" type=\"text\" class=\"verify_input\" placeholder=\"请输入验证码\"\r\n          [(ngModel)]=\"verify_code\" #code=\"ngModel\" required>\r\n            <ion-icon name=\"mail-open-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n          <ion-button color=\"primary\" (click)=\"onSendSMS()\" [disabled]=\"!verifyCode.disable\">\r\n            {{verifyCode.verifyCodeTips}}</ion-button>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"code.invalid && code.touched\">\r\n            <p class=\"warn\" [hidden]=\"!code.errors?.required\" padding-start>请输入验证码</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <!-- 输入密码 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name='r_pwd' type=\"password\" class=\"text_input\" placeholder=\"请输入密码\"\r\n            required pattern=\"^(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^[^\\s\\u4e00-\\u9fa5]{6,16}$\"\r\n            [(ngModel)]=\"register_password\" #r_pwd=\"ngModel\">\r\n            <ion-icon name=\"lock-closed-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text name='pwd2' text-left color=\"danger\" *ngIf=\"r_pwd.invalid && r_pwd.touched\">\r\n            <p class=\"warn\" [hidden]=\"!r_pwd.errors?.required\" padding-start>必填：请输入密码</p>\r\n            <p class=\"warn\" [hidden]=\"!r_pwd.errors?.pattern\" padding-start>\r\n              6至16位，由数字、英文、符号三种字符类型构成，至少包含两种类型字符</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <!-- 确认密码 -->\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"v_pwd\" type=\"password\" class=\"text_input\" placeholder=\"请确认密码\"\r\n            [(ngModel)]=\"verify_password\" #v_pwd=\"ngModel\" required>\r\n            <ion-icon name=\"bag-check-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"v_pwd.invalid && v_pwd.touched\">\r\n            <p class=\"warn\" [hidden]=\"!v_pwd.errors?.required\" padding-start>必填：请再次确认您的密码</p>\r\n          </ion-text>\r\n        </div> \r\n\r\n        <!-- 身份选择 -->\r\n        <ion-radio-group name=\"role\" [(ngModel)]=\"roleID\" mode=\"md\" required>\r\n          <ion-row class=\"row\">\r\n            <ion-col>\r\n              <ion-label style=\"margin-left: 15px; font-weight: bold;\" color=\"light\">身份</ion-label>\r\n            </ion-col>\r\n            <ion-col>\r\n              <ion-radio color=\"success\" value=1></ion-radio>\r\n              <ion-label style=\"margin-left: 15px;\" color=\"light\">教师</ion-label>\r\n            </ion-col>\r\n            <ion-col>\r\n              <ion-radio color=\"warning\" value=2></ion-radio>\r\n              <ion-label style=\"margin-left: 15px;\" color=\"light\">学生</ion-label>\r\n            </ion-col>\r\n          </ion-row>\r\n        </ion-radio-group>\r\n  \r\n        <ion-row class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n            [disabled]=\"registerForm.invalid\"> 注册</ion-button>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </form>\r\n  </div>\r\n</ion-content>");

/***/ }),

/***/ "mzgz":
/*!**********************************************************!*\
  !*** ./src/app/pages/passport/register/register.page.ts ***!
  \**********************************************************/
/*! exports provided: RegisterPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RegisterPage", function() { return RegisterPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./register.page.html */ "haLz");
/* harmony import */ var _register_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./register.page.scss */ "NxEW");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let RegisterPage = class RegisterPage {
    constructor(httpService, http, router, alertController, toastController, loadingController) {
        this.httpService = httpService;
        this.http = http;
        this.router = router;
        this.alertController = alertController;
        this.toastController = toastController;
        this.loadingController = loadingController;
        this.register_email = '';
        this.register_password = '';
        this.register_name = '';
        this.register_no = '';
        this.verify_password = '';
        this.verify_code = '';
        this.return_code = -1; //1: 发送成功   -1: 发送失败
        this.register_image = "image_null";
        this.verifyCode = {
            verifyCodeTips: "获取验证码",
            countdown: 60,
            disable: true
        };
    }
    ngOnInit() {
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------获取验证码-------------------------------------//
    //----------------------------------------------------------------------------------//
    onSendSMS() {
        //请求后台发送验证码
        if (this.verifyCode.disable == true) {
            this.verifyCode.disable = false;
            this.settime();
            var params = {
                email: this.register_email,
            };
            var api = '/send-code';
            // console.log(params);
            this.httpService.get_withoutToken(api, params).then((response) => {
                // console.log(response);
                this.return_code = response.data.respCode;
                // console.log(this.return_code);
            });
        }
    }
    settime() {
        if (this.verifyCode.countdown == 1) {
            this.verifyCode.countdown = 60;
            this.verifyCode.verifyCodeTips = "获取验证码";
            this.verifyCode.disable = true;
            return;
        }
        else {
            this.verifyCode.countdown--;
        }
        this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
        setTimeout(() => {
            this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
            this.settime();
        }, 1000);
    }
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //-----------------------------------提交注册信息------------------------------------//
    //----------------------------------------------------------------------------------//
    onRegister(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '请稍等...',
            });
            yield loading.present();
            if (form.invalid) { //检验输入信息是否有效
                yield loading.dismiss();
                let toast = yield this.toastController.create({
                    message: '请输入有效信息！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                if (this.return_code == -1) { //检验是否成功发送验证码
                    yield loading.dismiss();
                    let toast = yield this.toastController.create({
                        message: '请先获取验证码！',
                        duration: 2000
                    });
                    toast.present();
                }
                else {
                    if (this.register_password != this.verify_password) {
                        yield loading.dismiss();
                        let toast = yield this.toastController.create({
                            message: '两次密码不一致！',
                            duration: 2000
                        });
                        toast.present();
                    }
                    else {
                        var api = '/register'; //-------------------------后台接口
                        var params = {
                            image: this.register_image,
                            email: this.register_email,
                            password: this.register_password,
                            name: this.register_name,
                            sno: this.register_no,
                            mailVerificationCode: this.verify_code,
                            roleId: this.roleID
                        };
                        // console.log(params);
                        this.httpService.post_withoutToken(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            yield loading.dismiss();
                            // console.log(response);
                            if (response.data.respCode == -1) {
                                let alert = yield this.alertController.create({
                                    header: '提示',
                                    message: response.data.msg,
                                    buttons: ['确定']
                                });
                                alert.present();
                            }
                            else if (response.data.respCode == 1) {
                                let alert = yield this.alertController.create({
                                    header: '提示',
                                    message: '注册成功！',
                                    buttons: [{
                                            text: '确认',
                                            cssClass: 'primary',
                                            handler: (blah) => {
                                                this.router.navigateByUrl('/login');
                                            }
                                        }]
                                });
                                alert.present();
                            }
                        }));
                    }
                }
            }
        });
    }
};
RegisterPage.ctorParameters = () => [
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
RegisterPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-register',
        template: _raw_loader_register_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_register_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], RegisterPage);



/***/ })

}]);
//# sourceMappingURL=pages-passport-register-register-module.js.map