(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-checkin-checkin-module"],{

/***/ "Eka6":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/checkin/checkin.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"gotodetail()\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">课程签到</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  \r\n  <div class=\"my-circle\" *ngIf=\"isTeacher == '1'\">\r\n      <h3 style=\"position: relative;top: 10%;\">{{checkinState}}</h3>\r\n      <h3 style=\"position: relative;top: 10%;\" *ngIf=\"checkinState=='签到中'\">{{successTotal}}/{{memberTotal}}</h3>\r\n      <h3 style=\"position: relative;top: 10%;\">{{showTime}}</h3>\r\n  </div>\r\n  <div class=\"my-circle\" *ngIf=\"isTeacher == '0'\" (click)=\"joinCheckin()\">\r\n    <h3 style=\"position: relative;top: 15%;\">{{checkinState}}</h3>\r\n    <h3 style=\"margin-top: 60px;\">{{showTime}}</h3>\r\n  </div>\r\n</ion-content>\r\n\r\n<ion-footer>\r\n  <ion-grid>\r\n    <ion-row *ngIf=\"isTeacher == '1'\">\r\n        <ion-col class=\"col-btn\" (click)=\"endCheckin(2)\">\r\n            <ion-button fill=\"clear\">结束签到</ion-button>\r\n        </ion-col>\r\n        <ion-col>\r\n            <div></div>\r\n        </ion-col>\r\n        <!-- <ion-col class=\"col-btn\" (click)=\"endCheckin(3)\">\r\n            <ion-button fill=\"clear\">取消签到</ion-button>\r\n        </ion-col> -->\r\n    </ion-row>\r\n    <ion-row *ngIf=\"isTeacher == '0'\">\r\n        <ion-col class=\"col-btn\" (click)=\"gotoMemCheck()\">\r\n            <ion-button fill=\"clear\">我的签到</ion-button>\r\n        </ion-col>\r\n        <ion-col>\r\n            <div></div>\r\n        </ion-col>\r\n        <ion-col class=\"col-btn\" (click)=\"gotoMemberList()\">\r\n            <ion-button fill=\"clear\">成员列表</ion-button>\r\n        </ion-col>\r\n    </ion-row>\r\n</ion-grid>\r\n</ion-footer>");

/***/ }),

/***/ "GPu9":
/*!*************************************************!*\
  !*** ./src/app/pages/checkin/checkin.module.ts ***!
  \*************************************************/
/*! exports provided: CheckinPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinPageModule", function() { return CheckinPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./checkin-routing.module */ "InRz");
/* harmony import */ var _checkin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./checkin.page */ "qNFx");







let CheckinPageModule = class CheckinPageModule {
};
CheckinPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__["CheckinPageRoutingModule"]
        ],
        declarations: [_checkin_page__WEBPACK_IMPORTED_MODULE_6__["CheckinPage"]]
    })
], CheckinPageModule);



/***/ }),

/***/ "InRz":
/*!*********************************************************!*\
  !*** ./src/app/pages/checkin/checkin-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: CheckinPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinPageRoutingModule", function() { return CheckinPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _checkin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./checkin.page */ "qNFx");




const routes = [
    {
        path: '',
        component: _checkin_page__WEBPACK_IMPORTED_MODULE_3__["CheckinPage"]
    },
    {
        path: 'checkin-result',
        loadChildren: () => __webpack_require__.e(/*! import() | checkin-result-checkin-result-module */ "checkin-result-checkin-result-module").then(__webpack_require__.bind(null, /*! ./checkin-result/checkin-result.module */ "+3v+")).then(m => m.CheckinResultPageModule)
    },
    {
        path: 'create-checkin',
        loadChildren: () => __webpack_require__.e(/*! import() | create-checkin-create-checkin-module */ "create-checkin-create-checkin-module").then(__webpack_require__.bind(null, /*! ./create-checkin/create-checkin.module */ "5OpY")).then(m => m.CreateCheckinPageModule)
    },
    {
        path: 'course-checkin',
        loadChildren: () => __webpack_require__.e(/*! import() | course-checkin-course-checkin-module */ "course-checkin-course-checkin-module").then(__webpack_require__.bind(null, /*! ./course-checkin/course-checkin.module */ "I5I9")).then(m => m.CourseCheckinPageModule)
    }
];
let CheckinPageRoutingModule = class CheckinPageRoutingModule {
};
CheckinPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CheckinPageRoutingModule);



/***/ }),

/***/ "pVBJ":
/*!*************************************************!*\
  !*** ./src/app/pages/checkin/checkin.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".text-pos {\n  text-align: center;\n}\n\n.col-btn {\n  text-align: center;\n}\n\n.click-btn {\n  width: 50%;\n}\n\n.my-circle {\n  min-width: 180px;\n  height: 180px;\n  text-align: center;\n  line-height: 20px;\n  color: #fff;\n  background-color: #7468be;\n  display: block;\n  position: absolute;\n  font-style: initial;\n  left: 26%;\n  top: 30%;\n  border-radius: 120px;\n  padding: 0 3px;\n  z-index: 1000;\n  font-size: 11px;\n  box-shadow: rgba(131, 118, 216, 0.644) 0px 0px 100px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjaGVja2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGtCQUFBO0FBQ0o7O0FBRUE7RUFDSSxrQkFBQTtBQUNKOztBQUVBO0VBQ0ksVUFBQTtBQUNKOztBQUVBO0VBQ0ksZ0JBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLGNBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSxvQkFBQTtFQUNBLGNBQUE7RUFDQSxhQUFBO0VBQ0EsZUFBQTtFQUNBLG9EQUFBO0FBQ0oiLCJmaWxlIjoiY2hlY2tpbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIudGV4dC1wb3Mge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG59XHJcblxyXG4uY29sLWJ0biB7XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbn1cclxuXHJcbi5jbGljay1idG4ge1xyXG4gICAgd2lkdGg6IDUwJTtcclxufVxyXG5cclxuLm15LWNpcmNsZSB7XHJcbiAgICBtaW4td2lkdGg6IDE4MHB4O1xyXG4gICAgaGVpZ2h0OiAxODBweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4gICAgY29sb3I6ICNmZmY7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjNzQ2OGJlO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICBmb250LXN0eWxlOiBpbml0aWFsO1xyXG4gICAgbGVmdDogMjYlO1xyXG4gICAgdG9wOiAzMCU7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMjBweDsgLy/orqnovrnmoYblj5jmiJDlnIblvaJcclxuICAgIHBhZGRpbmc6IDAgM3B4O1xyXG4gICAgei1pbmRleDogMTAwMDtcclxuICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIGJveC1zaGFkb3c6IHJnYmEoMTMxLCAxMTgsIDIxNiwgMC42NDQpIDBweCAwcHggMTAwcHg7IC8v6K6p6L655qGG5bim5pyJ6Zi05b2xXHJcbn0iXX0= */");

/***/ }),

/***/ "qNFx":
/*!***********************************************!*\
  !*** ./src/app/pages/checkin/checkin.page.ts ***!
  \***********************************************/
/*! exports provided: CheckinPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinPage", function() { return CheckinPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./checkin.page.html */ "Eka6");
/* harmony import */ var _checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./checkin.page.scss */ "pVBJ");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "Bfh1");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let CheckinPage = class CheckinPage {
    constructor(router, activatedRoute, alertController, httpService, geolocation, toastController) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.alertController = alertController;
        this.httpService = httpService;
        this.geolocation = geolocation;
        this.toastController = toastController;
        this.checkin = {
            id: -1,
            state: 0,
            type: -1,
            courseId: -1,
            exp: -1,
            startTimeStr: "",
            distance: -1,
            expectEndTimeStr: "",
            local: ""
        };
        this.successTotal = 0;
        this.interval = null;
        this.canleave = false;
        this.checkinState = "已结束";
        this.PI = 3.141592654;
        this.EARTH_RADIUS = 6378.137;
        this.local = [];
    }
    ngOnInit() {
        this.isTeacher = localStorage.getItem("isTeacher");
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------页面展示--------------------------------------//
    //----------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.courseCode = localStorage.getItem('courseCode');
        this.courseId = localStorage.getItem('courseId');
        this.setCheckin();
        this.memberTotal = localStorage.getItem('memberNum');
        this.successTotal = 0;
    }
    setCheckin() {
        var params = {
            courseId: this.courseId
        };
        var api = '/attendance-info';
        this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(response);
            if (response.data.respCode != -1) {
                if (response.data.data.attendance == null) {
                    this.checkinState = "已结束";
                    this.stopRequest();
                }
                else {
                    this.checkin.id = response.data.data.attendance.id;
                    this.checkin.state = response.data.data.attendance.state;
                    this.checkin.type = response.data.data.attendance.type;
                    this.checkin.courseId = response.data.data.attendance.courseId;
                    this.checkin.exp = response.data.data.attendance.exp;
                    this.checkin.startTimeStr = response.data.data.attendance.startTimeStr;
                    this.checkin.distance = response.data.data.attendance.distance;
                    this.checkin.expectEndTimeStr = response.data.data.attendance.expectEndTimeStr;
                    this.checkin.local = response.data.data.attendance.local;
                    this.checkinState = "签到中";
                    if (this.isTeacher == '0' && response.data.data.student != null) {
                        this.checkinState = "已参与";
                        this.showTime = "--:--";
                        this.stopRequest();
                    }
                    else {
                        this.startRequest();
                    }
                }
            }
        }));
    }
    ;
    //----------------------------------------------------------------------------------//
    //-----------------------------------页面跳转逻辑------------------------------------//
    //----------------------------------------------------------------------------------//
    ionViewWillLeave() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.stopRequest();
            if (this.isTeacher == '1' && this.checkinState == "签到中") {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: '有正在进行的签到！',
                    buttons: [{
                            text: '确认',
                            cssClass: 'primary',
                            handler: (blah) => {
                                this.router.navigate(['/checkin']);
                            }
                        }],
                    backdropDismiss: false
                });
                alert.present();
            }
        });
    }
    gotodetail() {
        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.courseCode } });
    }
    gotoMemCheck() {
        this.router.navigate(['/member-list/member-checkin'], { queryParams: { stuId: localStorage.getItem('UserId') } });
    }
    gotoMemberList() {
        this.router.navigate(['/member-list']);
    }
    //----------------------------------------------------------------------------------//
    //-----------------------------------签到状态轮询------------------------------------//
    //----------------------------------------------------------------------------------//
    getCheckResult() {
        var params = {
            attendanceId: this.checkin.id,
            realTime: true
        };
        var api = '/attendance-result';
        this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(response.data);
            this.successTotal = response.data.data.total;
            this.checkin.state = response.data.data.state;
            if (this.checkin.state != 0) {
                this.setCheckin();
            }
        }));
        this.timeNow = this.getTimeStr(Date.now() / 1000);
        if (this.checkin.type == 1) {
            var sec = Number(this.getTimeStamp(this.checkin.expectEndTimeStr)) - Number(this.getTimeStamp(this.timeNow));
            this.showTime = Math.trunc((sec / 60)).toString().padStart(2, '0') + ':' + (sec % 60).toString().padStart(2, '0');
            if (sec <= 0 && this.checkin.state == 0) {
                this.endCheckin(1);
            }
        }
        else {
            this.showTime = this.timeNow.split(' ');
            this.showTime = this.showTime[1];
        }
    }
    startRequest() {
        if (this.interval != null) { //判断计时器是否为空
            clearInterval(this.interval);
            this.interval = null;
        }
        this.interval = setInterval(() => {
            this.getCheckResult();
        }, 1000);
    }
    stopRequest() {
        clearInterval(this.interval);
        this.interval = null;
    }
    getTimeStr(timestamp) {
        var time = new Date(timestamp * 1000);
        var date = ((time.getFullYear()) + "-" +
            (time.getMonth() + 1).toString().padStart(2, '0') + "-" +
            (time.getDate()).toString().padStart(2, '0') + " " +
            (time.getHours()).toString().padStart(2, '0') + ":" +
            (time.getMinutes()).toString().padStart(2, '0') + ":" +
            (time.getSeconds()).toString().padStart(2, '0'));
        return date;
    }
    getTimeStamp(dateStr) {
        dateStr = dateStr.substring(0, 19);
        dateStr = dateStr.replace(/-/g, '/');
        var timeTamp = new Date(dateStr).getTime() / 1000;
        return timeTamp;
    }
    //----------------------------------------------------------------------------------//
    //-----------------------------------签到功能逻辑------------------------------------//
    //----------------------------------------------------------------------------------//
    joinCheckin() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.checkinState == "签到中") {
                if (this.checkin.type == 0) { //定位签到
                    //获取当前定位
                    this.geolocation.getCurrentPosition().then((resp) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                        this.local[0] = resp.coords.latitude;
                        this.local[1] = resp.coords.longitude;
                        var teacher_loc = this.checkin.local.split('-');
                        //计算距离
                        var a = Math.abs(this.Rad(Number(teacher_loc[0])) - this.Rad(Number(this.local[0])));
                        var b = Math.abs(this.Rad(Number(teacher_loc[1])) - this.Rad(Number(this.local[1])));
                        this.dis = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2)
                            + Math.cos(this.Rad(Number(teacher_loc[0]))) * Math.cos(this.Rad(Number(this.local[0]))) * Math.pow(Math.sin(b / 2), 2)));
                        this.dis = this.dis * this.EARTH_RADIUS * 1000;
                        // console.log(this.local);
                        // console.log(teacher_loc);
                        // console.log(this.dis);
                        if (this.dis <= this.checkin.distance) {
                            var param_0 = {
                                studentId: localStorage.getItem('UserId'),
                                attendanceId: this.checkin.id,
                                state: 0,
                                attendanceTimeStr: this.timeNow
                            };
                            this.postCheckin(param_0);
                        }
                        else {
                            let toast = yield this.toastController.create({
                                message: '超出签到范围！',
                                duration: 2000
                            });
                            toast.present();
                        }
                    })).catch((error) => {
                        alert('Error getting location' + error);
                    });
                }
                else if (this.checkin.type == 1) { //限时签到
                    var checkinTime = this.timeNow;
                    if (this.getTimeStamp(this.timeNow) <= this.getTimeStamp(this.checkin.expectEndTimeStr)) {
                        var param_1 = {
                            studentId: localStorage.getItem('UserId'),
                            attendanceId: this.checkin.id,
                            state: 0,
                            attendanceTimeStr: checkinTime
                        };
                        this.postCheckin(param_1);
                    }
                    else {
                        let toast = yield this.toastController.create({
                            message: '签到超时！',
                            duration: 2000
                        });
                        toast.present();
                    }
                }
            }
        });
    }
    Rad(d) {
        return d * this.PI / 180.0;
    }
    postCheckin(param) {
        var api = "/attendance-result";
        this.httpService.post_data(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(response);
            if (response.data.respCode != -1) {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: '签到成功！',
                    buttons: [{
                            text: '确认',
                            cssClass: 'primary',
                        }],
                });
                alert.present();
                this.setCheckin();
            }
        }));
    }
    endCheckin(endType) {
        var param = {
            id: this.checkin.id,
            type: endType
        };
        var api = "/attendance";
        this.httpService.delete(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(response);
            if (response.data.respCode != -1) {
                this.stopRequest();
                this.setCheckin();
            }
            else {
                let toast = yield this.toastController.create({
                    message: '该签到已结束，请勿重复操作！',
                    duration: 2000
                });
                toast.present();
            }
        }));
    }
};
CheckinPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_5__["Geolocation"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
CheckinPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-checkin',
        template: _raw_loader_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CheckinPage);



/***/ })

}]);
//# sourceMappingURL=pages-checkin-checkin-module.js.map