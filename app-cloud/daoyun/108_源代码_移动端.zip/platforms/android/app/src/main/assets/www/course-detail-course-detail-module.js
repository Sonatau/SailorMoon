(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["course-detail-course-detail-module"],{

/***/ "/PYT":
/*!****************************************************************************!*\
  !*** ./src/app/pages/course/course-detail/course-detail-routing.module.ts ***!
  \****************************************************************************/
/*! exports provided: CourseDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseDetailPageRoutingModule", function() { return CourseDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _course_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./course-detail.page */ "Wezu");




const routes = [
    {
        path: '',
        component: _course_detail_page__WEBPACK_IMPORTED_MODULE_3__["CourseDetailPage"]
    }
];
let CourseDetailPageRoutingModule = class CourseDetailPageRoutingModule {
};
CourseDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CourseDetailPageRoutingModule);



/***/ }),

/***/ "FQSf":
/*!********************************************************************!*\
  !*** ./src/app/pages/course/course-detail/course-detail.page.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".row {\n  height: 50px;\n  width: 100%;\n}\n\n.btn-exit {\n  border: solid 1px red;\n}\n\n.lesson-row {\n  margin: auto;\n  width: 100%;\n  margin-top: 20px;\n  width: 90%;\n  border-radius: 10px;\n}\n\n.lesson-btn {\n  margin: auto;\n  width: 80%;\n}\n\n.my_textarea {\n  width: 90%;\n  height: 100px;\n  overflow: visible;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY291cnNlLWRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtBQUNKOztBQUVBO0VBQ0kscUJBQUE7QUFDSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZ0JBQUE7RUFDQSxVQUFBO0VBQ0EsbUJBQUE7QUFDSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxVQUFBO0FBQ0o7O0FBR0E7RUFDSSxVQUFBO0VBQ0EsYUFBQTtFQUNBLGlCQUFBO0FBQUoiLCJmaWxlIjoiY291cnNlLWRldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucm93IHtcclxuICAgIGhlaWdodDogNTBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG59XHJcblxyXG4uYnRuLWV4aXQge1xyXG4gICAgYm9yZGVyOiBzb2xpZCAxcHggcmVkO1xyXG59XHJcblxyXG4ubGVzc29uLXJvdyB7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxufVxyXG5cclxuLmxlc3Nvbi1idG4ge1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgd2lkdGg6IDgwJTtcclxuICAgIC8vIGhlaWdodDogLXdlYmtpdC1maWxsLWF2YWlsYWJsZTtcclxufVxyXG5cclxuLm15X3RleHRhcmVhe1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICBvdmVyZmxvdzogdmlzaWJsZTtcclxufSJdfQ== */");

/***/ }),

/***/ "TqLA":
/*!********************************************************************!*\
  !*** ./src/app/pages/course/course-detail/course-detail.module.ts ***!
  \********************************************************************/
/*! exports provided: CourseDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseDetailPageModule", function() { return CourseDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _course_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./course-detail-routing.module */ "/PYT");
/* harmony import */ var _course_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./course-detail.page */ "Wezu");







let CourseDetailPageModule = class CourseDetailPageModule {
};
CourseDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _course_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["CourseDetailPageRoutingModule"]
        ],
        declarations: [_course_detail_page__WEBPACK_IMPORTED_MODULE_6__["CourseDetailPage"]]
    })
], CourseDetailPageModule);



/***/ }),

/***/ "Wezu":
/*!******************************************************************!*\
  !*** ./src/app/pages/course/course-detail/course-detail.page.ts ***!
  \******************************************************************/
/*! exports provided: CourseDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CourseDetailPage", function() { return CourseDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course-detail.page.html */ "u8v9");
/* harmony import */ var _course_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course-detail.page.scss */ "FQSf");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_event_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/event.service */ "6BoG");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");
/* harmony import */ var _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/geolocation/ngx */ "Bfh1");










let CourseDetailPage = class CourseDetailPage {
    constructor(router, httpService, http, activatedRoute, pickerController, alertController, loadingController, nav, eventService, actionSheetController, geolocation) {
        this.router = router;
        this.httpService = httpService;
        this.http = http;
        this.activatedRoute = activatedRoute;
        this.pickerController = pickerController;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.nav = nav;
        this.eventService = eventService;
        this.actionSheetController = actionSheetController;
        this.geolocation = geolocation;
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------初始信息展示-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ngOnInit() {
        this.course = this.initCourse();
        this.isTeacher = localStorage.getItem("isTeacher");
        this.course_admin = localStorage.getItem("course-admin");
        this.checkin_admin = localStorage.getItem("checkin-admin");
    }
    ionViewWillEnter() {
        this.code = this.activatedRoute.snapshot.queryParams['code'];
        this.inCourse = true;
        this.isTeacher = localStorage.getItem("isTeacher");
        this.course_admin = localStorage.getItem("course-admin");
        this.checkin_admin = localStorage.getItem("checkin-admin");
        this.setCourse();
        // console.log('course_detail-ionViewWillEnter');
    }
    ionViewWillLeave() {
        this.eventService.eventEmit.emit('detail-change', '详情页返回');
    }
    /**
     * 初始化班课信息
     * @returns {Course}
     */
    initCourse() {
        return {
            id: -1,
            cover: "",
            code: "",
            name: "",
            school: "",
            academy: "",
            teacher: "",
            schoolId: -1,
            academyId: -1,
            teacherId: -1,
            term: "",
            termId: -1,
            join: true,
            status: true,
            lesson: "",
            lessonId: -1,
        };
    }
    setCourse() {
        //先判断是自己的班课吗
        this.course.cover = "image_null";
        this.course.code = this.code;
        var param_in = {
            name: this.code,
            page: 1,
            isSelf: this.inCourse
        };
        var api = '/course';
        this.httpService.get(api, param_in).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            if (response.data.data.total == 0) {
                this.inCourse = false;
                this.setCourse();
            }
            else if (response.data.data.total != 0) {
                this.course.id = response.data.data.list[0].id;
                this.course.name = response.data.data.list[0].name;
                this.course.lesson = response.data.data.list[0].lesson;
                this.course.school = response.data.data.list[0].school;
                this.course.academy = response.data.data.list[0].academy;
                this.course.teacher = response.data.data.list[0].teacher;
                this.course.term = response.data.data.list[0].term;
                this.course.cover = response.data.data.list[0].image;
                this.course.join = response.data.data.list[0].okJoin;
                this.course.status = response.data.data.list[0].state;
                this.saveData();
            }
            else {
                const alert = yield this.alertController.create({
                    message: '班课号错误！',
                    buttons: [{
                            text: "确认",
                            handler: () => {
                                this.gotoCourse();
                            }
                        }]
                });
                yield alert.present();
            }
        }));
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //----------------------------------------------------一些跳转&删除----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    gotoQRcode() {
        this.router.navigate(['/course/create-success']);
    }
    gotoEdit() {
        this.router.navigate(['/course/edit-detail']);
    }
    gotoCourse() {
        this.router.navigate(['/tabs/course']);
    }
    gotoMemberList() {
        this.router.navigate(['/member-list']);
    }
    gotoCheckinList() {
        this.router.navigate(['/checkin/course-checkin']);
    }
    deleteLesson() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: '提示',
                message: '是否确认删除？',
                buttons: [
                    {
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'medium'
                    },
                    {
                        text: '确认',
                        handler: () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            var params = {
                                id: this.course.id
                            };
                            var api = '/course';
                            this.httpService.delete(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                                // console.log(response);
                                const alert = yield this.alertController.create({
                                    message: '删除成功！',
                                    buttons: [{
                                            text: "确认",
                                            handler: () => {
                                                this.gotoCourse();
                                            }
                                        }]
                                });
                                yield alert.present();
                            }));
                        })
                    }
                ]
            });
            yield alert.present();
        });
    }
    outLesson() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: '提示',
                message: '是否确认退出？',
                buttons: [
                    {
                        text: '取消',
                        role: 'cancel',
                        cssClass: 'medium'
                    },
                    {
                        text: '确认',
                        handler: () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            var params = {
                                id: this.course.id
                            };
                            var api = '/course-member';
                            this.httpService.delete(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                                if (response.data.respCode == 1) {
                                    const alert = yield this.alertController.create({
                                        header: '提示',
                                        message: '退出成功！',
                                        buttons: [{
                                                text: "确认",
                                                handler: () => {
                                                    this.gotoCourse();
                                                }
                                            }]
                                    });
                                    yield alert.present();
                                }
                            }));
                        })
                    }
                ]
            });
            yield alert.present();
        });
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //----------------------------------------------------加入&状态更新----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    updateCourse() {
        var params = {
            id: this.course.id,
            name: this.course.name,
            okJoin: this.course.join,
            state: this.course.status
        };
        var api = '/course';
        this.httpService.put(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
        }));
    }
    joinLesson() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '请稍等...',
            });
            yield loading.present();
            if (this.course.join == false) {
                yield loading.dismiss();
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: "该班课不允许加入",
                    buttons: ['确定']
                });
                alert.present();
            }
            else if (this.course.status == false) {
                yield loading.dismiss();
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: "该班课已结束",
                    buttons: ['确定']
                });
                alert.present();
            }
            else {
                var api = '/course-member'; //-------------------------后台接口
                var params = {
                    code: this.course.code
                };
                this.httpService.post_params(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    // console.log(response);
                    if (response.data.respCode == -1) {
                        let alert = yield this.alertController.create({
                            header: '提示',
                            message: response.data.msg,
                            buttons: ['确定']
                        });
                        alert.present();
                    }
                    else if (response.data.respCode == 1) {
                        let alert = yield this.alertController.create({
                            header: '提示',
                            message: '加入成功！',
                            buttons: [{
                                    text: '确认',
                                    cssClass: 'primary',
                                    handler: (blah) => {
                                        this.inCourse = true;
                                    }
                                }]
                        });
                        alert.present();
                    }
                }));
            }
        });
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------------------签到相关部分----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    createCheckin() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                mode: "ios",
                buttons: [
                    // {
                    //   text: '口令签到',   //type2
                    //   handler: () => {
                    //     this.router.navigate(['/checkin/create-checkin'], {queryParams:{type: 2, code: this.code, id: this.course.id} });
                    //   }
                    // },
                    {
                        text: '定位签到',
                        handler: () => {
                            this.geolocation.getCurrentPosition().then((resp) => {
                                var local = resp.coords.latitude + '-' + resp.coords.longitude;
                                var beginStr = this.getTimeStr(Date.now() / 1000);
                                var param_0 = {
                                    type: 0,
                                    courseId: this.course.id,
                                    startTimeStr: beginStr,
                                    local: local
                                };
                                this.post(param_0);
                            }).catch((error) => {
                                alert('Error getting location' + error);
                            });
                        }
                    },
                    {
                        text: '限时签到',
                        handler: () => {
                            this.router.navigate(['/checkin/create-checkin']);
                        }
                    },
                    {
                        text: '取消',
                        role: 'destructive'
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    post(param) {
        var api = '/attendance';
        // console.log(param);
        this.httpService.post_data(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            if (response.data.respCode == 1) {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: '签到发起成功！',
                    buttons: [{
                            text: '确认',
                            cssClass: 'primary',
                            handler: (blah) => {
                                this.router.navigate(['/checkin']);
                            }
                        }]
                });
                alert.present();
            }
            else {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: "签到发起失败！",
                    buttons: ['确定']
                });
                alert.present();
            }
        }));
    }
    gotoCheckin() {
        this.router.navigate(['/checkin']);
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------JS时间转换-------------------------------------//
    //----------------------------------------------------------------------------------//
    getTimeStr(timestamp) {
        var time = new Date(timestamp * 1000);
        var date = ((time.getFullYear()) + "-" +
            (time.getMonth() + 1).toString().padStart(2, '0') + "-" +
            (time.getDate()).toString().padStart(2, '0') + " " +
            (time.getHours()).toString().padStart(2, '0') + ":" +
            (time.getMinutes()).toString().padStart(2, '0') + ":" +
            (time.getSeconds()).toString().padStart(2, '0'));
        return date;
    }
    //----------------------------------------------------------------------------------//
    //-----------------------------------预存班课数据------------------------------------//
    //----------------------------------------------------------------------------------//
    saveData() {
        localStorage.setItem('courseCode', this.course.code);
        localStorage.setItem('courseId', this.course.id.toString());
        localStorage.setItem('courseName', this.course.name);
        //获取成员数
        var param = {
            courseId: this.course.id
        };
        var api = '/course-member';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            localStorage.setItem('memberNum', response.data.data.total);
        }));
        // console.log(this.inCourse);
        if (this.isTeacher == '1' && this.inCourse == true) {
            var params = {
                courseId: this.course.id
            };
            var api = '/attendance-info';
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                // console.log(response);
                if (response.data.data.attendance != null) {
                    let alert = yield this.alertController.create({
                        header: '提示',
                        message: '有正在进行的签到！',
                        buttons: [{
                                text: '确认',
                                cssClass: 'primary',
                                handler: (blah) => {
                                    this.router.navigate(['/checkin']);
                                }
                            }],
                        backdropDismiss: false
                    });
                    alert.present();
                }
            }));
        }
    }
};
CourseDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_8__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PickerController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"] },
    { type: src_app_shared_services_event_service__WEBPACK_IMPORTED_MODULE_7__["EventService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] },
    { type: _ionic_native_geolocation_ngx__WEBPACK_IMPORTED_MODULE_9__["Geolocation"] }
];
CourseDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-course-detail',
        template: _raw_loader_course_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CourseDetailPage);



/***/ }),

/***/ "u8v9":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/course-detail/course-detail.page.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"light\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"gotoCourse()\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">班课详情</ion-title>\r\n\r\n      <ion-buttons slot=\"end\" *ngIf=\"isTeacher=='0' && inCourse==true\">\r\n        <ion-button color=\"light\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"outLesson()\">\r\n            <ion-icon name=\"log-out-outline\"></ion-icon>\r\n        </ion-button>\r\n    </ion-buttons>\r\n\r\n    <ion-buttons slot=\"end\" *ngIf=\"isTeacher == '1'\">\r\n        <ion-button color=\"light\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"deleteLesson()\">\r\n            <ion-icon name=\"trash-outline\"></ion-icon>\r\n        </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n\r\n  <ion-toolbar style=\"--background:linear-gradient(#7468BE 0%,#7468BE 60%,white 60%,white 100%);--border-width: 0 0 0px;\">\r\n      <ion-card mode=\"ios\">\r\n        <ion-row style=\"margin-top:10px;\"></ion-row>\r\n\r\n          <ion-item lines=\"none\">\r\n              <ion-thumbnail class=\"thum\" *ngIf=\"course.cover != 'image_null'\">\r\n                <img src={{course.cover}}>\r\n              </ion-thumbnail>\r\n              <ion-thumbnail class=\"thum\" *ngIf=\"course.cover == 'image_null'\">\r\n                <img src=\"assets/img/course/cover-default.jpg\">\r\n              </ion-thumbnail>\r\n              <ion-label>\r\n                  <h3 style=\"color: #7468BE; font-size: 18px;\">&nbsp;&nbsp;{{course.name}}</h3>\r\n                  <h5>&nbsp;&nbsp;&nbsp;老师：{{course.teacher}}</h5>\r\n                  <h5>&nbsp;&nbsp;&nbsp;学期：{{course.term}}</h5>\r\n              </ion-label>\r\n              <ion-button *ngIf=\"course_admin == 1\" fill=\"clear\" (click)=\"gotoEdit()\" style=\"margin-top: -40px; width: 30px;\">\r\n                  <ion-icon slot=\"icon-only\" name=\"create-outline\"></ion-icon>\r\n              </ion-button>\r\n          </ion-item>\r\n\r\n        <ion-row style=\"margin-block-end:10px;\"></ion-row>\r\n      </ion-card>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n  <ion-list>\r\n    <ion-item lines=\"none\">\r\n        <ion-label slot=\"start\">\r\n            <p>班课号</p>\r\n        </ion-label>\r\n        <ion-label slot=\"end\">\r\n            <p>{{course.code}}</p>\r\n        </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\" (click)=\"gotoQRcode()\">\r\n        <ion-label slot=\"start\">\r\n            <p>班课二维码</p>\r\n        </ion-label>\r\n        <ion-icon slot=\"end\" name=\"qr-code-outline\" style=\"color: gray;\"></ion-icon>\r\n        <ion-icon slot=\"end\" name=\"chevron-forward-outline\" style=\"color:#7468be;\"></ion-icon>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\" *ngIf=\"isTeacher=='0'\">\r\n        <ion-label slot=\"start\">允许加入</ion-label>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\" *ngIf=\"course.join=='1'\">是</ion-note>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\" *ngIf=\"course.join=='0'\">否</ion-note>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\" *ngIf=\"isTeacher=='1'\">\r\n        <ion-label slot=\"start\">允许加入</ion-label>\r\n        <ion-label slot=\"end\">\r\n            <ion-toggle color=\"primary\" (ionChange)=\"updateCourse()\" [(ngModel)]=\"course.join\"></ion-toggle>\r\n        </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\" *ngIf=\"isTeacher=='0'\">\r\n        <ion-label slot=\"start\">班课状态</ion-label>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\" *ngIf=\"course.status=='1'\">开课中</ion-note>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\" *ngIf=\"course.status=='0'\">已结课</ion-note>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\" *ngIf=\"isTeacher=='1'\">\r\n        <ion-label slot=\"start\">班课状态</ion-label>\r\n        <ion-label slot=\"end\">\r\n            <ion-toggle color=\"primary\" (ionChange)=\"updateCourse()\" [(ngModel)]=\"course.status\"></ion-toggle>\r\n        </ion-label>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\">\r\n        <ion-label slot=\"start\">对应课程</ion-label>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\">{{course.lesson}}</ion-note>\r\n    </ion-item>\r\n\r\n    <ion-item lines=\"none\">\r\n        <ion-label slot=\"start\">开设学校</ion-label>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\">{{course.school}}</ion-note>\r\n    </ion-item>\r\n  \r\n    <ion-item lines=\"none\">\r\n        <ion-label slot=\"start\">开设学院</ion-label>\r\n        <ion-note class=\"my_inf\" slot=\"end\" color=\"medium\">{{course.academy}}</ion-note>\r\n    </ion-item>\r\n  </ion-list>\r\n\r\n  <ion-item *ngIf=\"isTeacher=='0' && inCourse==false\" class=\"lesson-row\" lines=\"none\" style=\"border:solid 1px #7468be;\">\r\n    <ion-button class=\"lesson-btn\" fill=\"clear\" style=\"color: #7468be\" (click)=\"joinLesson()\">加入班课</ion-button>\r\n  </ion-item>\r\n<ion-item class=\"lesson-row\" lines=\"none\" style=\"border:solid 1px #7468be;\" *ngIf=\"inCourse==true\">\r\n    <ion-button class=\"lesson-btn\" fill=\"clear\" style=\"color:#7468be\" (click)=\"gotoMemberList()\">成员列表</ion-button>\r\n</ion-item>\r\n\r\n<ion-item *ngIf=\"isTeacher=='1' && inCourse==true\" class=\"lesson-row\" lines=\"none\" style=\"border:solid 1px green;\">\r\n    <ion-button class=\"lesson-btn\" fill=\"clear\" style=\"color:green\" (click)=\"createCheckin()\">发起签到</ion-button>\r\n</ion-item>\r\n<ion-item *ngIf=\"isTeacher=='0' && inCourse==true\" class=\"lesson-row\" lines=\"none\" style=\"border:solid 1px green;\">\r\n  <ion-button class=\"lesson-btn\" fill=\"clear\" style=\"color:green\" (click)=\"gotoCheckin()\">参与签到</ion-button>\r\n</ion-item>\r\n\r\n<ion-item *ngIf=\"checkin_admin=='1' && inCourse==true\" class=\"lesson-row\" lines=\"none\" style=\"border:solid 1px blue;\">\r\n    <ion-button class=\"lesson-btn\" fill=\"clear\" style=\"color:blue\" (click)=\"gotoCheckinList()\">签到历史</ion-button>\r\n</ion-item>\r\n<ion-item *ngIf=\"isTeacher=='0' && inCourse==true\" class=\"lesson-row\" lines=\"none\" style=\"border:solid 1px blue;\">\r\n    <ion-button class=\"lesson-btn\" fill=\"clear\" style=\"color:blue\" [routerLink]=\"['/member-list/member-checkin']\">签到记录</ion-button>\r\n</ion-item>\r\n\r\n\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=course-detail-course-detail-module.js.map