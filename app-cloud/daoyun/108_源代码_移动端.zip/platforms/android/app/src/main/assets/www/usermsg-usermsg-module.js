(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["usermsg-usermsg-module"],{

/***/ "1jLg":
/*!**************************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: UsermsgPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsermsgPageRoutingModule", function() { return UsermsgPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _usermsg_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./usermsg.page */ "w++B");




const routes = [
    {
        path: '',
        component: _usermsg_page__WEBPACK_IMPORTED_MODULE_3__["UsermsgPage"]
    }
];
let UsermsgPageRoutingModule = class UsermsgPageRoutingModule {
};
UsermsgPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UsermsgPageRoutingModule);



/***/ }),

/***/ "BFBO":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mine/usermsg/usermsg.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n        <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/tabs/mine']\">\r\n            <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n        </ion-button>\r\n    </ion-buttons>\r\n\r\n      <ion-title style=\"text-align:center;\">我的信息</ion-title>\r\n\r\n      <ion-buttons slot=\"end\">\r\n        <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/mine/edit-usermsg']\">\r\n            <ion-icon slot=\"end\" name=\"create-outline\"></ion-icon>\r\n        </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-list lines=\"full\">\r\n    <ion-grid>\r\n        <!-- <ion-card mode=\"ios\">\r\n            <ion-item lines=\"none\" style=\"margin-top: 10px;\">\r\n                <ion-avatar class=\"my-thum\" *ngIf=\"user.image!='image_null'\">\r\n                    <img class=\"my-thum\" src={{user.image}}>\r\n                </ion-avatar>\r\n                <ion-avatar class=\"my-thum\" *ngIf=\"user.image=='image_null'\">\r\n                    <img class=\"my-thum-image\" src=\"../../../../assets/icon/head.png\">\r\n                </ion-avatar>\r\n            </ion-item>\r\n            <ion-item lines=\"none\">\r\n                <ion-label style=\"text-align: center; margin-top: 8px; color: #7468be;\">\r\n                    用户身份：{{role}}</ion-label>\r\n            </ion-item>\r\n            <ion-item lines=\"none\" *ngIf=\"role=='学生'\">\r\n                <ion-label style=\"text-align: center; color: black;\">\r\n                    总经验值：{{user.exp}}</ion-label>\r\n            </ion-item>\r\n        </ion-card> -->\r\n        <ion-card mode=\"ios\">\r\n            <ion-grid>\r\n                <ion-row style=\"width:100%;height:10px\"></ion-row>\r\n                <ion-row>\r\n                    <ion-col size=\"4\">\r\n                        <ion-avatar class=\"my-thum\" *ngIf=\"user.image!='image_null'\">\r\n                          <img class=\"my-thum\" src={{user.image}}>\r\n                        </ion-avatar>\r\n                        <ion-avatar class=\"my-thum\" *ngIf=\"user.image=='image_null'\">\r\n                          <img class=\"my-thum-image\" src=\"assets/icon/head.png\">\r\n                        </ion-avatar>\r\n                    </ion-col>\r\n                    <ion-col size=\"8\">\r\n                      <ion-row style=\"width:100%\" *ngIf=\"role=='学生'\">\r\n                        <ion-label>\r\n                          <p style=\"color:#7468be; font-size: 18px; font-weight: 700;\">{{user.name}}</p>\r\n                          <p style=\"color:black; font-size: 16px; font-weight: 500;\">用户身份：{{role}}</p>\r\n                          <p style=\"color:black; font-size: 16px; font-weight: 500;\">总经验值：{{user.exp}}</p>\r\n                        </ion-label>\r\n                      </ion-row>\r\n                      <ion-row style=\"width:100%; margin-top: 15px;\" *ngIf=\"role=='老师'\">\r\n                        <ion-label>\r\n                            <p style=\"color:#7468be; font-size: 18px; font-weight: 700;\">{{user.name}}</p>\r\n                            <p style=\"color:black; font-size: 16px; font-weight: 500;\">用户身份：{{role}}</p>\r\n                        </ion-label>\r\n                      </ion-row>\r\n                    </ion-col>\r\n                </ion-row>\r\n            </ion-grid>\r\n            <ion-row style=\"width:100%;height:10px\"></ion-row>\r\n        </ion-card>\r\n    \r\n        <ion-item>\r\n            <ion-label>邮箱</ion-label>\r\n            <ion-note class=\"my_inf\" slot=\"end\" type=\"text\" style=\"color: #808080\">{{user.email}}</ion-note>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-label>手机号</ion-label>\r\n            <ion-note class=\"my_inf\" slot=\"end\" type=\"text\" style=\"color: #808080\">{{user.telephone}}</ion-note>\r\n        </ion-item>\r\n    \r\n        <!-- <ion-item>\r\n            <ion-label>姓名</ion-label>\r\n            <ion-note class=\"my_inf\" slot=\"end\" type=\"text\" style=\"color: #808080\">{{user.name}}</ion-note>\r\n        </ion-item> -->\r\n        <ion-item>\r\n            <ion-label>学号</ion-label>\r\n            <ion-note class=\"my_inf\" slot=\"end\" type=\"text\" style=\"color: #808080\">{{user.sno}}</ion-note>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-label>性别</ion-label>\r\n            <ion-note class=\"my_inf\" slot=\"end\" type=\"text\" style=\"color: #808080\">{{user.sex}}</ion-note>\r\n        </ion-item>\r\n        <ion-item>\r\n            <ion-label>学校</ion-label>\r\n            <ion-note class=\"my_inf\" slot=\"end\" type=\"text\" style=\"color: #808080\">{{user.school}}</ion-note>\r\n        </ion-item>\r\n\r\n    </ion-grid>\r\n  </ion-list>\r\n</ion-content>\r\n");

/***/ }),

/***/ "P8kf":
/*!******************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg.module.ts ***!
  \******************************************************/
/*! exports provided: UsermsgPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsermsgPageModule", function() { return UsermsgPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _usermsg_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./usermsg-routing.module */ "1jLg");
/* harmony import */ var _usermsg_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./usermsg.page */ "w++B");







let UsermsgPageModule = class UsermsgPageModule {
};
UsermsgPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _usermsg_routing_module__WEBPACK_IMPORTED_MODULE_5__["UsermsgPageRoutingModule"]
        ],
        declarations: [_usermsg_page__WEBPACK_IMPORTED_MODULE_6__["UsermsgPage"]]
    })
], UsermsgPageModule);



/***/ }),

/***/ "d8Zw":
/*!******************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".my-thum {\n  text-align: center;\n  background-color: #7468be;\n  width: 80px;\n  height: 80px;\n  margin: auto;\n}\n\n.my-thum-image {\n  width: 80px;\n  height: 80px;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdXNlcm1zZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLHlCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7QUFDSiIsImZpbGUiOiJ1c2VybXNnLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5teS10aHVte1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzc0NjhiZTtcclxuICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgaGVpZ2h0OjgwcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbn1cclxuXHJcbi5teS10aHVtLWltYWdle1xyXG4gICAgd2lkdGg6IDgwcHg7XHJcbiAgICBoZWlnaHQ6ODBweDtcclxuICAgIG1hcmdpbjogYXV0bztcclxufSJdfQ== */");

/***/ }),

/***/ "w++B":
/*!****************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg.page.ts ***!
  \****************************************************/
/*! exports provided: UsermsgPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsermsgPage", function() { return UsermsgPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_usermsg_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./usermsg.page.html */ "BFBO");
/* harmony import */ var _usermsg_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usermsg.page.scss */ "d8Zw");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_event_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/event.service */ "6BoG");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");









let UsermsgPage = class UsermsgPage {
    constructor(router, httpService, http, pickerController, toast, loadingController, eventService) {
        this.router = router;
        this.httpService = httpService;
        this.http = http;
        this.pickerController = pickerController;
        this.toast = toast;
        this.loadingController = loadingController;
        this.eventService = eventService;
        this.user = {
            image: "image_null",
            email: "未设置",
            exp: 0,
            id: -1,
            loginType: -1,
            name: "",
            school: "",
            schoolId: -1,
            sex: "",
            sno: "",
            telephone: "未设置",
            password: null
        };
        this.return_flag = 0;
        this.eventService.eventEmit.on('user-detail-change', () => {
            // console.log('usermsg-eventListener');
            this.initUserInfo();
            this.return_flag = 1;
        });
    }
    ngOnInit() {
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------------------页面信息展示----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        if (this.return_flag == 0) {
            this.initUserInfo();
        }
    }
    ionViewWillLeave() {
        this.eventService.eventEmit.emit('msg-change', '用户信息页返回');
    }
    initUserInfo() {
        //getUserInfo
        var api = '/userinfo'; //后台接口
        var params = {};
        this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response);
            if (response.data.data.user.email != null) {
                this.user.email = response.data.data.user.email;
            }
            if (response.data.data.user.telephone != null) {
                this.user.telephone = response.data.data.user.telephone;
            }
            this.user.image = response.data.data.user.image;
            this.user.name = response.data.data.user.name;
            this.user.sno = response.data.data.user.sno;
            if (response.data.data.user.sex == 1) {
                this.user.sex = '女';
            }
            else {
                this.user.sex = '男';
            }
            this.user.school = response.data.data.user.school;
            this.user.exp = response.data.data.user.exp;
        }));
        if (localStorage.getItem('isTeacher') == '1') {
            this.role = '老师';
        }
        else {
            this.role = '学生';
        }
    }
};
UsermsgPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_8__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PickerController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: src_app_shared_services_event_service__WEBPACK_IMPORTED_MODULE_7__["EventService"] }
];
UsermsgPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-usermsg',
        template: _raw_loader_usermsg_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_usermsg_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], UsermsgPage);



/***/ })

}]);
//# sourceMappingURL=usermsg-usermsg-module.js.map