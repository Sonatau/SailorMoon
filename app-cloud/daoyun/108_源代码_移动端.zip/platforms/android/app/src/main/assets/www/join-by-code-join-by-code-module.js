(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["join-by-code-join-by-code-module"],{

/***/ "HVfY":
/*!****************************************************************!*\
  !*** ./src/app/pages/course/join-by-code/join-by-code.page.ts ***!
  \****************************************************************/
/*! exports provided: JoinByCodePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinByCodePage", function() { return JoinByCodePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_join_by_code_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./join-by-code.page.html */ "Ysr0");
/* harmony import */ var _join_by_code_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./join-by-code.page.scss */ "xMJB");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let JoinByCodePage = class JoinByCodePage {
    constructor(router, httpService, http, loadingController, toastController, alertController) {
        this.router = router;
        this.httpService = httpService;
        this.http = http;
        this.loadingController = loadingController;
        this.toastController = toastController;
        this.alertController = alertController;
        this.search_code = "";
    }
    ngOnInit() {
    }
    onSubmit(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '请稍等...',
            });
            yield loading.present();
            if (form.invalid) { //检验输入信息是否有效
                yield loading.dismiss();
                let toast = yield this.toastController.create({
                    message: '请输入有效信息！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                //待定需要修改
                var api = '/course'; //-------------------------后台接口
                var params = {
                    name: this.search_code,
                    page: 1,
                    isSelf: false
                };
                this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    // console.log(response);
                    if (response.data.data.total == 0) {
                        let alert = yield this.alertController.create({
                            header: '提示',
                            message: '班课不存在！',
                            buttons: ['确定']
                        });
                        alert.present();
                    }
                    else {
                        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.search_code } });
                    }
                }));
            }
        });
    }
};
JoinByCodePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] }
];
JoinByCodePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-join-by-code',
        template: _raw_loader_join_by_code_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_join_by_code_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], JoinByCodePage);



/***/ }),

/***/ "Ysr0":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/join-by-code/join-by-code.page.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/tabs/course']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title color=\"medium\" style=\"text-align:center;\">加入班课</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <form (ngSubmit)=\"onSubmit(codeForm)\" #codeForm=\"ngForm\" novalidate>\r\n        <ion-item lines=\"none\"></ion-item>\r\n        <ion-item lines=\"none\">\r\n            <ion-input name=\"code\" type=\"text\" style=\"border-bottom: solid 1px #7468BE\" placeholder=\"请输入班课号\"\r\n            [(ngModel)]=\"search_code\" #code=\"ngModel\" required pattern=\"^\\d{7}$\"></ion-input>\r\n        </ion-item>\r\n        <ion-row class=\"row\">\r\n            <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n            [disabled]=\"codeForm.invalid\">下一步</ion-button>\r\n        </ion-row>\r\n    </form>\r\n</ion-content>\r\n");

/***/ }),

/***/ "afBY":
/*!******************************************************************!*\
  !*** ./src/app/pages/course/join-by-code/join-by-code.module.ts ***!
  \******************************************************************/
/*! exports provided: JoinByCodePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinByCodePageModule", function() { return JoinByCodePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _join_by_code_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./join-by-code-routing.module */ "ss83");
/* harmony import */ var _join_by_code_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./join-by-code.page */ "HVfY");







let JoinByCodePageModule = class JoinByCodePageModule {
};
JoinByCodePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _join_by_code_routing_module__WEBPACK_IMPORTED_MODULE_5__["JoinByCodePageRoutingModule"]
        ],
        declarations: [_join_by_code_page__WEBPACK_IMPORTED_MODULE_6__["JoinByCodePage"]]
    })
], JoinByCodePageModule);



/***/ }),

/***/ "ss83":
/*!**************************************************************************!*\
  !*** ./src/app/pages/course/join-by-code/join-by-code-routing.module.ts ***!
  \**************************************************************************/
/*! exports provided: JoinByCodePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinByCodePageRoutingModule", function() { return JoinByCodePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _join_by_code_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./join-by-code.page */ "HVfY");




const routes = [
    {
        path: '',
        component: _join_by_code_page__WEBPACK_IMPORTED_MODULE_3__["JoinByCodePage"]
    }
];
let JoinByCodePageRoutingModule = class JoinByCodePageRoutingModule {
};
JoinByCodePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], JoinByCodePageRoutingModule);



/***/ }),

/***/ "xMJB":
/*!******************************************************************!*\
  !*** ./src/app/pages/course/join-by-code/join-by-code.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJqb2luLWJ5LWNvZGUucGFnZS5zY3NzIn0= */");

/***/ })

}]);
//# sourceMappingURL=join-by-code-join-by-code-module.js.map