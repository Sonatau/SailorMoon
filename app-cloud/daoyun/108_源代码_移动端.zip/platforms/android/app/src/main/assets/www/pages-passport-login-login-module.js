(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-passport-login-login-module"],{

/***/ "0clm":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passport/login/login.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <div class=\"background\">\r\n    <form (ngSubmit)=\"onLogin(loginForm)\" #loginForm=\"ngForm\" novalidate>\r\n      <ion-grid>\r\n        <ion-row class=\"row\" style=\"margin-top:80px\">\r\n          <ion-segment mode=\"md\" name=\"tab\" [(ngModel)]=\"tab\" color=\"light\">\r\n            <ion-segment-button value=\"tab1\">\r\n              <ion-label class=\"login_tabs\">密码登录</ion-label>\r\n            </ion-segment-button>\r\n            <ion-segment-button value=\"tab2\">\r\n              <ion-label class=\"login_tabs\">验证码登录</ion-label>\r\n            </ion-segment-button>\r\n          </ion-segment>\r\n        </ion-row>\r\n\r\n        <div [ngSwitch]=\"tab\">\r\n\r\n          <div *ngSwitchCase=\"'tab1'\">\r\n            <ion-row style=\"margin-top:20px;\"></ion-row>\r\n            <ion-row class=\"row\">\r\n              <ion-input name=\"email\" type=\"tel\" class=\"text_input\" placeholder=\"邮箱/手机号\"\r\n                required [(ngModel)]=\"login_email\" #email=ngModel>\r\n                <ion-icon name=\"mail-outline\" class=\"input_icon\"></ion-icon>\r\n              </ion-input>\r\n            </ion-row>\r\n            <div class=\"signup_warn\">\r\n              <ion-text text-left color=\"danger\" *ngIf=\"email.invalid && email.touched\">\r\n                <p class=\"warn\" [hidden]=\"!email.errors?.required\" padding-start>请输入邮箱/手机号</p>\r\n              </ion-text>\r\n            </div>\r\n            <ion-row class=\"row\">\r\n              <ion-input name=\"password\" type=\"password\" class=\"text_input\" placeholder=\"密码\"\r\n                [(ngModel)]=\"login_password\" #password=ngModel required>\r\n               <ion-icon name=\"lock-closed-outline\" class=\"input_icon\"></ion-icon>\r\n              </ion-input>\r\n            </ion-row>\r\n            <div class=\"signup_warn\">\r\n              <ion-text text-left color=\"danger\" *ngIf=\"password.invalid && password.touched\">\r\n                <p class=\"warn\" [hidden]=\"!password.errors?.required\" padding-start>请输入密码</p>\r\n              </ion-text>\r\n            </div>\r\n\r\n            <ion-row class=\"row\">\r\n              <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n              [disabled]=\"loginForm.invalid\"> 登录 </ion-button>\r\n            </ion-row>\r\n            <ion-row class=\"row\" style=\"display: block;text-align: right;\">\r\n              <ion-label color=\"light\" [routerLink]=\"['/find-by-email']\">忘记密码</ion-label>\r\n            </ion-row>\r\n\r\n            <ion-row style=\"margin-top:30px;\"></ion-row>\r\n            <ion-row class=\"row\" style=\"display: block;text-align: center;\">\r\n              <ion-label class=\"login_tabs\" [routerLink]=\"['/register']\">—— 邮箱注册 ——</ion-label>\r\n            </ion-row>\r\n          </div>\r\n\r\n\r\n          <div *ngSwitchCase=\"'tab2'\">\r\n            <ion-row style=\"margin-top:20px;\"></ion-row>\r\n            <ion-row class=\"row\">\r\n              <ion-input name=\"phone\" type=\"text\" class=\"text_input\" placeholder=\"请输入手机号\"\r\n                required [(ngModel)]=\"login_phone\" #phone=\"ngModel\">\r\n                <ion-icon name=\"call-outline\" class=\"input_icon\"></ion-icon>\r\n              </ion-input>\r\n            </ion-row>\r\n            <div class=\"signup_warn\">\r\n              <ion-text text-left color=\"danger\" *ngIf=\"phone.invalid && phone.touched\">\r\n                <p class=\"warn\" [hidden]=\"!phone.errors?.required\" padding-start>请输入手机号</p>\r\n              </ion-text>\r\n            </div>\r\n            <ion-row class=\"row\">\r\n              <ion-input name=\"code\" type=\"text\" class=\"verify_input\" placeholder=\"请输入验证码\"\r\n                [(ngModel)]=\"verify_code\" #code=\"ngModel\" required>\r\n                <ion-icon name=\"mail-open-outline\" class=\"input_icon\"></ion-icon>\r\n              </ion-input>\r\n              <ion-button color=\"primary\" (click)=\"onSendMsg()\" [disabled]=\"!verifyCode.disable\">\r\n                {{verifyCode.verifyCodeTips}}</ion-button>\r\n            </ion-row>\r\n            <div class=\"signup_warn\">\r\n              <ion-text text-left color=\"danger\" *ngIf=\"code.invalid && code.touched\">\r\n                <p class=\"warn\" [hidden]=\"!code.errors?.required\" padding-start>请输入验证码</p>\r\n              </ion-text>\r\n            </div>\r\n\r\n            <ion-row class=\"row\">\r\n              <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n              [disabled]=\"loginForm.invalid\"> 登录 </ion-button>\r\n            </ion-row>\r\n\r\n            <ion-row style=\"margin-top:30px;\"></ion-row>\r\n            <ion-row class=\"row\" style=\"display: block;text-align: center;\">\r\n              <ion-label class=\"login_tabs\" [routerLink]=\"['/register-phone']\">—— 手机快速注册 ——</ion-label>\r\n            </ion-row>\r\n          </div>\r\n        </div>\r\n\r\n        <!-- <ion-row style=\"margin-top:30px;\"></ion-row>\r\n        <ion-row class=\"row\" style=\"display: block;text-align: center;\" class=\"login_tabs\" (click)=\"loginByGitHub()\">\r\n          <ion-icon name=\"logo-github\" color=\"light\" style=\"font-size: 25px;\"></ion-icon>\r\n          <ion-label>&nbsp;&nbsp;Gitee登录</ion-label>\r\n        </ion-row> -->\r\n\r\n      </ion-grid>\r\n    </form>\r\n  </div>\r\n\r\n</ion-content>");

/***/ }),

/***/ "4utI":
/*!****************************************************!*\
  !*** ./src/app/pages/passport/login/login.page.ts ***!
  \****************************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./login.page.html */ "0clm");
/* harmony import */ var _login_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./login.page.scss */ "MiFm");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "m/P+");









let LoginPage = class LoginPage {
    constructor(httpService, http, router, alertController, toastController, inAppBrowser, activatedRoute, loadingController) {
        this.httpService = httpService;
        this.http = http;
        this.router = router;
        this.alertController = alertController;
        this.toastController = toastController;
        this.inAppBrowser = inAppBrowser;
        this.activatedRoute = activatedRoute;
        this.loadingController = loadingController;
        this.tab = "tab1";
        this.login_email = '';
        this.login_phone = '';
        this.login_password = '';
        this.verify_code = '';
        this.verifyCode = {
            verifyCodeTips: "获取验证码",
            countdown: 60,
            disable: true
        };
        //登录状态为1时自动登录
        if (localStorage.getItem("isLogin") == "1") {
            if (this.isOverTime() == false) {
                this.router.navigateByUrl('/tabs/course');
            }
        }
    }
    // ionViewWillEnter() {
    //   this.github_code = this.activatedRoute.snapshot.queryParams.code;
    //   console.log(this.github_code)
    //   if(this.github_code != null){
    //     var api = 'http://192.168.43.225:8080/login-github';
    //     var params = {//后台所需参数
    //         code: this.github_code
    //     };
    //     console.log(params);
    //     //post_withoutToken
    //     this.httpService.post_byURL(api, params).then((response: any) => {
    //       console.log(response);
    //       this.return_code = response.data.respCode;
    //       if(this.return_code == '1'){
    //         localStorage.setItem("token", response.data.data.token);
    //         if(response.data.data.role == '1') localStorage.setItem("isTeacher", '1');
    //         else localStorage.setItem("isTeacher", '0');
    //         if(response.data.data.admin.course == '1') localStorage.setItem("course-admin", '1');
    //         else localStorage.setItem("course-admin", '0');
    //         if(response.data.data.admin.checkin == '1') localStorage.setItem("checkin-admin", '1');
    //         else localStorage.setItem("checkin-admin", '0');
    //         this.router.navigateByUrl('/tabs/course');
    //         localStorage.setItem("isLogin", "1");
    //         this.setLoginTime();
    //       } else{
    //         // console.log('当前github账户未注册，请先注册！');
    //         // this.router.navigateByUrl('/register');
    //         console.log('github链接超时！');
    //       }
    //     })
    //   }
    // }
    ngOnInit() {
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------获取验证码-------------------------------------//
    //----------------------------------------------------------------------------------//
    onSendMsg() {
        //请求后台发送手机验证码
        if (this.verifyCode.disable == true) {
            this.verifyCode.disable = false;
            this.settime();
            var params = {
                phone: this.login_phone,
            };
            var api = '/send-message';
            this.httpService.get_withoutToken(api, params).then((response) => {
                // console.log(response);
                this.return_code = response.data.respCode;
            });
        }
    }
    settime() {
        if (this.verifyCode.countdown == 1) {
            this.verifyCode.countdown = 60;
            this.verifyCode.verifyCodeTips = "获取验证码";
            this.verifyCode.disable = true;
            return;
        }
        else {
            this.verifyCode.countdown--;
        }
        this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
        setTimeout(() => {
            this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
            this.settime();
        }, 1000);
    }
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //-----------------------------------是否需要登录------------------------------------//
    //----------------------------------------------------------------------------------//
    setLoginTime() {
        let myDate = new Date();
        //获取当前年
        var year = myDate.getFullYear();
        //获取当前月
        var month = myDate.getMonth() + 1;
        //获取当前日
        var date = myDate.getDate();
        var h = myDate.getHours() < 10 ? '0' + myDate.getHours() : '' + myDate.getHours(); //获取当前小时数(0-23)
        var m = myDate.getMinutes() < 10 ? '0' + myDate.getMinutes() : '' + myDate.getMinutes(); //获取当前分钟数(0-59)
        var s = myDate.getSeconds() < 10 ? '0' + myDate.getSeconds() : '' + myDate.getSeconds();
        localStorage.setItem("loginTime", year + "/" + month + "/" + date + " " + h + ":" + m + ":" + s);
    }
    isOverTime() {
        let endDate = new Date();
        let startDate = localStorage.getItem("loginTime");
        //时间差的毫秒数 
        let date3 = endDate.getTime() - new Date(startDate).getTime();
        var hours = Math.floor(date3 / (3600 * 1000)); //计算小时数
        //计算出相差天数
        //var days = Math.floor(date3 / (24 * 3600 * 1000));
        //计算出小时数
        //var leave1=date3%(24*3600*1000)    //计算天数后剩余的毫秒数
        //var hours=Math.floor(leave1/(3600*1000))
        // //计算相差分钟数
        // var leave2=leave1%(3600*1000)        //计算小时数后剩余的毫秒数
        // var minutes=Math.floor(leave2/(60*1000))
        // //计算相差秒数
        // var leave3=leave2%(60*1000)      //计算分钟数后剩余的毫秒数
        // var seconds=Math.round(leave3/1000)  //对应的秒数
        // alert(" 相差 "+days+"天 "+hours+"小时 "+minutes+" 分钟"+seconds+" 秒")
        if (hours > 2)
            return true;
        else
            return false;
    }
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //-------------------------------------验证登录--------------------------------------//
    //----------------------------------------------------------------------------------//
    onLogin(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '登陆中...',
            });
            var params;
            if (form.invalid) { //检验输入信息是否有效
                yield loading.dismiss();
                let toast = yield this.toastController.create({
                    message: '请输入有效信息！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                if (this.tab == 'tab2') { //验证码登录
                    var api = '/login-code'; //后台接口
                    params = {
                        phone: this.login_phone,
                        code: this.verify_code,
                        device: 0
                    };
                }
                else if (this.tab == 'tab1') { //密码登录
                    var api = '/login'; //后台接口
                    params = {
                        email: this.login_email,
                        password: this.login_password,
                        device: 0
                    };
                }
                this.httpService.post_withoutToken(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    // console.log(response);
                    this.return_code = response.data.respCode;
                    // console.log(this.return_code);
                    if (this.return_code == '1') {
                        localStorage.setItem("token", response.data.data.token);
                        if (response.data.data.role == '1')
                            localStorage.setItem("isTeacher", '1');
                        else
                            localStorage.setItem("isTeacher", '0');
                        if (response.data.data.admin.course == '1')
                            localStorage.setItem("course-admin", '1');
                        else
                            localStorage.setItem("course-admin", '0');
                        if (response.data.data.admin.checkin == '1')
                            localStorage.setItem("checkin-admin", '1');
                        else
                            localStorage.setItem("checkin-admin", '0');
                        localStorage.setItem("isLogin", "1");
                        this.router.navigateByUrl('/tabs/course');
                        this.setLoginTime();
                    }
                    else {
                        yield loading.dismiss();
                        let alert = yield this.alertController.create({
                            header: '提示',
                            message: '登录失败',
                            buttons: ['确定']
                        });
                        alert.present();
                    }
                }));
            }
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_8__["InAppBrowser"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
LoginPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-login',
        template: _raw_loader_login_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_login_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], LoginPage);



/***/ }),

/***/ "CWu2":
/*!******************************************************!*\
  !*** ./src/app/pages/passport/login/login.module.ts ***!
  \******************************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login-routing.module */ "j0c1");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "4utI");







let LoginPageModule = class LoginPageModule {
};
LoginPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"]
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "MiFm":
/*!******************************************************!*\
  !*** ./src/app/pages/passport/login/login.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".background {\n  height: 100%;\n  width: 100%;\n  background-image: url(/assets/img/login/login.png);\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.login_tabs {\n  font-size: 17px;\n  font-weight: bold;\n  color: #f4f5f8;\n}\n\n.img-tel {\n  height: 28px;\n}\n\n.row {\n  padding-top: 10px;\n  width: 80%;\n  margin: auto;\n}\n\nion-segment-button {\n  background-color: rgba(225, 225, 225, 0) !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcbG9naW4ucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxrREFBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7QUFBSjs7QUFHQTtFQUNJLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7QUFBSjs7QUFJQTtFQUNJLFlBQUE7QUFESjs7QUFHQTtFQUNJLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFBSjs7QUFFQTtFQUNJLG1EQUFBO0FBQ0oiLCJmaWxlIjoibG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy/pobXpnaLog4zmma9cclxuLmJhY2tncm91bmR7XHJcbiAgICBoZWlnaHQ6MTAwJTtcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOnVybCgvYXNzZXRzL2ltZy9sb2dpbi9sb2dpbi5wbmcpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6bm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOjEwMCUgMTAwJTtcclxufVxyXG5cclxuLmxvZ2luX3RhYnN7XHJcbiAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgIGNvbG9yOiAjZjRmNWY4O1xyXG59XHJcblxyXG4vL+adgumhuVxyXG4uaW1nLXRlbHtcclxuICAgIGhlaWdodDogMjhweDtcclxufVxyXG4ucm93e1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICB3aWR0aDo4MCU7XHJcbiAgICBtYXJnaW46YXV0bztcclxufVxyXG5pb24tc2VnbWVudC1idXR0b257XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDIyNSwyMjUsMjI1LDApICFpbXBvcnRhbnQ7XHJcbn0iXX0= */");

/***/ }),

/***/ "j0c1":
/*!**************************************************************!*\
  !*** ./src/app/pages/passport/login/login-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: LoginPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function() { return LoginPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./login.page */ "4utI");




const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }
];
let LoginPageRoutingModule = class LoginPageRoutingModule {
};
LoginPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], LoginPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-passport-login-login-module.js.map