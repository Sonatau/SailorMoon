(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-passport-change-pass-change-pass-module"],{

/***/ "3f5W":
/*!******************************************************************!*\
  !*** ./src/app/pages/passport/change-pass/change-pass.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".background {\n  height: 100%;\n  width: 100%;\n  background-image: url(\"/assets/img/login/login.png\");\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.row {\n  padding-top: 10px;\n  width: 80%;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY2hhbmdlLXBhc3MucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxvREFBQTtFQUNBLDRCQUFBO0VBQ0EsMEJBQUE7QUFDSjs7QUFDQTtFQUNJLGlCQUFBO0VBQ0EsVUFBQTtFQUNBLFlBQUE7QUFFSiIsImZpbGUiOiJjaGFuZ2UtcGFzcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuYmFja2dyb3VuZHtcclxuICAgIGhlaWdodDoxMDAlO1xyXG4gICAgd2lkdGg6MTAwJTtcclxuICAgIGJhY2tncm91bmQtaW1hZ2U6dXJsKFwiL2Fzc2V0cy9pbWcvbG9naW4vbG9naW4ucG5nXCIpO1xyXG4gICAgYmFja2dyb3VuZC1yZXBlYXQ6bm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOjEwMCUgMTAwJTtcclxufVxyXG4ucm93e1xyXG4gICAgcGFkZGluZy10b3A6IDEwcHg7XHJcbiAgICB3aWR0aDo4MCU7XHJcbiAgICBtYXJnaW46YXV0bztcclxufVxyXG4iXX0= */");

/***/ }),

/***/ "Mpii":
/*!******************************************************************!*\
  !*** ./src/app/pages/passport/change-pass/change-pass.module.ts ***!
  \******************************************************************/
/*! exports provided: ChangePassPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePassPageModule", function() { return ChangePassPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _change_pass_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./change-pass-routing.module */ "U092");
/* harmony import */ var _change_pass_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./change-pass.page */ "fXWF");







let ChangePassPageModule = class ChangePassPageModule {
};
ChangePassPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _change_pass_routing_module__WEBPACK_IMPORTED_MODULE_5__["ChangePassPageRoutingModule"]
        ],
        declarations: [_change_pass_page__WEBPACK_IMPORTED_MODULE_6__["ChangePassPage"]]
    })
], ChangePassPageModule);



/***/ }),

/***/ "U092":
/*!**************************************************************************!*\
  !*** ./src/app/pages/passport/change-pass/change-pass-routing.module.ts ***!
  \**************************************************************************/
/*! exports provided: ChangePassPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePassPageRoutingModule", function() { return ChangePassPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _change_pass_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./change-pass.page */ "fXWF");




const routes = [
    {
        path: '',
        component: _change_pass_page__WEBPACK_IMPORTED_MODULE_3__["ChangePassPage"]
    }
];
let ChangePassPageRoutingModule = class ChangePassPageRoutingModule {
};
ChangePassPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ChangePassPageRoutingModule);



/***/ }),

/***/ "cdtH":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passport/change-pass/change-pass.page.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-icon slot=\"start\" name=\"chevron-back-outline\" [routerLink]=\"['/tabs/mine']\"></ion-icon>\r\n    <ion-title class=\"ion-text-center\">修改密码</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"background\">\r\n    <form (ngSubmit)=\"onChangePass(changepassForm)\" #changepassForm=\"ngForm\" novalidate>\r\n      <ion-grid>\r\n        <ion-row class=\"row\" style=\"margin-top:30px\">\r\n        </ion-row>\r\n        <ion-row class=\"row\">\r\n          <ion-input name='old_pwd' type=\"password\" class=\"text_input\" placeholder=\"请输入旧密码\" required\r\n          pattern=\"^(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^[^\\s\\u4e00-\\u9fa5]{6,12}$\" [(ngModel)]=\"changeinf.oldpassword\" #old_pwd=\"ngModel\">\r\n            <ion-icon name=\"lock-closed-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text name='old_pwd' text-left color=\"danger\" *ngIf=\"old_pwd.invalid && old_pwd.touched\">\r\n            <p class=\"warn\" [hidden]=\"!old_pwd.errors?.required\" padding-start>必填：请输入旧密码</p>\r\n            <p class=\"warn\" [hidden]=\"!old_pwd.errors?.pattern\" padding-start>\r\n              旧密码格式错误</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"pwd1\" type=\"password\" class=\"text_input\" placeholder=\"请输入新密码\" required\r\n          pattern=\"^(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^[^\\s\\u4e00-\\u9fa5]{6,16}$\" [(ngModel)]=\"changeinf.password1\" #pwd1=\"ngModel\">\r\n            <ion-icon name=\"lock-closed-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text name='pwd1' text-left color=\"danger\" *ngIf=\"pwd1.invalid && pwd1.touched\">\r\n            <p class=\"warn\" [hidden]=\"!pwd1.errors?.required\" padding-start>必填：请输入新密码</p>\r\n            <p class=\"warn\" [hidden]=\"!pwd1.errors?.pattern\" padding-start>\r\n              6至16位，由数字、英文、符号三种字符类型构成，至少包含两种类型字符</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"pwd2\" type=\"password\" class=\"text_input\" placeholder=\"请再次输入新密码\" required\r\n          pattern=\"^(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^[^\\s\\u4e00-\\u9fa5]{6,16}$\" [(ngModel)]=\"changeinf.password2\" #pwd2=\"ngModel\">\r\n            <ion-icon name=\"bag-check-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"pwd2.invalid && pwd2.touched\">\r\n            <p class=\"warn\" [hidden]=\"!pwd2.errors?.required\" padding-start>必填：请再次确认您的密码</p>\r\n          </ion-text>\r\n        </div> \r\n\r\n        <ion-row class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\" [disabled]=\"changepassForm.invalid\">确认修改</ion-button>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </form>\r\n  </div>\r\n</ion-content>");

/***/ }),

/***/ "fXWF":
/*!****************************************************************!*\
  !*** ./src/app/pages/passport/change-pass/change-pass.page.ts ***!
  \****************************************************************/
/*! exports provided: ChangePassPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ChangePassPage", function() { return ChangePassPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_change_pass_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./change-pass.page.html */ "cdtH");
/* harmony import */ var _change_pass_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./change-pass.page.scss */ "3f5W");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let ChangePassPage = class ChangePassPage {
    constructor(toastController, httpService, alertController, http, router, loadingController) {
        this.toastController = toastController;
        this.httpService = httpService;
        this.alertController = alertController;
        this.http = http;
        this.router = router;
        this.loadingController = loadingController;
        this.changeinf = {
            oldpassword: '',
            password1: '',
            password2: ''
        };
    }
    ngOnInit() {
    }
    onChangePass(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '修改中...',
            });
            if (form.invalid) {
                yield loading.dismiss();
                let toast = yield this.toastController.create({
                    message: '请输入有效信息！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                //两次新密码是否相同
                if (this.changeinf.password1 == this.changeinf.password2) {
                    var api = '/updated-password';
                    var params = {
                        newPassword1: this.changeinf.password1,
                        newPassword2: this.changeinf.password2,
                        oldPassword: this.changeinf.oldpassword,
                    };
                    this.httpService.put(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                        //console.log(response);
                        yield loading.dismiss();
                        if (response.data.respCode == 1) {
                            //修改密码成功，跳转到登录页
                            let alert = yield this.alertController.create({
                                header: '提示',
                                message: '修改成功，点击返回登录！',
                                buttons: [{
                                        text: '确定',
                                        cssClass: 'primary',
                                        handler: (blah) => {
                                            //修改密码成功，跳转到登录页
                                            this.router.navigateByUrl('/login');
                                        }
                                    }]
                            });
                            alert.present();
                        }
                        else {
                            let alert = yield this.alertController.create({
                                header: '提示',
                                message: '密码修改失败！',
                                buttons: ['确定']
                            });
                            alert.present();
                        }
                    }));
                }
                else {
                    yield loading.dismiss();
                    let toast = yield this.toastController.create({
                        message: '两次新密码输入不一致！',
                        duration: 2000
                    });
                    toast.present();
                }
            }
        });
    }
};
ChangePassPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
ChangePassPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-change-pass',
        template: _raw_loader_change_pass_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_change_pass_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], ChangePassPage);



/***/ })

}]);
//# sourceMappingURL=pages-passport-change-pass-change-pass-module.js.map