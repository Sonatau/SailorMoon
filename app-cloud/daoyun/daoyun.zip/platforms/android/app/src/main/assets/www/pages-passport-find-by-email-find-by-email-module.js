(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-passport-find-by-email-find-by-email-module"],{

/***/ "0LsX":
/*!********************************************************************!*\
  !*** ./src/app/pages/passport/find-by-email/find-by-email.page.ts ***!
  \********************************************************************/
/*! exports provided: FindByEmailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FindByEmailPage", function() { return FindByEmailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_find_by_email_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./find-by-email.page.html */ "lv/H");
/* harmony import */ var _find_by_email_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./find-by-email.page.scss */ "pJUs");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let FindByEmailPage = class FindByEmailPage {
    constructor(httpService, http, router, alertController, toastController, loadingController) {
        this.httpService = httpService;
        this.http = http;
        this.router = router;
        this.alertController = alertController;
        this.toastController = toastController;
        this.loadingController = loadingController;
        this.find_email = '';
        this.password1 = '';
        this.password2 = '';
        this.verify_code = '';
        this.return_code = -1; //1: 发送成功   -1: 发送失败
        this.verifyCode = {
            verifyCodeTips: "获取验证码",
            countdown: 60,
            disable: true
        };
    }
    ngOnInit() {
    }
    //----------------------------------------------------------------------------------//
    //------------------------------------获取验证码-------------------------------------//
    //----------------------------------------------------------------------------------//
    onSendSMS() {
        //请求后台发送验证码
        if (this.verifyCode.disable == true) {
            this.verifyCode.disable = false;
            this.settime();
            var params = {
                email: this.find_email,
            };
            var api = '/sendCode';
            this.httpService.get_withoutToken(api, params).then((response) => {
                //console.log(response);
                this.return_code = response.data.respCode;
                // console.log(this.return_code);
            });
        }
    }
    settime() {
        if (this.verifyCode.countdown == 1) {
            this.verifyCode.countdown = 60;
            this.verifyCode.verifyCodeTips = "获取验证码";
            this.verifyCode.disable = true;
            return;
        }
        else {
            this.verifyCode.countdown--;
        }
        this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
        setTimeout(() => {
            this.verifyCode.verifyCodeTips = "重新获取(" + this.verifyCode.countdown + "秒)";
            this.settime();
        }, 1000);
    }
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //----------------------------------------------------------------------------------//
    //-----------------------------------验证更改密码------------------------------------//
    //----------------------------------------------------------------------------------//
    onVerify(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: '修改中...',
            });
            if (form.invalid) { //检验输入信息是否有效
                yield loading.dismiss();
                let toast = yield this.toastController.create({
                    message: '请输入有效信息！',
                    duration: 2000
                });
                toast.present();
            }
            else {
                if (this.return_code == -1) { //检验是否成功发送验证码
                    yield loading.dismiss();
                    let toast = yield this.toastController.create({
                        message: '请先获取验证码！',
                        duration: 2000
                    });
                    toast.present();
                }
                else {
                    if (this.password1 != this.password2) {
                        yield loading.dismiss();
                        let toast = yield this.toastController.create({
                            message: '两次密码不一致！',
                            duration: 2000
                        });
                        toast.present();
                    }
                    else {
                        var api = '/forget-password'; //----------------后台接口
                        var params = {
                            email: this.find_email,
                            newPassword: this.password1,
                            mailVerificationCode: this.verify_code
                        };
                        //console.log(params);
                        this.httpService.post_withoutToken(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            yield loading.dismiss();
                            if (response.data.respCode == -1) {
                                let alert = yield this.alertController.create({
                                    header: '提示',
                                    message: response.data.msg,
                                    buttons: ['确定']
                                });
                                alert.present();
                            }
                            else if (response.data.respCode == 1) {
                                let alert = yield this.alertController.create({
                                    header: '提示',
                                    message: '修改成功！',
                                    buttons: [{
                                            text: '确认',
                                            cssClass: 'primary',
                                            handler: (blah) => {
                                                this.router.navigateByUrl('/login');
                                            }
                                        }]
                                });
                                alert.present();
                            }
                        }));
                    }
                }
            }
        });
    }
};
FindByEmailPage.ctorParameters = () => [
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClient"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
FindByEmailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-find-by-email',
        template: _raw_loader_find_by_email_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_find_by_email_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], FindByEmailPage);



/***/ }),

/***/ "81ZK":
/*!**********************************************************************!*\
  !*** ./src/app/pages/passport/find-by-email/find-by-email.module.ts ***!
  \**********************************************************************/
/*! exports provided: FindByEmailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FindByEmailPageModule", function() { return FindByEmailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _find_by_email_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./find-by-email-routing.module */ "yN0Q");
/* harmony import */ var _find_by_email_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./find-by-email.page */ "0LsX");







let FindByEmailPageModule = class FindByEmailPageModule {
};
FindByEmailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _find_by_email_routing_module__WEBPACK_IMPORTED_MODULE_5__["FindByEmailPageRoutingModule"]
        ],
        declarations: [_find_by_email_page__WEBPACK_IMPORTED_MODULE_6__["FindByEmailPage"]]
    })
], FindByEmailPageModule);



/***/ }),

/***/ "lv/H":
/*!************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/passport/find-by-email/find-by-email.page.html ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-icon slot=\"start\" name=\"chevron-back-outline\" [routerLink]=\"['/login']\"></ion-icon>\r\n    <ion-title class=\"ion-text-center\">找回密码</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div class=\"background\">\r\n    <form (ngSubmit)=\"onVerify(verifyForm)\" #verifyForm=\"ngForm\" novalidate>\r\n      <ion-grid>\r\n        <ion-row style=\"margin-top:30px;\"></ion-row>\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"email\" type=\"text\" class=\"text_input\" [(ngModel)]=\"find_email\" #email=\"ngModel\"\r\n          placeholder=\"请输入邮箱\" required pattern=\"^\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*$\" >\r\n            <ion-icon name=\"mail-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"email.invalid && email.touched\">\r\n            <p class=\"warn\" [hidden]=\"!email.errors?.required\" padding-start>必填：请输入邮箱地址</p>\r\n            <p class=\"warn\" [hidden]=\"!email.errors?.pattern\" padding-start>您输入的邮箱格式不正确</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"code\" type=\"text\" class=\"verify_input\" placeholder=\"请输入验证码\"\r\n          [(ngModel)]=\"verify_code\" #code=\"ngModel\" required>\r\n            <ion-icon name=\"mail-open-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n          <ion-button color=\"primary\" (click)=\"onSendSMS()\" [disabled]=\"!verifyCode.disable\">\r\n            {{verifyCode.verifyCodeTips}}</ion-button>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"code.invalid && code.touched\">\r\n            <p class=\"warn\" [hidden]=\"!code.errors?.required\" padding-start>请输入验证码</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"pwd1\" type=\"password\" class=\"text_input\" placeholder=\"请输入新密码\" required\r\n          pattern=\"^(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^[^\\s\\u4e00-\\u9fa5]{6,16}$\" [(ngModel)]=\"password1\" #pwd1=\"ngModel\">\r\n            <ion-icon name=\"lock-closed-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text name='pwd1' text-left color=\"danger\" *ngIf=\"pwd1.invalid && pwd1.touched\">\r\n            <p class=\"warn\" [hidden]=\"!pwd1.errors?.required\" padding-start>必填：请输入新密码</p>\r\n            <p class=\"warn\" [hidden]=\"!pwd1.errors?.pattern\" padding-start>\r\n              6至16位，由数字、英文、符号三种字符类型构成，至少包含两种类型字符</p>\r\n          </ion-text>\r\n        </div>\r\n\r\n        <ion-row class=\"row\">\r\n          <ion-input name=\"pwd2\" type=\"password\" class=\"text_input\" placeholder=\"请再次输入新密码\" required\r\n          pattern=\"^(?!^[0-9]+$)(?!^[A-z]+$)(?!^[^A-z0-9]+$)^[^\\s\\u4e00-\\u9fa5]{6,16}$\" [(ngModel)]=\"password2\" #pwd2=\"ngModel\">\r\n            <ion-icon name=\"bag-check-outline\" class=\"input_icon\"></ion-icon>\r\n          </ion-input>\r\n        </ion-row>\r\n        <div class=\"signup_warn\">\r\n          <ion-text text-left color=\"danger\" *ngIf=\"pwd2.invalid && pwd2.touched\">\r\n            <p class=\"warn\" [hidden]=\"!pwd2.errors?.required\" padding-start>必填：请再次确认您的密码</p>\r\n          </ion-text>\r\n          <ion-text text-left color=\"danger\" *ngIf=\"pwd2.touched && pwd1v!==vpwd2\">\r\n            <p class=\"warn\" padding-start>两次密码不一致</p>\r\n          </ion-text>\r\n        </div> \r\n\r\n        <ion-row class=\"row\">\r\n          <ion-button color=\"primary\" class=\"btn\" type=\"submit\" [disabled]=\"verifyForm.invalid\">确认</ion-button>\r\n        </ion-row>\r\n      </ion-grid>\r\n    </form>\r\n  </div>\r\n\r\n</ion-content>");

/***/ }),

/***/ "pJUs":
/*!**********************************************************************!*\
  !*** ./src/app/pages/passport/find-by-email/find-by-email.page.scss ***!
  \**********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".background {\n  height: 100%;\n  width: 100%;\n  background-image: url(\"/assets/img/login/login.png\");\n  background-repeat: no-repeat;\n  background-size: 100% 100%;\n}\n\n.row {\n  padding-top: 10px;\n  width: 80%;\n  margin: auto;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcZmluZC1ieS1lbWFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLG9EQUFBO0VBQ0EsNEJBQUE7RUFDQSwwQkFBQTtBQUNKOztBQUVBO0VBQ0ksaUJBQUE7RUFDQSxVQUFBO0VBQ0EsWUFBQTtBQUNKIiwiZmlsZSI6ImZpbmQtYnktZW1haWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmJhY2tncm91bmR7XHJcbiAgICBoZWlnaHQ6MTAwJTtcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgICBiYWNrZ3JvdW5kLWltYWdlOnVybChcIi9hc3NldHMvaW1nL2xvZ2luL2xvZ2luLnBuZ1wiKTtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0Om5vLXJlcGVhdDtcclxuICAgIGJhY2tncm91bmQtc2l6ZToxMDAlIDEwMCU7XHJcbn1cclxuXHJcbi5yb3d7XHJcbiAgICBwYWRkaW5nLXRvcDogMTBweDtcclxuICAgIHdpZHRoOjgwJTtcclxuICAgIG1hcmdpbjphdXRvO1xyXG59Il19 */");

/***/ }),

/***/ "yN0Q":
/*!******************************************************************************!*\
  !*** ./src/app/pages/passport/find-by-email/find-by-email-routing.module.ts ***!
  \******************************************************************************/
/*! exports provided: FindByEmailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FindByEmailPageRoutingModule", function() { return FindByEmailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _find_by_email_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./find-by-email.page */ "0LsX");




const routes = [
    {
        path: '',
        component: _find_by_email_page__WEBPACK_IMPORTED_MODULE_3__["FindByEmailPage"]
    }
];
let FindByEmailPageRoutingModule = class FindByEmailPageRoutingModule {
};
FindByEmailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], FindByEmailPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-passport-find-by-email-find-by-email-module.js.map