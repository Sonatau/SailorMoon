(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["edit-detail-edit-detail-module"],{

/***/ "1956":
/*!******************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/edit-detail/edit-detail.page.html ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"gotodetail()\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">编辑课程</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form (ngSubmit)=\"onSubmit(submitForm)\" #submitForm=\"ngForm\" novalidate>\r\n      <ion-list lines=\"full\">\r\n\r\n        <ion-item-divider color=\"light\">\r\n          <ion-thumbnail *ngIf=\"course.cover != 'image_null'\">\r\n            <img src={{course.cover}}>\r\n          </ion-thumbnail>\r\n          <ion-thumbnail slot=\"end\" (click)=\"onPresentActiveSheet()\">\r\n            <img src=\"assets/img/course/add.png\">\r\n          </ion-thumbnail>\r\n        </ion-item-divider>\r\n\r\n        <ion-item>\r\n          <ion-label slot=\"start\">课程名称</ion-label>\r\n          <ion-input name=\"name\" type=\"text\" class=\"my_inf\" slot=\"end\"\r\n            placeholder=\"course.name\" [(ngModel)]=\"course.name\" #name=\"ngModel\" required>\r\n          </ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(1)\">\r\n          <ion-label slot=\"start\">开设学校</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{course.school}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(2)\">\r\n          <ion-label slot=\"start\">开设学院</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{course.academy}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(3)\">\r\n          <ion-label slot=\"start\">开设专业</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{course.major}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-row style=\"margin: top 30px;\" class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n          [disabled]=\"submitForm.invalid\"> 确认修改 </ion-button>\r\n        </ion-row>\r\n      </ion-list>\r\n  </form>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "GYIr":
/*!************************************************************************!*\
  !*** ./src/app/pages/course/edit-detail/edit-detail-routing.module.ts ***!
  \************************************************************************/
/*! exports provided: EditDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditDetailPageRoutingModule", function() { return EditDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _edit_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./edit-detail.page */ "vqdg");




const routes = [
    {
        path: '',
        component: _edit_detail_page__WEBPACK_IMPORTED_MODULE_3__["EditDetailPage"]
    }
];
let EditDetailPageRoutingModule = class EditDetailPageRoutingModule {
};
EditDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], EditDetailPageRoutingModule);



/***/ }),

/***/ "IjmW":
/*!****************************************************************!*\
  !*** ./src/app/pages/course/edit-detail/edit-detail.page.scss ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".my_textarea {\n  width: 90%;\n  height: 100px;\n  overflow: visible;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcZWRpdC1kZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksVUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUNKIiwiZmlsZSI6ImVkaXQtZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5teV90ZXh0YXJlYXtcclxuICAgIHdpZHRoOiA5MCU7XHJcbiAgICBoZWlnaHQ6IDEwMHB4O1xyXG4gICAgb3ZlcmZsb3c6IHZpc2libGU7XHJcbn0iXX0= */");

/***/ }),

/***/ "rMfX":
/*!****************************************************************!*\
  !*** ./src/app/pages/course/edit-detail/edit-detail.module.ts ***!
  \****************************************************************/
/*! exports provided: EditDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditDetailPageModule", function() { return EditDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _edit_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./edit-detail-routing.module */ "GYIr");
/* harmony import */ var _edit_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./edit-detail.page */ "vqdg");







let EditDetailPageModule = class EditDetailPageModule {
};
EditDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _edit_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["EditDetailPageRoutingModule"]
        ],
        declarations: [_edit_detail_page__WEBPACK_IMPORTED_MODULE_6__["EditDetailPage"]]
    })
], EditDetailPageModule);



/***/ }),

/***/ "vqdg":
/*!**************************************************************!*\
  !*** ./src/app/pages/course/edit-detail/edit-detail.page.ts ***!
  \**************************************************************/
/*! exports provided: EditDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "EditDetailPage", function() { return EditDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_edit_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./edit-detail.page.html */ "1956");
/* harmony import */ var _edit_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./edit-detail.page.scss */ "IjmW");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");
/* harmony import */ var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/image-picker/ngx */ "tAfe");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");










let EditDetailPage = class EditDetailPage {
    constructor(router, activatedRoute, actionSheetCtrl, camera, imagePicker, httpService, http, alertController, toastController, pickerController, platform) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.actionSheetCtrl = actionSheetCtrl;
        this.camera = camera;
        this.imagePicker = imagePicker;
        this.httpService = httpService;
        this.http = http;
        this.alertController = alertController;
        this.toastController = toastController;
        this.pickerController = pickerController;
        this.platform = platform;
        this.schoolList = {
            total: 0,
            schools: []
        };
        this.academyList = {
            total: 0,
            academies: []
        };
        this.majorList = {
            total: 0,
            majors: []
        };
    }
    ngOnInit() {
        this.course = this.initCourse();
        this.setCourse();
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------------初始：请求学校+课程信息------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.setCourse();
        this.setSchoolList();
        this.setAcademyList();
        this.setMajorList();
    }
    setSchoolList() {
        var param = {
            page: 1
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.schoolList.schools.push({
                    schoolId: response.data.data.list[i].id,
                    schoolName: response.data.data.list[i].name
                });
            }
            this.schoolList.total = response.data.data.total;
            //console.log(this.schoolList);
        }));
    }
    setAcademyList() {
        var param = {
            page: 1,
            parentId: this.course.schoolId
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.academyList.academies.push({
                    academyId: response.data.data.list[i].id,
                    academyName: response.data.data.list[i].name
                });
            }
            this.academyList.total = response.data.data.total;
        }));
    }
    setMajorList() {
        var param = {
            page: 1,
            parentId: this.course.academyId
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.majorList.majors.push({
                    majorId: response.data.data.list[i].id,
                    majorName: response.data.data.list[i].name
                });
            }
            this.majorList.total = response.data.data.total;
        }));
    }
    /**
     * 初始化课程信息
     * @returns {Course}
     */
    initCourse() {
        return {
            id: -1,
            cover: "",
            code: "",
            name: "",
            school: "",
            academy: "",
            major: "",
            teacher: "",
            schoolId: -1,
            academyId: -1,
            majorId: -1,
            teacherId: -1
        };
    }
    setCourse() {
        this.course.code = this.activatedRoute.snapshot.queryParams['code'];
        var param = {
            code: this.course.code,
            page: 1
        };
        var api = '/course';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(response);
            this.course.id = response.data.data.list[0].id;
            this.course.name = response.data.data.list[0].name;
            this.course.school = response.data.data.list[0].school;
            this.course.academy = response.data.data.list[0].academy;
            this.course.major = response.data.data.list[0].major;
            this.course.teacher = response.data.data.list[0].teacher;
            this.course.cover = response.data.data.list[0].image;
            this.course.schoolId = response.data.data.list[0].schoolId;
            this.course.academyId = response.data.data.list[0].acadeId;
            this.course.majorId = response.data.data.list[0].majorId;
            this.course.teacherId = response.data.data.list[0].teacherId;
        }));
        //console.log(this.course);
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------------请求学校/学院/专业列表------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    openPicker(type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (type == 3 && this.course.academyId == -1) {
                const alert = yield this.alertController.create({
                    header: '警告',
                    message: '请先选择院系！',
                    buttons: ['确认']
                });
                yield alert.present();
            }
            else {
                const picker = yield this.pickerController.create({
                    columns: this.getColumns(type),
                    buttons: [
                        {
                            text: '取消',
                            role: 'cancel'
                        },
                        {
                            text: '确认',
                            handler: (value) => {
                                var selected = this.getColumns(type);
                                //console.log(value);
                                if (type == 1) {
                                    this.course.school = selected[0].options[value.daoyun108.value].text;
                                    this.course.schoolId = selected[0].options[value.daoyun108.value].id;
                                    this.setNextOptions(type);
                                }
                                else if (type == 2) {
                                    this.course.academy = selected[0].options[value.daoyun108.value].text;
                                    this.course.academyId = selected[0].options[value.daoyun108.value].id;
                                    this.setNextOptions(type);
                                }
                                else {
                                    this.course.major = selected[0].options[value.daoyun108.value].text;
                                    this.course.majorId = selected[0].options[value.daoyun108.value].id;
                                }
                            }
                        }
                    ]
                });
                yield picker.present();
            }
        });
    }
    getColumns(type) {
        let options = [];
        if (type == 1) {
            for (let i = 0; i < this.schoolList.total; i++) {
                options.push({
                    text: this.schoolList.schools[i].schoolName,
                    id: this.schoolList.schools[i].schoolId,
                    value: i
                });
            }
        }
        else if (type == 2) {
            for (let i = 0; i < this.academyList.total; i++) {
                options.push({
                    text: this.academyList.academies[i].academyName,
                    id: this.academyList.academies[i].academyId,
                    value: i
                });
            }
        }
        else {
            for (let i = 0; i < this.majorList.total; i++) {
                options.push({
                    text: this.majorList.majors[i].majorName,
                    id: this.majorList.majors[i].majorId,
                    value: i
                });
            }
        }
        let columns = [];
        columns.push({
            name: `daoyun108`,
            options: options
        });
        //console.log(options);
        return columns;
    }
    setNextOptions(type) {
        if (type == 1) {
            this.academyList.academies = [];
            this.academyList.total = 0;
            this.course.academy = "请选择";
            this.course.academyId = -1;
            this.setAcademyList();
        }
        this.majorList.majors = [];
        this.majorList.total = 0;
        this.course.major = "请选择";
        this.course.majorId = -1;
        if (type == 2) {
            this.setMajorList();
        }
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------上传课程封面-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    /**
     * 上传图片
     * @returns {Promise<void>}
     */
    onPresentActiveSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetCtrl.create({
                header: '选择您的操作',
                buttons: [
                    {
                        text: '拍照',
                        role: 'destructive',
                        handler: () => {
                            // console.log('进入相机');
                            this.onCamera();
                        }
                    }, {
                        text: '相册',
                        handler: () => {
                            // console.log('进入相册');
                            this.onImagePicker();
                        }
                    }, {
                        text: '取消',
                        role: 'cancel',
                        handler: () => {
                            // console.log('Cancel clicked');
                        }
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    /**
     * 拍照
     */
    onCamera() {
        const options = {
            quality: 10,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then((imageData) => {
            this.course.cover = 'data:image/jpeg;base64,' + imageData;
        }, (err) => {
        });
    }
    /**
     * 相册
     */
    onImagePicker() {
        const options = {
            maximumImagesCount: 1,
            quality: 10,
            outputType: 1
        };
        //console.log('in imagePicker');
        this.imagePicker.getPictures(options).then((results) => {
            for (let i = 0; i < results.length; i++) {
                //console.log('Image URI: ' + results[i]);
                this.course.cover = 'data:image/jpeg;base64,' + results[i];
            }
        }, (err) => { console.log(err); });
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //-------------------------------------------------------提交&跳转------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    onSubmit(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (form.valid) {
                if (this.course.academyId == -1 || this.course.majorId == -1) {
                    let toast = yield this.toastController.create({
                        message: '请选择学院、专业！',
                        duration: 2000
                    });
                    toast.present();
                }
                else {
                    var param = {
                        id: this.course.id,
                        image: this.course.cover,
                        name: this.course.name,
                        schoolId: this.course.schoolId,
                        acadeId: this.course.academyId,
                        majorId: this.course.majorId,
                    };
                    //console.log(param);
                    var api = '/course';
                    this.httpService.put(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                        //console.log(response);
                        const alert = yield this.alertController.create({
                            message: '信息修改成功！',
                            buttons: [
                                {
                                    text: '确认',
                                    cssClass: 'secondary',
                                    handler: (blah) => {
                                        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.course.code } });
                                    }
                                }
                            ]
                        });
                        yield alert.present();
                    }));
                }
            }
        });
    }
    gotodetail() {
        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.course.code } });
    }
};
EditDetailPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_7__["Camera"] },
    { type: _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_8__["ImagePicker"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_9__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PickerController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"] }
];
EditDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-edit-detail',
        template: _raw_loader_edit_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_edit_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], EditDetailPage);



/***/ })

}]);
//# sourceMappingURL=edit-detail-edit-detail-module.js.map