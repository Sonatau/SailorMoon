(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["join-by-qr-join-by-qr-module"],{

/***/ "9MLM":
/*!**********************************************************************!*\
  !*** ./src/app/pages/course/join-by-qr/join-by-qr-routing.module.ts ***!
  \**********************************************************************/
/*! exports provided: JoinByQrPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinByQrPageRoutingModule", function() { return JoinByQrPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _join_by_qr_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./join-by-qr.page */ "Rb1H");




const routes = [
    {
        path: '',
        component: _join_by_qr_page__WEBPACK_IMPORTED_MODULE_3__["JoinByQrPage"]
    }
];
let JoinByQrPageRoutingModule = class JoinByQrPageRoutingModule {
};
JoinByQrPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], JoinByQrPageRoutingModule);



/***/ }),

/***/ "AaI+":
/*!**************************************************************!*\
  !*** ./src/app/pages/course/join-by-qr/join-by-qr.module.ts ***!
  \**************************************************************/
/*! exports provided: JoinByQrPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinByQrPageModule", function() { return JoinByQrPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _join_by_qr_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./join-by-qr-routing.module */ "9MLM");
/* harmony import */ var _join_by_qr_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./join-by-qr.page */ "Rb1H");







let JoinByQrPageModule = class JoinByQrPageModule {
};
JoinByQrPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _join_by_qr_routing_module__WEBPACK_IMPORTED_MODULE_5__["JoinByQrPageRoutingModule"]
        ],
        declarations: [_join_by_qr_page__WEBPACK_IMPORTED_MODULE_6__["JoinByQrPage"]]
    })
], JoinByQrPageModule);



/***/ }),

/***/ "JduO":
/*!**************************************************************!*\
  !*** ./src/app/pages/course/join-by-qr/join-by-qr.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".scanner {\n  --background: none transparent !important;\n  background: none transparent !important;\n  --color: white;\n}\n.scanner ion-icon {\n  color: white;\n  font-size: 20px;\n}\n.scanner-button-bottom {\n  position: absolute;\n  bottom: 45px;\n  left: auto;\n  right: auto;\n  width: 100%;\n}\n.scanner-button-bottom .qr-scanner-button {\n  width: 75px;\n  height: 75px;\n  border-radius: 100%;\n  background: rgba(0, 0, 0, 0.3);\n}\n.qr-scanner-area {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 100%;\n  height: calc(100% - 45px - 103px);\n  background: url(\"/assets/img/course/scanner.svg\") no-repeat center;\n  background-size: 100% 100%;\n}\n.qr-scanner-area .lines {\n  width: 58%;\n  height: 2px;\n  background: var(--ion-color-primary);\n  animation: lines 2s linear infinite alternate;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcam9pbi1ieS1xci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSx5Q0FBQTtFQUNBLHVDQUFBO0VBQ0EsY0FBQTtBQUNKO0FBQUk7RUFDSSxZQUFBO0VBQ0EsZUFBQTtBQUVSO0FBQ0E7RUFDSSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxVQUFBO0VBQ0EsV0FBQTtFQUNBLFdBQUE7QUFFSjtBQURJO0VBQ0ksV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0FBR1I7QUFBQTtFQUNJLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsV0FBQTtFQUNBLGlDQUFBO0VBQ0Esa0VBQUE7RUFDQSwwQkFBQTtBQUdKO0FBRkk7RUFDSSxVQUFBO0VBQ0EsV0FBQTtFQUNBLG9DQUFBO0VBQ0EsNkNBQUE7QUFJUiIsImZpbGUiOiJqb2luLWJ5LXFyLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zY2FubmVyeyAgLy8g5LiA5a6a6KaB5bCGaW9uLWNvbnRlbnTorr7nva7kuLrog4zmma/pgI/mmI7vvIzlkKbliJnnnIvkuI3liLDmkYTlg4/lpLTnlLvpnaJcclxuICAgIC0tYmFja2dyb3VuZDogbm9uZSB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogbm9uZSB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgLS1jb2xvcjogd2hpdGU7XHJcbiAgICBpb24taWNvbnsgXHJcbiAgICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIH1cclxufVxyXG4uc2Nhbm5lci1idXR0b24tYm90dG9te1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgYm90dG9tOiA0NXB4O1xyXG4gICAgbGVmdDogYXV0bztcclxuICAgIHJpZ2h0OiBhdXRvO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICAucXItc2Nhbm5lci1idXR0b257XHJcbiAgICAgICAgd2lkdGg6IDc1cHg7XHJcbiAgICAgICAgaGVpZ2h0OiA3NXB4O1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDEwMCU7XHJcbiAgICAgICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwLjMpO1xyXG4gICAgfVxyXG59XHJcbi5xci1zY2FubmVyLWFyZWF7XHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IGNhbGMoMTAwJSAtIDQ1cHggLSAxMDNweCk7XHJcbiAgICBiYWNrZ3JvdW5kOiB1cmwoJy9hc3NldHMvaW1nL2NvdXJzZS9zY2FubmVyLnN2ZycpIG5vLXJlcGVhdCBjZW50ZXIgO1xyXG4gICAgYmFja2dyb3VuZC1zaXplOiAxMDAlIDEwMCU7XHJcbiAgICAubGluZXN7XHJcbiAgICAgICAgd2lkdGg6IDU4JTtcclxuICAgICAgICBoZWlnaHQ6IDJweDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgICAgICAgYW5pbWF0aW9uOiBsaW5lcyAycyBsaW5lYXIgaW5maW5pdGUgYWx0ZXJuYXRlO1xyXG4gICAgfVxyXG59Il19 */");

/***/ }),

/***/ "Rb1H":
/*!************************************************************!*\
  !*** ./src/app/pages/course/join-by-qr/join-by-qr.page.ts ***!
  \************************************************************/
/*! exports provided: JoinByQrPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "JoinByQrPage", function() { return JoinByQrPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_join_by_qr_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./join-by-qr.page.html */ "g10g");
/* harmony import */ var _join_by_qr_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./join-by-qr.page.scss */ "JduO");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let JoinByQrPage = class JoinByQrPage {
    constructor() { }
    ngOnInit() {
    }
};
JoinByQrPage.ctorParameters = () => [];
JoinByQrPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-join-by-qr',
        template: _raw_loader_join_by_qr_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_join_by_qr_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], JoinByQrPage);



/***/ }),

/***/ "g10g":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/join-by-qr/join-by-qr.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <!-- <ion-toolbar class=\"scanner\"> -->\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button (click)=\"closeModal()\" [routerLink]=\"['/tabs/course']\">\r\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-title>扫描中...</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content [class.scanner]=\"scannerClass\">\r\n  <div class=\"qr-scanner-area\">\r\n    <p class=\"lines\"></p>\r\n  </div>\r\n\r\n  <ion-grid fixed class=\"scanner-button-bottom\">\r\n    <ion-row>\r\n      <ion-col size=\"6\" class=\"ion-flex ion-justify-content-center\" style=\"text-align: center;\">\r\n        <ion-button fill=\"clear\" class=\"qr-scanner-button\" (click)=\"toogleLight()\">\r\n          <ion-icon slot=\"icon-only\" [name]=\"lightIcon\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n      <ion-col size=\"6\" class=\"ion-flex ion-justify-content-center\" style=\"text-align: center;\">\r\n         <ion-button fill=\"clear\" class=\"qr-scanner-button\" (click)=\"toggleCamera()\">\r\n          <ion-icon name=\"camera-reverse-outline\" slot=\"icon-only\"></ion-icon>\r\n        </ion-button>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n");

/***/ })

}]);
//# sourceMappingURL=join-by-qr-join-by-qr-module.js.map