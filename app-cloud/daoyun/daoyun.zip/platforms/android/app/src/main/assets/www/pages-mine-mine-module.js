(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-mine-mine-module"],{

/***/ "UHON":
/*!*******************************************!*\
  !*** ./src/app/pages/mine/mine.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJtaW5lLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "VjJe":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mine/mine.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\r\n<ion-content color=\"light\">\r\n  \r\n  <ion-card mode=\"ios\">\r\n    <ion-grid>\r\n        <ion-row style=\"width:100%;height:20px\"></ion-row>\r\n        <ion-row>\r\n            <ion-col size=\"2.5\">\r\n                <ion-avatar>\r\n                    <img src=\"../../../../assets/icon/head.png\">\r\n                </ion-avatar>\r\n            </ion-col>\r\n            <ion-col size=\"9.5\">\r\n                <ion-label>\r\n                    <h3>{{user.name}}{{isTeacher}}</h3>\r\n                </ion-label>\r\n            </ion-col>\r\n        </ion-row>\r\n    </ion-grid>\r\n    <ion-row style=\"width:100%;height:20px\"></ion-row>\r\n</ion-card>\r\n\r\n  <ion-list inset=\"true\">\r\n    <ion-item detail [routerLink]=\"['/mine/usermsg']\">\r\n      <ion-label>我的信息</ion-label>\r\n    </ion-item>\r\n    <ion-item detail [routerLink]=\"['/change-pass']\">\r\n      <ion-label>修改密码</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n  <ion-list inset=\"true\">\r\n    <ion-item detail [routerLink]=\"['/mine/about-us']\">\r\n      <ion-label>关于我们</ion-label>\r\n    </ion-item>\r\n    <ion-item detail>\r\n      <ion-label>联系客服</ion-label>\r\n      <ion-note slot=\"end\"><a href=\"tel:18050170860\">18050170860</a></ion-note>\r\n    </ion-item>\r\n    <ion-item detail (click)=\"checkUpdate()\">\r\n      <ion-label>版本号:{{version}}</ion-label>\r\n      <ion-note slot=\"end\">检测更新</ion-note>\r\n    </ion-item>\r\n  </ion-list>\r\n  <ion-list inset=\"true\">\r\n    <ion-item detail (click)=\"onLogout()\" [routerLink]=\"['/login']\">\r\n      <ion-label>安全退出</ion-label>\r\n    </ion-item>\r\n  </ion-list>\r\n  <!-- 其他省略 -->\r\n</ion-content>\r\n");

/***/ }),

/***/ "dg82":
/*!*******************************************!*\
  !*** ./src/app/pages/mine/mine.module.ts ***!
  \*******************************************/
/*! exports provided: MinePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MinePageModule", function() { return MinePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _mine_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./mine-routing.module */ "t0A+");
/* harmony import */ var _mine_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mine.page */ "j3ct");







let MinePageModule = class MinePageModule {
};
MinePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _mine_routing_module__WEBPACK_IMPORTED_MODULE_5__["MinePageRoutingModule"]
        ],
        declarations: [_mine_page__WEBPACK_IMPORTED_MODULE_6__["MinePage"]]
    })
], MinePageModule);



/***/ }),

/***/ "j3ct":
/*!*****************************************!*\
  !*** ./src/app/pages/mine/mine.page.ts ***!
  \*****************************************/
/*! exports provided: MinePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MinePage", function() { return MinePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_mine_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./mine.page.html */ "VjJe");
/* harmony import */ var _mine_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./mine.page.scss */ "UHON");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let MinePage = class MinePage {
    constructor() {
        this.user = {
            email: localStorage.getItem("email"),
            image: "1",
            role: "",
            sno: "",
            school: "0",
            sex: "0",
            telphone: "0",
            nickname: "0",
            name: "0",
            birth: "0",
            exp: "0"
        };
    }
    ngOnInit() {
    }
};
MinePage.ctorParameters = () => [];
MinePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-mine',
        template: _raw_loader_mine_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_mine_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MinePage);



/***/ }),

/***/ "t0A+":
/*!***************************************************!*\
  !*** ./src/app/pages/mine/mine-routing.module.ts ***!
  \***************************************************/
/*! exports provided: MinePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MinePageRoutingModule", function() { return MinePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _mine_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./mine.page */ "j3ct");




const routes = [
    {
        path: '',
        component: _mine_page__WEBPACK_IMPORTED_MODULE_3__["MinePage"]
    },
    {
        path: 'edit-usermsg',
        loadChildren: () => __webpack_require__.e(/*! import() | edit-usermsg-edit-usermsg-module */ "edit-usermsg-edit-usermsg-module").then(__webpack_require__.bind(null, /*! ./edit-usermsg/edit-usermsg.module */ "6/+Y")).then(m => m.EditUsermsgPageModule)
    },
    {
        path: 'usermsg',
        loadChildren: () => __webpack_require__.e(/*! import() | usermsg-usermsg-module */ "usermsg-usermsg-module").then(__webpack_require__.bind(null, /*! ./usermsg/usermsg.module */ "P8kf")).then(m => m.UsermsgPageModule)
    },
    {
        path: 'about-us',
        loadChildren: () => __webpack_require__.e(/*! import() | about-us-about-us-module */ "about-us-about-us-module").then(__webpack_require__.bind(null, /*! ./about-us/about-us.module */ "0UyS")).then(m => m.AboutUsPageModule)
    }
];
let MinePageRoutingModule = class MinePageRoutingModule {
};
MinePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MinePageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-mine-mine-module.js.map