(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["create-checkin-create-checkin-module"],{

/***/ "5OpY":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin.module.ts ***!
  \***********************************************************************/
/*! exports provided: CreateCheckinPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCheckinPageModule", function() { return CreateCheckinPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./create-checkin-routing.module */ "v79b");
/* harmony import */ var _create_checkin_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-checkin.page */ "atnx");







let CreateCheckinPageModule = class CreateCheckinPageModule {
};
CreateCheckinPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _create_checkin_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateCheckinPageRoutingModule"]
        ],
        declarations: [_create_checkin_page__WEBPACK_IMPORTED_MODULE_6__["CreateCheckinPage"]]
    })
], CreateCheckinPageModule);



/***/ }),

/***/ "5fTR":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/checkin/create-checkin/create-checkin.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/course/course-detail']\">\r\n          <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n      </ion-button>\r\n      </ion-buttons>\r\n    <ion-title>create-checkin</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "YDyG":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJjcmVhdGUtY2hlY2tpbi5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "atnx":
/*!*********************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin.page.ts ***!
  \*********************************************************************/
/*! exports provided: CreateCheckinPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCheckinPage", function() { return CreateCheckinPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-checkin.page.html */ "5fTR");
/* harmony import */ var _create_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-checkin.page.scss */ "YDyG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");




let CreateCheckinPage = class CreateCheckinPage {
    constructor() { }
    ngOnInit() {
    }
};
CreateCheckinPage.ctorParameters = () => [];
CreateCheckinPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-create-checkin',
        template: _raw_loader_create_checkin_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_checkin_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateCheckinPage);



/***/ }),

/***/ "v79b":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/checkin/create-checkin/create-checkin-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: CreateCheckinPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCheckinPageRoutingModule", function() { return CreateCheckinPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_checkin_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-checkin.page */ "atnx");




const routes = [
    {
        path: '',
        component: _create_checkin_page__WEBPACK_IMPORTED_MODULE_3__["CreateCheckinPage"]
    }
];
let CreateCheckinPageRoutingModule = class CreateCheckinPageRoutingModule {
};
CreateCheckinPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateCheckinPageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=create-checkin-create-checkin-module.js.map