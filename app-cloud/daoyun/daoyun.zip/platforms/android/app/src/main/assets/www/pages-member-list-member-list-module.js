(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-member-list-member-list-module"],{

/***/ "+A5s":
/*!*******************************************************!*\
  !*** ./src/app/pages/member-list/member-list.page.ts ***!
  \*******************************************************/
/*! exports provided: MemberListPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MemberListPage", function() { return MemberListPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_member_list_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./member-list.page.html */ "Gnhy");
/* harmony import */ var _member_list_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./member-list.page.scss */ "Sqc+");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let MemberListPage = class MemberListPage {
    constructor(modalController, router, httpService, http, alertController, loadingController, toastController, activatedRoute) {
        this.modalController = modalController;
        this.router = router;
        this.httpService = httpService;
        this.http = http;
        this.alertController = alertController;
        this.loadingController = loadingController;
        this.toastController = toastController;
        this.activatedRoute = activatedRoute;
        this.lesson = {
            no: '888888',
            name: '工程训练'
        };
        this.isNo = '1';
        this.member = [];
        this.memberNo = 0;
        this.flag = '0';
        this.activatedRoute.queryParams.subscribe(queryParams => {
            if (queryParams.isFlash == '1') {
                this.getdata();
            }
        });
    }
    ngOnInit() {
        this.getdata();
    }
    ionViewWillEnter() {
        this.getdata();
    }
    getdata() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // this.lesson.name = localStorage.getItem("lesson_name");
            // this.lesson.no = localStorage.getItem("lesson_no");
            this.isTeacher = localStorage.getItem("isTeacher");
            if (this.isTeacher == '1') {
                this.orderByNo();
            }
            else {
                this.orderByExp();
            }
            //个人排名与经验值
            var params = {
                code: localStorage.getItem("lesson_no"),
                order: "0",
                email: localStorage.getItem("email")
            };
            var api = '/courses/member'; //后台接口
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.rank = response.data.rank;
                this.my_exp = response.data.exp;
            }));
        });
    }
    orderByNo() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isNo = '0';
            localStorage.setItem("isNo", "1");
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            //按学号排序List
            var params = {
                code: localStorage.getItem("lesson_no"),
                order: "1" //按学号顺序显示
            };
            var api = '/courses/member'; //后台接口
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                if (response.data.respCode == "该课程没有学生") {
                    this.flag = '0';
                }
                else {
                    this.flag = '1';
                    this.member = response.data;
                    this.memberNo = this.member.length;
                }
            })).catch(function (error) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    const alert = yield this.alertController.create({
                        header: '警告',
                        message: '请求失败！',
                        buttons: ['确认']
                    });
                    yield alert.present();
                });
            });
        });
    }
    orderByExp() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.isNo = '1';
            localStorage.setItem("isNo", "0");
            //按经验值排序list
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present(); //加载
            var params = {
                code: localStorage.getItem("lesson_no"),
                order: "0" //按经验值顺序显示
            };
            var api = '/courses/member'; //后台接口
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                if (response.data.respCode == "该课程没有学生") {
                    this.flag = '0';
                }
                else {
                    this.flag = '1';
                    this.member = response.data;
                    this.memberNo = this.member.length;
                }
            })).catch(function (error) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    const alert = yield this.alertController.create({
                        header: '警告',
                        message: '请求失败！',
                        buttons: ['确认']
                    });
                    yield alert.present();
                });
            });
        });
    }
    // async searchMember() {
    //   //弹出搜索模态框
    //   const modal = await this.modalController.create({
    //     component: SearchMemberComponent,
    //     componentProps: {
    //       type: '按照姓名、学号检索'
    //     }
    //   });
    //   await modal.present();
    // }
    gotoCheck() {
        this.router.navigateByUrl('student-checkin');
    }
};
MemberListPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] }
];
MemberListPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-member-list',
        template: _raw_loader_member_list_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_member_list_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], MemberListPage);



/***/ }),

/***/ "7B2Y":
/*!*****************************************************************!*\
  !*** ./src/app/pages/member-list/member-list-routing.module.ts ***!
  \*****************************************************************/
/*! exports provided: MemberListPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MemberListPageRoutingModule", function() { return MemberListPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _member_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./member-list.page */ "+A5s");




const routes = [
    {
        path: '',
        component: _member_list_page__WEBPACK_IMPORTED_MODULE_3__["MemberListPage"]
    },
    {
        path: 'member-checkin',
        loadChildren: () => __webpack_require__.e(/*! import() | member-checkin-member-checkin-module */ "member-checkin-member-checkin-module").then(__webpack_require__.bind(null, /*! ./member-checkin/member-checkin.module */ "QCxY")).then(m => m.MemberCheckinPageModule)
    }
];
let MemberListPageRoutingModule = class MemberListPageRoutingModule {
};
MemberListPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], MemberListPageRoutingModule);



/***/ }),

/***/ "Gnhy":
/*!***********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/member-list/member-list.page.html ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar *ngIf=\"isTeacher == '1'\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/course/course-detail']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title color=\"medium\" style=\"text-align:center;margin-right: 30px;\">{{lesson.name}}</ion-title>\r\n  </ion-toolbar>\r\n\r\n  <ion-toolbar color=\"primary\" *ngIf=\"isTeacher == '0'\">\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"light\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/course/course-detail']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">{{lesson.name}}</ion-title>\r\n  </ion-toolbar>\r\n\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-toolbar *ngIf=\"isTeacher=='0'\"\r\n      style=\"--background:linear-gradient(#7468be 0%,#7468be 60%,white 60%,white 100%);--border-width: 0 0 0px;\">\r\n      <!-- <div style=\"width:100%；height：100px;color:blue\"></div> -->\r\n      <div style=\"width: 100%;height: 20px;opacity: 0;\"></div>\r\n      <ion-grid>\r\n          <ion-row class=\"text1\">\r\n              <ion-label>第{{rank}}名</ion-label>\r\n          </ion-row>\r\n          <ion-row class=\"text2\">\r\n              <ion-label>当前获得{{my_exp}}经验值</ion-label>\r\n          </ion-row>\r\n      </ion-grid>\r\n      <ion-card mode=\"ios\" (click)=\"gotoCheck()\">\r\n          <ion-item lines=\"none\">\r\n              <ion-avatar class=\"my-thum\">\r\n                  <!-- <ion-avatar class=\"my-thum\" [routerLink]=\"['/student-checkin']\"> -->\r\n                  <ion-icon class=\"my-thum-icon\" color=\"light\" name=\"calendar-outline\"></ion-icon>\r\n              </ion-avatar>\r\n          </ion-item>\r\n          <ion-item lines=\"none\">\r\n              <ion-label style=\"text-align: center;margin-top: 8px;\">\r\n                  <h2>签到记录</h2>\r\n              </ion-label>\r\n          </ion-item>\r\n      </ion-card>\r\n  </ion-toolbar>\r\n\r\n  <ion-toolbar *ngIf=\"isTeacher=='1'\">\r\n      <ion-item lines=\"none\" style=\"--background: #80808024;color:#7468be\">\r\n          <p slot=\"start\" *ngIf=\"isNo=='1'\" (click)=\"orderByNo()\">切换为按学号升序显示</p>\r\n          <p slot=\"start\" *ngIf=\"isNo=='0'\" (click)=\"orderByExp()\">切换为按经验值降序显示</p>\r\n      </ion-item>\r\n  </ion-toolbar>\r\n\r\n  <div *ngIf=\"flag == '1'\">\r\n      <ion-list>\r\n          <ion-item lines=\"full\">\r\n              <ion-label>\r\n                  <p>成员总数</p>\r\n              </ion-label>\r\n              <ion-label style=\"text-align: -webkit-right;\">\r\n                  <p>{{memberNo}}人</p>\r\n              </ion-label>\r\n          </ion-item>\r\n          <ion-item *ngFor=\"let item of member;let i = index\" style=\"margin:5px 0px;\"\r\n          routerLink=\"/student-checkin\" [queryParams]=\"{historyFlag:'1',studentEmail:item.email}\">\r\n              <h3 style=\"color: #7468be;\">{{item.index+1}}&nbsp;&nbsp;</h3>\r\n              <ion-thumbnail>\r\n                  <img src=\"assets/icon/head.png\">\r\n              </ion-thumbnail>\r\n              <ion-label>\r\n                  <h3>\r\n                      &nbsp;&nbsp;{{item.name}}&nbsp;&nbsp;\r\n                      <ion-icon *ngIf=\"item.sex=='1'\" name=\"female-outline\" style=\"color:#ed576b\"></ion-icon>\r\n                      <ion-icon *ngIf=\"item.sex=='0'\" name=\"male-outline\" style=\"color:#3dc2ff\"></ion-icon>\r\n                  </h3>\r\n                  <p>&nbsp;&nbsp;{{item.sno}}</p>\r\n              </ion-label>\r\n              <ion-label style=\"text-align: -webkit-right;color:#ed9c57;\">\r\n                  <h2>{{item.exp}}&nbsp;经验值</h2>\r\n              </ion-label>\r\n          </ion-item>\r\n      </ion-list>\r\n  </div>\r\n\r\n  <div *ngIf=\"flag == '0'\">\r\n      <ion-grid>\r\n          <ion-item lines=\"none\"></ion-item>\r\n          <ion-row>\r\n            <ion-col></ion-col>\r\n            <ion-col>\r\n              <img src=\"assets/img/components/empty.png\">\r\n            </ion-col>\r\n            <ion-col></ion-col>\r\n          </ion-row>\r\n          <ion-row>\r\n            <ion-col></ion-col>\r\n            <ion-col>\r\n              <ion-label style=\"text-align: center;\">\r\n                <p>当前课程还没有学生哦~</p>\r\n              </ion-label>\r\n            </ion-col>\r\n            <ion-col></ion-col>\r\n          </ion-row>\r\n        </ion-grid>\r\n  </div>\r\n</ion-content>\r\n");

/***/ }),

/***/ "Sqc+":
/*!*********************************************************!*\
  !*** ./src/app/pages/member-list/member-list.page.scss ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".circle {\n  margin: auto;\n  line-height: 85px;\n  font-size: 30px;\n  width: 80px;\n  height: 80px;\n}\n\n.my-thum {\n  text-align: center;\n  background-color: #7468be;\n  width: 80px;\n  height: 80px;\n  margin: auto;\n  margin-top: 10px;\n}\n\n.my-thum-icon {\n  margin: auto;\n  line-height: 85px;\n  font-size: 30px;\n  width: 50%;\n  height: 100%;\n}\n\n.text1 {\n  font-size: 28px;\n  text-align: center;\n  display: block;\n  color: var(--ion-color-primary-contrast);\n}\n\n.text2 {\n  margin-top: 10px;\n  font-size: 14px;\n  text-align: center;\n  display: block;\n  color: var(--ion-color-primary-contrast);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxtZW1iZXItbGlzdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxlQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7QUFDSjs7QUFFQTtFQUNJLGtCQUFBO0VBQ0EseUJBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLFlBQUE7RUFDQSxnQkFBQTtBQUFKOztBQUdBO0VBQ0ksWUFBQTtFQUNBLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLFVBQUE7RUFDQSxZQUFBO0FBQUo7O0FBR0E7RUFDSSxlQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0Esd0NBQUE7QUFBSjs7QUFHQTtFQUNJLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLHdDQUFBO0FBQUoiLCJmaWxlIjoibWVtYmVyLWxpc3QucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNpcmNsZXtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIGxpbmUtaGVpZ2h0OiA4NXB4O1xyXG4gICAgZm9udC1zaXplOiAzMHB4O1xyXG4gICAgd2lkdGg6IDgwcHg7XHJcbiAgICBoZWlnaHQ6IDgwcHg7XHJcbn1cclxuXHJcbi5teS10aHVte1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzc0NjhiZTtcclxuICAgIC8vIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgIHdpZHRoOiA4MHB4O1xyXG4gICAgaGVpZ2h0OjgwcHg7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBtYXJnaW4tdG9wOjEwcHg7XHJcbn1cclxuXHJcbi5teS10aHVtLWljb257XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICBsaW5lLWhlaWdodDogODVweDtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIHdpZHRoOiA1MCU7XHJcbiAgICBoZWlnaHQ6IDEwMCU7XHJcbn1cclxuXHJcbi50ZXh0MXtcclxuICAgIGZvbnQtc2l6ZTogMjhweDtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1wcmltYXJ5LWNvbnRyYXN0KTtcclxufVxyXG5cclxuLnRleHQye1xyXG4gICAgbWFyZ2luLXRvcDoxMHB4O1xyXG4gICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgZGlzcGxheTogYmxvY2s7XHJcbiAgICBjb2xvcjogdmFyKC0taW9uLWNvbG9yLXByaW1hcnktY29udHJhc3QpO1xyXG59Il19 */");

/***/ }),

/***/ "gkKl":
/*!*********************************************************!*\
  !*** ./src/app/pages/member-list/member-list.module.ts ***!
  \*********************************************************/
/*! exports provided: MemberListPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MemberListPageModule", function() { return MemberListPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _member_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./member-list-routing.module */ "7B2Y");
/* harmony import */ var _member_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./member-list.page */ "+A5s");







let MemberListPageModule = class MemberListPageModule {
};
MemberListPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _member_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["MemberListPageRoutingModule"]
        ],
        declarations: [_member_list_page__WEBPACK_IMPORTED_MODULE_6__["MemberListPage"]]
    })
], MemberListPageModule);



/***/ })

}]);
//# sourceMappingURL=pages-member-list-member-list-module.js.map