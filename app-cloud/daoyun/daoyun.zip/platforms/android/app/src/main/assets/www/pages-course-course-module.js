(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-course-course-module"],{

/***/ "ETWM":
/*!***********************************************!*\
  !*** ./src/app/pages/course/course.module.ts ***!
  \***********************************************/
/*! exports provided: CoursePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursePageModule", function() { return CoursePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _course_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./course-routing.module */ "xKYt");
/* harmony import */ var _course_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./course.page */ "FK+3");







let CoursePageModule = class CoursePageModule {
};
CoursePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _course_routing_module__WEBPACK_IMPORTED_MODULE_5__["CoursePageRoutingModule"]
        ],
        declarations: [_course_page__WEBPACK_IMPORTED_MODULE_6__["CoursePage"]]
    })
], CoursePageModule);



/***/ }),

/***/ "FK+3":
/*!*********************************************!*\
  !*** ./src/app/pages/course/course.page.ts ***!
  \*********************************************/
/*! exports provided: CoursePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursePage", function() { return CoursePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_course_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./course.page.html */ "UKbt");
/* harmony import */ var _course_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./course.page.scss */ "FYxu");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_components_search_course_search_course_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/components/search-course/search-course.component */ "STZ0");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");









let CoursePage = class CoursePage {
    constructor(httpService, http, modalController, router, actionSheetController, loadingController) {
        this.httpService = httpService;
        this.http = http;
        this.modalController = modalController;
        this.router = router;
        this.actionSheetController = actionSheetController;
        this.loadingController = loadingController;
        this.list = [];
        this.page_max = 10;
        this.page = 1;
        this.total = 0;
        this.flag = 0; //标记当前用户的课程是否抓取完全
    }
    ngOnInit() {
        this.isTeacher = localStorage.getItem("isTeacher");
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------列表信息展示-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    ionViewWillEnter() {
        this.initData();
    }
    initData() {
        this.list = [];
        this.page = 1;
        this.total = 0;
        this.flag = 0;
        this.getCourse();
    }
    getCourse() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            var params = {
                page: this.page
            };
            var api = '/course';
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                //console.log(response);
                this.total = response.data.data.total;
                if (response.data.data.list.length < this.page_max) {
                    this.flag = 1;
                }
                for (let i = 0; i < response.data.data.list.length; i++) {
                    this.list.push(response.data.data.list[i]);
                }
            })).catch(function (error) {
                return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                    const alert = yield this.alertController.create({
                        header: '警告',
                        message: '请求失败！',
                        buttons: ['确认']
                    });
                    yield alert.present();
                });
            });
        });
    }
    loadData(event) {
        setTimeout(() => {
            if (this.flag == 1) {
                event.target.disabled = true;
            }
            else {
                this.page = this.page + 1;
                this.getCourse();
            }
            event.target.complete();
        }, 500);
    }
    doRefresh(event) {
        this.initData();
        setTimeout(() => {
            event.target.complete();
        }, 500);
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //----------------------------------------------------一些跳转&搜索----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    search(type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //弹出搜索模态框
            const modal = yield this.modalController.create({
                component: src_app_shared_components_search_course_search_course_component__WEBPACK_IMPORTED_MODULE_7__["SearchCourseComponent"],
                componentProps: {
                    type: type
                }
            });
            yield modal.present();
        });
    }
    AddorCreate() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.isTeacher == 1) { //教师
                const actionSheet = yield this.actionSheetController.create({
                    mode: "ios",
                    buttons: [
                        {
                            text: '创建课程',
                            handler: () => {
                                this.router.navigateByUrl('/course/create-course');
                            }
                        },
                        {
                            text: '取消',
                            role: 'destructive'
                        }
                    ]
                });
                yield actionSheet.present();
            }
            else {
                const actionSheet = yield this.actionSheetController.create({
                    mode: "ios",
                    buttons: [
                        {
                            text: '使用课程号加入课程',
                            handler: () => {
                                this.router.navigateByUrl('/course/join-by-code');
                            }
                        },
                        {
                            text: '使用二维码加入课程',
                            handler: () => {
                                this.router.navigateByUrl('/course/join-by-qr');
                            }
                        },
                        {
                            text: '取消',
                            role: 'destructive'
                        }
                    ]
                });
                yield actionSheet.present();
            }
        });
    }
    gotodetail(index) {
        //console.log(index);
        this.router.navigate(['/course/course-detail'], { queryParams: { code: this.list[index].code } });
    }
};
CoursePage.ctorParameters = () => [
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_8__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
CoursePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-course',
        template: _raw_loader_course_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_course_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CoursePage);



/***/ }),

/***/ "FYxu":
/*!***********************************************!*\
  !*** ./src/app/pages/course/course.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-backdrop {\n  opacity: 0.3;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFxjb3Vyc2UucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksWUFBQTtBQUNKIiwiZmlsZSI6ImNvdXJzZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tYmFja2Ryb3Age1xyXG4gICAgb3BhY2l0eTogMC4zO1xyXG4gIH0iXX0= */");

/***/ }),

/***/ "UKbt":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/course.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-title *ngIf=\"isTeacher==1\" color=\"primary\" style=\"text-align:left\">我创建的课程列表</ion-title>\r\n      <ion-title *ngIf=\"isTeacher==0\" color=\"primary\" style=\"text-align:left\">我加入的课程列表</ion-title>\r\n      <ion-button slot=\"end\" (click)=\"AddorCreate()\" fill=\"clear\">\r\n          <ion-icon slot=\"icon-only\" name=\"add\"></ion-icon>\r\n      </ion-button>\r\n  </ion-toolbar>\r\n\r\n  <ion-toolbar>\r\n      <ion-searchbar class=\"searchbar\" placeholder=\"通过课程名/课程号搜索\" (click)=\"search()\">\r\n      </ion-searchbar>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n    <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\r\n        <ion-refresher-content \r\n         pullingIcon=\"chevron-down\">\r\n        </ion-refresher-content>\r\n    </ion-refresher>\r\n\r\n    <div *ngIf=\"total!=0\">\r\n        <ion-list id=\"list\" lines=\"full\" *ngFor=\"let item of list; let i=index\">\r\n\r\n            <ion-item style=\"width:100%\">\r\n                <ion-grid>\r\n                    <ion-row (click)=\"gotodetail(i)\">\r\n\r\n                        <ion-col size=\"2\">\r\n                            <ion-thumbnail class=\"thum\" *ngIf=\"item.image != 'image_null'\">\r\n                                <img src={{item.image}}>\r\n                            </ion-thumbnail>\r\n                            <ion-thumbnail class=\"thum\" *ngIf=\"item.image == 'image_null'\">\r\n                                <img src=\"assets/img/course/cover-default.jpg\">\r\n                            </ion-thumbnail>\r\n                        </ion-col>\r\n\r\n                        <ion-col size=\"9\">\r\n                            <ion-label>\r\n                                <ion-text style=\"color: black;\">&nbsp;&nbsp;&nbsp;{{item.name}}</ion-text>\r\n                                <p>&nbsp;&nbsp;&nbsp;{{item.code}}&nbsp;&nbsp;&nbsp;{{item.teacher}}</p>\r\n                            </ion-label>\r\n                        </ion-col>\r\n\r\n                        <ion-col size=\"1\">\r\n                            <ion-icon solt=\"end\" name=\"chevron-forward-outline\" color=\"primary\"\r\n                            style=\"margin-top: 50%; font-size: large;\"></ion-icon>\r\n                        </ion-col>\r\n\r\n                    </ion-row>\r\n                </ion-grid>\r\n            </ion-item>\r\n\r\n        </ion-list>\r\n\r\n        <ion-item *ngIf=\"flag==1\" lines=\"none\">\r\n            <ion-label style=\"text-align: center;\">\r\n                 <p>你已经看到我的底线啦~</p>\r\n            </ion-label>\r\n        </ion-item>\r\n\r\n        <ion-infinite-scroll threshold=\"10%\" id=\"infinite-scroll\" (ionInfinite)=\"loadData($event)\">\r\n            <ion-infinite-scroll-content\r\n                loading-spinner=\"bubbles\" loading-text=\"加载中...\">\r\n            </ion-infinite-scroll-content>\r\n        </ion-infinite-scroll>\r\n\r\n    </div>\r\n\r\n    <div *ngIf=\"total==0 && flag==1\">\r\n        <ion-grid>\r\n            <ion-item lines=\"none\"></ion-item>\r\n            <ion-item lines=\"none\"></ion-item>\r\n            \r\n            <ion-row>\r\n                <ion-col></ion-col>\r\n                <ion-col><img src=\"assets/img/components/empty.png\"></ion-col>\r\n                <ion-col></ion-col>\r\n            </ion-row>\r\n\r\n            <ion-row>\r\n                <ion-col>\r\n                    <ion-label style=\"text-align: center;\" *ngIf=\"isTeacher==1\">\r\n                        <p>你还没有创建班课</p>\r\n                        <p>快点击右上方相应图标创建班课吧~</p>\r\n                    </ion-label>\r\n                    <ion-label style=\"text-align: center;\" *ngIf=\"isTeacher==0\">\r\n                        <p>你还没有加入班课</p>\r\n                        <p>快点击右上方相应图标加入班课吧~</p>\r\n                    </ion-label>\r\n                </ion-col>\r\n            </ion-row>\r\n\r\n        </ion-grid>\r\n\r\n    </div>\r\n    \r\n</ion-content>");

/***/ }),

/***/ "xKYt":
/*!*******************************************************!*\
  !*** ./src/app/pages/course/course-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: CoursePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CoursePageRoutingModule", function() { return CoursePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _course_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./course.page */ "FK+3");




const routes = [
    {
        path: '',
        component: _course_page__WEBPACK_IMPORTED_MODULE_3__["CoursePage"]
    },
    {
        path: 'create-course',
        loadChildren: () => __webpack_require__.e(/*! import() | create-course-create-course-module */ "create-course-create-course-module").then(__webpack_require__.bind(null, /*! ./create-course/create-course.module */ "4nSL")).then(m => m.CreateCoursePageModule)
    },
    {
        path: 'join-by-code',
        loadChildren: () => __webpack_require__.e(/*! import() | join-by-code-join-by-code-module */ "join-by-code-join-by-code-module").then(__webpack_require__.bind(null, /*! ./join-by-code/join-by-code.module */ "afBY")).then(m => m.JoinByCodePageModule)
    },
    {
        path: 'join-by-qr',
        loadChildren: () => __webpack_require__.e(/*! import() | join-by-qr-join-by-qr-module */ "join-by-qr-join-by-qr-module").then(__webpack_require__.bind(null, /*! ./join-by-qr/join-by-qr.module */ "AaI+")).then(m => m.JoinByQrPageModule)
    },
    {
        path: 'create-success',
        loadChildren: () => __webpack_require__.e(/*! import() | create-success-create-success-module */ "create-success-create-success-module").then(__webpack_require__.bind(null, /*! ./create-success/create-success.module */ "Uzlm")).then(m => m.CreateSuccessPageModule)
    },
    {
        path: 'course-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | course-detail-course-detail-module */ "course-detail-course-detail-module").then(__webpack_require__.bind(null, /*! ./course-detail/course-detail.module */ "TqLA")).then(m => m.CourseDetailPageModule)
    },
    {
        path: 'edit-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | edit-detail-edit-detail-module */ "edit-detail-edit-detail-module").then(__webpack_require__.bind(null, /*! ./edit-detail/edit-detail.module */ "rMfX")).then(m => m.EditDetailPageModule)
    },
];
let CoursePageRoutingModule = class CoursePageRoutingModule {
};
CoursePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CoursePageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=pages-course-course-module.js.map