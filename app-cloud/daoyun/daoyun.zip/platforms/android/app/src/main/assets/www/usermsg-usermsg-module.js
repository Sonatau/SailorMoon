(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["usermsg-usermsg-module"],{

/***/ "1jLg":
/*!**************************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg-routing.module.ts ***!
  \**************************************************************/
/*! exports provided: UsermsgPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsermsgPageRoutingModule", function() { return UsermsgPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _usermsg_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./usermsg.page */ "w++B");




const routes = [
    {
        path: '',
        component: _usermsg_page__WEBPACK_IMPORTED_MODULE_3__["UsermsgPage"]
    }
];
let UsermsgPageRoutingModule = class UsermsgPageRoutingModule {
};
UsermsgPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], UsermsgPageRoutingModule);



/***/ }),

/***/ "BFBO":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/mine/usermsg/usermsg.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n        <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/tabs/mine']\">\r\n            <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n        </ion-button>\r\n    </ion-buttons>\r\n      <ion-title style=\"text-align:center;\">我的信息</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <!-- <ion-list> -->\r\n  <!-- <ion-item-divider style=\"padding: 0px;\"> -->\r\n  <!-- <ion-item lines=\"none\" style=\"padding: 0px 0px;\"> -->\r\n  <!-- <ion-item lines=\"none\"></ion-item> -->\r\n  \r\n  <!-- </ion-item> -->\r\n  <!-- </ion-list> -->\r\n\r\n  <ion-list lines=\"full\">\r\n      <!-- <ion-item-divider>\r\n      </ion-item-divider> -->\r\n      <ion-item slot=\"end\">\r\n          <ion-label>姓名</ion-label>\r\n          <ion-input class=\"my_inf\" slot=\"end\" type=\"text\" placeholder=\"未设置\" [(ngModel)]=\"user.name\"></ion-input>\r\n      </ion-item>\r\n      <ion-item slot=\"end\">\r\n          <ion-label>昵称</ion-label>\r\n          <ion-input class=\"my_inf\" slot=\"end\" type=\"text\" placeholder=\"未设置\" [(ngModel)]=\"user.nickname\"></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item>\r\n          <ion-label>工号</ion-label>\r\n          <ion-input class=\"my_inf\" slot=\"end\" type=\"text\" placeholder=\"未设置\" [(ngModel)]=\"user.sno\"></ion-input>\r\n      </ion-item>\r\n\r\n      <ion-item>\r\n          <ion-label>手机号</ion-label>\r\n          <ion-input class=\"my_inf\" slot=\"end\" type=\"text\" placeholder=\"未设置\" [(ngModel)]=\"user.telphone\"></ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n          <!-- <ion-item> -->\r\n          <ion-label>出生年月</ion-label>\r\n          <ion-datetime slot=\"end\" value=\"1990-02-19\" placeholder=\"未设置\" [(ngModel)]=\"user.birth\"\r\n              displayFormat=\"YYYY-MM-DD\" cancelText=\"取消\" doneText=\"确认\"></ion-datetime>\r\n          <!-- </ion-item> -->\r\n          <!-- <ion-label>出生年月</ion-label>\r\n    <ion-input class=\"my_inf\" slot=\"end\" type=\"text\" placeholder=\"未设置\" [(ngModel)]=\"user.birth\"></ion-input> -->\r\n      </ion-item>\r\n      <ion-radio-group [(ngModel)]=\"user.sex\" mode=\"md\">\r\n          <ion-item>\r\n              <ion-label>性别</ion-label>\r\n              <ion-radio color=\"success\" value=\"0\" style=\"margin-left: 100px;\"></ion-radio>\r\n              <ion-label style=\"margin-left: 15px;\">男</ion-label>\r\n              <ion-radio color=\"tertiary\" value=\"1\"></ion-radio>\r\n              <ion-label style=\"margin-left: 15px;\">女</ion-label>\r\n              <!-- <ion-input class=\"my_inf\" slot=\"end\" type=\"text\" placeholder=\"未设置\" [(ngModel)]=\"user.sex\"></ion-input> -->\r\n          </ion-item>\r\n      </ion-radio-group>\r\n      <ion-item style=\"border-top: solid 0.5px #afb2bd;\" (click)=\"openPicker(1,schoolOptions,school,1)\">\r\n          <ion-label>学校</ion-label>\r\n          <ion-label class=\"my_inf\" slot=\"end\">{{schoolChoosed}}</ion-label>\r\n      </ion-item>\r\n      <ion-item (click)=\"openPicker(1,academyOptions,academy,0)\">\r\n          <ion-label>学院</ion-label>\r\n          <ion-label class=\"my_inf\" slot=\"end\">{{academyChoosed}}</ion-label>\r\n      </ion-item>\r\n      <ion-item lines=\"none\">\r\n      </ion-item>\r\n  </ion-list>\r\n  <ion-row style=\"margin: top 30px;\" class=\"row\">\r\n    <ion-button class=\"btn\" color=\"primary\"\r\n    [routerLink]=\"['/mine/edit-usermsg']\">修改个人信息\r\n    </ion-button>\r\n    </ion-row>\r\n</ion-content>\r\n");

/***/ }),

/***/ "P8kf":
/*!******************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg.module.ts ***!
  \******************************************************/
/*! exports provided: UsermsgPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsermsgPageModule", function() { return UsermsgPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _usermsg_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./usermsg-routing.module */ "1jLg");
/* harmony import */ var _usermsg_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./usermsg.page */ "w++B");







let UsermsgPageModule = class UsermsgPageModule {
};
UsermsgPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _usermsg_routing_module__WEBPACK_IMPORTED_MODULE_5__["UsermsgPageRoutingModule"]
        ],
        declarations: [_usermsg_page__WEBPACK_IMPORTED_MODULE_6__["UsermsgPage"]]
    })
], UsermsgPageModule);



/***/ }),

/***/ "d8Zw":
/*!******************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".logout-row {\n  margin: auto;\n  width: 100%;\n  margin-top: 20px;\n  width: 90%;\n  border-radius: 10px;\n  border: solid 1px red;\n  margin: auto;\n}\n\n.save-row {\n  margin: auto;\n  width: 100%;\n  margin-top: 20px;\n  width: 90%;\n  border-radius: 10px;\n  border: solid 1px #36abe0;\n  margin: auto;\n}\n\n.logout-btn {\n  margin: auto;\n  width: 80%;\n  color: red;\n}\n\n.save-btn {\n  margin: auto;\n  width: 80%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcdXNlcm1zZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EscUJBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBRUE7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdCQUFBO0VBQ0EsVUFBQTtFQUNBLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxZQUFBO0FBQ0o7O0FBQ0E7RUFDSSxZQUFBO0VBQ0EsVUFBQTtFQUNBLFVBQUE7QUFFSjs7QUFFQTtFQUNJLFlBQUE7RUFDQSxVQUFBO0FBQ0oiLCJmaWxlIjoidXNlcm1zZy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubG9nb3V0LXJvdyB7XHJcbiAgICBtYXJnaW46IGF1dG87XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJvcmRlcjogc29saWQgMXB4IHJlZDtcclxuICAgIG1hcmdpbjogYXV0bztcclxufVxyXG5cclxuLnNhdmUtcm93e1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gICAgd2lkdGg6IDkwJTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBib3JkZXI6IHNvbGlkIDFweCAjMzZhYmUwO1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG59XHJcbi5sb2dvdXQtYnRuIHtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICBjb2xvcjogcmVkO1xyXG4gICAgLy8gaGVpZ2h0Oi13ZWJraXQtZmlsbC1hdmFpbGFibGU7XHJcbn1cclxuXHJcbi5zYXZlLWJ0bntcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgICAvLyBjb2xvcjogcmVkO1xyXG4gICAgLy8gY29sb3I6IHJlZDtcclxufSJdfQ== */");

/***/ }),

/***/ "w++B":
/*!****************************************************!*\
  !*** ./src/app/pages/mine/usermsg/usermsg.page.ts ***!
  \****************************************************/
/*! exports provided: UsermsgPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UsermsgPage", function() { return UsermsgPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_usermsg_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./usermsg.page.html */ "BFBO");
/* harmony import */ var _usermsg_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usermsg.page.scss */ "d8Zw");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");








let UsermsgPage = class UsermsgPage {
    constructor(router, httpService, http, alertController, pickerController, toast, activatedRoute, loadingController) {
        this.router = router;
        this.httpService = httpService;
        this.http = http;
        this.alertController = alertController;
        this.pickerController = pickerController;
        this.toast = toast;
        this.activatedRoute = activatedRoute;
        this.loadingController = loadingController;
        this.user = {
            email: localStorage.getItem("email"),
            image: "1",
            role: "",
            sno: "",
            school: "0",
            sex: "0",
            telphone: "0",
            nickname: "0",
            name: "0",
            birth: "0",
            exp: "0"
        };
        // pickerController = document.querySelector('ion-picker-controller');
        this.school = [[]];
        this.academy = [[]];
        this.schoolList = {};
        this.academyList = {};
        this.flag = 0;
        this.schoolChoosed = "未设置";
        this.academyChoosed = "未设置";
        this.schoolOptions = 0;
        this.academyOptions = 0;
    }
    ngOnInit() {
        // this.getInf()
        // this.activatedRoute.queryParams.subscribe(async queryParams => {
        //   this.getInf()
        // });
    }
    //获取个人信息
    getInf() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            var params = {
                email: localStorage.getItem("email"),
            };
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            var api = '/user/info'; //后台接口
            this.httpService.get(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                if (response.status == 200) {
                    // console.log(response.data);
                    this.user = response.data;
                    this.user["sex"] = response.data.sex.toString();
                    this.user["email"] = localStorage.getItem("email");
                    if (response.data.role == 0) {
                        this.isTeacher = "(教师)";
                    }
                    else {
                        this.isTeacher = "(学生)";
                    }
                    //获取学校名称
                    if (response.data.name == 0) {
                        this.user.name = "";
                    }
                    if (response.data.nickname == 0) {
                        this.user.nickname = "";
                    }
                    if (response.data.sno == 0) {
                        this.user.sno = "";
                    }
                    if (response.data.telphone == 0) {
                        this.user.telphone = "";
                    }
                    if (this.user.school == null || this.user.school == "") {
                        this.schoolChoosed = "未设置";
                    }
                    else {
                        var str = this.user.school.split("/");
                        var api = '/schools/getCode'; //后台接口
                        this.httpService.get(api, { code: str[0] }).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                            this.schoolChoosed = response.data;
                            if (this.schoolChoosed != "未设置") {
                                //获取学院列表
                                this.academy[0].length = 0;
                                var param1 = {
                                    schoolCode: str[0],
                                };
                                // this.academyChoosed = '未设置';
                                var api = '/schools'; //后台接口
                                this.httpService.get(api, param1).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                                    for (var i = 0; i < response.data.length; i++) {
                                        this.academy[0].push(response.data[i].name);
                                    }
                                    this.academyList = response.data;
                                    this.academyOptions = this.academy[0].length;
                                }));
                            }
                        }));
                        if (JSON.stringify(str[1]) != "") {
                            yield loading.dismiss();
                            this.httpService.get(api, { code: str[1] }).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                                this.academyChoosed = response.data;
                            }));
                        }
                    }
                }
            }));
            //获取学校列表
            this.school[0].length = 0;
            var param = {
                school: 1,
            };
            var api = '/schools'; //后台接口
            this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                this.schoolList = response.data;
                for (var i = 0; i < response.data.length; i++) {
                    this.school[0].push(response.data[i].name);
                }
                this.schoolOptions = this.school[0].length;
            }));
        });
    }
    //编辑个人信息
    updateInf() {
        // if (form.valid) {
        var params = {
            email: this.user.email,
            image: "0",
            sno: this.user.sno,
            school: this.user.school,
            sex: this.user.sex,
            nickname: this.user.nickname,
            telphone: this.user.telphone,
            name: this.user.name,
            birth: this.user.birth,
        };
        console.log(params);
        var api = '/user/info'; //后台接口
        this.httpService.put(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            console.log(response);
            if (response.data.respCode == 1) {
                let alert = yield this.alertController.create({
                    header: '提示',
                    message: '修改成功！',
                    buttons: ['确认']
                });
                alert.present();
                //修改成功，重新获取刷新页面
                var param = {
                    email: localStorage.getItem("email"),
                };
                var api = '/user/info'; //后台接口
                this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    if (response.status == 200) {
                        this.user = response.data;
                        this.user.sex = response.data.sex.toString();
                        this.user["email"] = localStorage.getItem("email");
                        if (response.data.name == 0) {
                            this.user.name = "";
                        }
                        if (response.data.nickname == 0) {
                            this.user.nickname = "";
                        }
                        if (response.data.sno == 0) {
                            this.user.sno = "";
                        }
                        if (response.data.telphone == 0) {
                            this.user.telphone = "";
                        }
                    }
                }));
            }
            else if (response.data.respCode == "改手机号已被使用") {
                const toast = yield this.toast.create({
                    message: '改手机号已被使用',
                    duration: 2000
                });
                toast.present();
            }
            else if (response.data.respCode == "改昵称已被使用") {
                const toast = yield this.toast.create({
                    message: '改昵称已被使用',
                    duration: 2000
                });
                toast.present();
            }
        }));
        // }
    }
    onLogout() {
        localStorage.setItem("isLogin", "0");
        this.router.navigateByUrl('');
    }
    openPicker(numColumns = 1, numOptions, multiColumnOptions, isSchool) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (isSchool != 1 && this.user.school.length == 0) {
                const alert = yield this.alertController.create({
                    header: '警告',
                    message: '请先选择学校！',
                    buttons: ['确认']
                });
                yield alert.present();
            }
            else {
                const picker = yield this.pickerController.create({
                    columns: this.getColumns(numColumns, numOptions, multiColumnOptions, isSchool),
                    buttons: [
                        {
                            text: '取消',
                            role: 'cancel'
                        },
                        {
                            text: '确认',
                            handler: (value) => {
                                var selected = this.getColumns(numColumns, numOptions, multiColumnOptions, isSchool);
                                if (isSchool == 1) {
                                    this.flag = 1;
                                    this.academyId = selected[0].options[value.col.value].id;
                                    this.schoolChoosed = value.col.text;
                                    this.user.school = "";
                                    this.selectedSchool = selected[0].options[value.col.value].code;
                                    this.user.school += this.selectedSchool;
                                    //获取学院列表
                                    this.academy[0].length = 0;
                                    var param = {
                                        academy: this.academyId,
                                    };
                                    // console.log(param);
                                    this.academyChoosed = '未设置';
                                    var api = '/schools'; //后台接口
                                    this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                                        for (var i = 0; i < response.data.length; i++) {
                                            this.academy[0].push(response.data[i].name);
                                        }
                                        this.academyList = response.data;
                                        this.academyOptions = this.academy[0].length;
                                    }));
                                }
                                else {
                                    this.flag++; //2
                                    if (this.flag > 2) {
                                        this.flag--;
                                        this.user.school = this.selectedSchool;
                                    }
                                    if (this.user.school.length == 0) {
                                        console.log("请先选择学校");
                                    }
                                    else if (this.user.school.indexOf("/") == -1) {
                                        this.academyChoosed = value.col.text;
                                        this.selectedAcademy = selected[0].options[value.col.value].code;
                                        this.user.school += "/" + this.selectedAcademy;
                                    }
                                    else {
                                        // console.log(selected[0].options[value.col.value].code);
                                        //更新后面的学院
                                        var index = this.user.school.indexOf("/");
                                        this.user.school = this.user.school.substr(0, index);
                                        this.academyChoosed = value.col.text;
                                        this.selectedAcademy = selected[0].options[value.col.value].code;
                                        this.user.school += "/" + this.selectedAcademy;
                                    }
                                }
                                // console.log(this.user.school);
                            }
                        }
                    ]
                });
                yield picker.present();
            }
        });
    }
    getColumns(numColumns, numOptions, columnOptions, isSchool) {
        let columns = [];
        for (let i = 0; i < numColumns; i++) {
            columns.push({
                name: `col`,
                options: this.getColumnOptions(i, numOptions, columnOptions, isSchool)
            });
        }
        return columns;
    }
    getColumnOptions(columnIndex, numOptions, columnOptions, isSchool) {
        let options = [];
        for (let i = 0; i < numOptions; i++) {
            if (isSchool == 1) {
                for (let j = 0; j < this.schoolOptions; j++) {
                    if (this.schoolList[j].name == columnOptions[columnIndex][i % numOptions]) {
                        options.push({
                            text: columnOptions[columnIndex][i % numOptions],
                            value: i,
                            code: this.schoolList[j].code,
                            id: this.schoolList[j].id
                        });
                    }
                }
            }
            else {
                for (let j = 0; j < this.academyOptions; j++) {
                    if (this.academyList[j].name == columnOptions[columnIndex][i % numOptions]) {
                        options.push({
                            text: columnOptions[columnIndex][i % numOptions],
                            value: i,
                            code: this.academyList[j].code,
                            id: this.academyList[j].id
                        });
                    }
                }
            }
            // options.push({
            //   text: columnOptions[columnIndex][i % numOptions],
            //   value: i,
            // })
        }
        return options;
    }
};
UsermsgPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PickerController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"] }
];
UsermsgPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-usermsg',
        template: _raw_loader_usermsg_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_usermsg_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], UsermsgPage);



/***/ })

}]);
//# sourceMappingURL=usermsg-usermsg-module.js.map