(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["checkin-result-checkin-result-module"],{

/***/ "+3v+":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result.module.ts ***!
  \***********************************************************************/
/*! exports provided: CheckinResultPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinResultPageModule", function() { return CheckinResultPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _checkin_result_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./checkin-result-routing.module */ "+LgT");
/* harmony import */ var _checkin_result_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./checkin-result.page */ "GbYZ");







let CheckinResultPageModule = class CheckinResultPageModule {
};
CheckinResultPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _checkin_result_routing_module__WEBPACK_IMPORTED_MODULE_5__["CheckinResultPageRoutingModule"]
        ],
        declarations: [_checkin_result_page__WEBPACK_IMPORTED_MODULE_6__["CheckinResultPage"]]
    })
], CheckinResultPageModule);



/***/ }),

/***/ "+LgT":
/*!*******************************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result-routing.module.ts ***!
  \*******************************************************************************/
/*! exports provided: CheckinResultPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinResultPageRoutingModule", function() { return CheckinResultPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _checkin_result_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./checkin-result.page */ "GbYZ");




const routes = [
    {
        path: '',
        component: _checkin_result_page__WEBPACK_IMPORTED_MODULE_3__["CheckinResultPage"]
    }
];
let CheckinResultPageRoutingModule = class CheckinResultPageRoutingModule {
};
CheckinResultPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CheckinResultPageRoutingModule);



/***/ }),

/***/ "GbYZ":
/*!*********************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result.page.ts ***!
  \*********************************************************************/
/*! exports provided: CheckinResultPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckinResultPage", function() { return CheckinResultPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_checkin_result_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./checkin-result.page.html */ "uaBc");
/* harmony import */ var _checkin_result_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./checkin-result.page.scss */ "Gq5T");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");







let CheckinResultPage = class CheckinResultPage {
    constructor(actionSheetController, modalController, router, loadingController, httpService, toastController, activateInfo) {
        this.actionSheetController = actionSheetController;
        this.modalController = modalController;
        this.router = router;
        this.loadingController = loadingController;
        this.httpService = httpService;
        this.toastController = toastController;
        this.activateInfo = activateInfo;
        this.type = 0;
        this.absenceList = [];
        this.attendanceList = [];
        this.show = false;
        this.checkText = "多选";
        this.isSelectAllAbsence = false;
        this.isSelectAllAttendance = false;
        this.attendanceTotal = 0;
        this.absenceTotal = 0;
        this.api = "/attendenceResult";
        activateInfo.queryParams.subscribe(queryParams => {
            this.type = queryParams.type;
            if (queryParams.success == '1') {
                this.getData();
            }
        });
    }
    ngOnInit() {
        // this.activateInfo.queryParams.subscribe(queryParams => {
        //   this.type = queryParams.type;
        // })
        // if (this.type == 1) {
        //   this.startManual()
        // } else {
        //   this.getData();
        // }
    }
    showCheck() {
        if (this.show == false) {
            this.show = true;
            this.checkText = "取消多选";
        }
        else {
            this.show = false;
            this.checkText = "多选";
        }
    }
    selectAllAbsence() {
        this.isSelectAllAbsence = !this.isSelectAllAbsence;
        if (this.isSelectAllAbsence == true) {
            this.absenceList.forEach(item => {
                item.checked = true;
            });
            this.isSelectAllAbsence = false;
        }
        else {
            this.isSelectAllAbsence = true;
            this.absenceList.forEach(item => {
                item.checked = false;
            });
        }
    }
    checkAbsence(item) {
        let sum = 0;
        // console.log(item)
        this.absenceList.forEach(item1 => {
            if (item == item1) {
                if (item.checked == false || item.checked == undefined) {
                    sum += 1;
                }
                else {
                    this.isSelectAllAbsence = false;
                }
            }
            else {
                if (item1.checked == true) {
                    sum += 1;
                }
                else {
                    this.isSelectAllAbsence = false;
                }
            }
            // if (item1.checked == true && item1 != item) {
            //   sum += 1;
            // }
            // else if (item1.checked == false) {
            //   if (item1 == item && item.checked == false) {
            //     sum += 1;
            //   } else {
            //     this.isSelectAllAbsence = false;
            //   }
            // }
        });
        if (sum == this.absenceList.length) {
            this.isSelectAllAbsence = true;
        }
        else {
            this.isSelectAllAbsence = false;
        }
    }
    selectAllAttendance() {
        this.isSelectAllAttendance = !this.isSelectAllAttendance;
        if (this.isSelectAllAttendance == true) {
            this.attendanceList.forEach(item => {
                item.checked = true;
            });
            this.isSelectAllAttendance = false;
        }
        else {
            this.isSelectAllAttendance = true;
            this.attendanceList.forEach(item => {
                item.checked = false;
            });
        }
    }
    checkAttendance(item) {
        let sum = 0;
        this.attendanceList.forEach(item1 => {
            if (item == item1) {
                if (item.checked == false || item.checked == undefined) {
                    sum += 1;
                }
                else {
                    this.isSelectAllAttendance = false;
                }
            }
            else {
                if (item1.checked == true) {
                    sum += 1;
                }
                else {
                    this.isSelectAllAttendance = false;
                }
                // if (item1.checked == true && item1 != item) {
                //   sum += 1;
                // }
                // else if (item1.checked == false) {
                //   if (item1 == item && item.checked == false) {
                //     sum += 1;
                //   } else {
                //     this.isSelectAllAttendance = false;
                //   }
            }
        });
        if (sum == this.attendanceList.length) {
            this.isSelectAllAttendance = true;
        }
        else {
            this.isSelectAllAttendance = false;
        }
    }
    presentActionSheet(item) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: '设置',
                cssClass: 'my-custom-class',
                buttons: [{
                        text: '设为缺勤',
                        role: 'destructive',
                        icon: 'heart-dislike-outline',
                        handler: () => {
                            this.setState(item, 2);
                        }
                    }, {
                        text: '设为请假',
                        icon: 'mail-outline',
                        handler: () => {
                            this.setState(item, 1);
                        }
                    },
                    {
                        text: '设为已签到',
                        icon: 'heart-outline',
                        handler: () => {
                            this.setState(item, 0);
                        }
                    }, {
                        text: '取消',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                            // console.log('Cancel clicked');
                        }
                    }]
            });
            yield actionSheet.present();
        });
    }
    getData() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            var params = {
                code: localStorage.getItem("lesson_no"),
                attend_id: localStorage.getItem("attend_id")
            };
            this.httpService.patch(this.api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                this.absenceList = response.data[0];
                this.absenceTotal = response.data[0][response.data[0].length - 1].total;
                this.absenceList.splice(this.absenceList.length - 1);
                this.attendanceList = response.data[1];
                this.attendanceTotal = response.data[1][response.data[1].length - 1].total;
                this.attendanceList.splice(this.attendanceList.length - 1);
            }));
            this.show = false;
            this.checkText = "多选";
        });
    }
    presentToast(str) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: str,
                duration: 2000
            });
            toast.present();
        });
    }
    setState(i, type) {
        var data = [];
        if (this.show == true) {
            this.absenceList.forEach(item => {
                if (item.checked == true) {
                    var params = {
                        student_email: item.email,
                        code: localStorage.getItem("lesson_no"),
                        attend_id: localStorage.getItem("attend_id"),
                        type: type
                    };
                    data.push(params);
                }
            });
            this.attendanceList.forEach(item => {
                if (item.checked == true) {
                    var params = {
                        student_email: item.email,
                        code: localStorage.getItem("lesson_no"),
                        attend_id: localStorage.getItem("attend_id"),
                        type: type
                    };
                    data.push(params);
                }
            });
        }
        else {
            var params = {
                student_email: i.email,
                code: localStorage.getItem("lesson_no"),
                attend_id: localStorage.getItem("attend_id"),
                type: type
            };
            data.push(params);
            // console.log("999")
        }
        // if (data.length==0) {
        //   this.presentToast("请至少选中一条数据");
        // } else {
        var api = "/attendenceResult/change";
        this.httpService.put(api, data).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // console.log(response.data)
            if (response.data.respCode == "1") {
                this.presentToast("状态修改成功！");
            }
            else {
                this.presentToast(response.data);
            }
        }));
        this.getData();
        // }
    }
    setAllState() {
        var sum = 0;
        this.absenceList.forEach(item => {
            if (item.checked == true) {
                sum += 1;
            }
        });
        this.attendanceList.forEach(item => {
            if (item.checked == true) {
                sum += 1;
            }
        });
        if (this.isSelectAllAttendance == true || this.isSelectAllAbsence == true || sum > 0) {
            this.presentActionSheet([]);
        }
        else {
            this.presentToast("请至少选中一条数据");
        }
    }
    goback() {
        // this.router.navigate(['/choose'], {
        //   queryParams: {
        //     flush: '1'
        //   }
        // })
    }
    startManual() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...',
            });
            yield loading.present();
            var params = {
                code: localStorage.getItem("lesson_no")
            };
            var api = "/attendence/hand";
            this.httpService.put(api, params).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                yield loading.dismiss();
                localStorage.setItem("attend_id", response.data);
                this.getData();
            }));
        });
    }
};
CheckinResultPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ActionSheetController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_6__["HttpService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"] }
];
CheckinResultPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-checkin-result',
        template: _raw_loader_checkin_result_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_checkin_result_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CheckinResultPage);



/***/ }),

/***/ "Gq5T":
/*!***********************************************************************!*\
  !*** ./src/app/pages/checkin/checkin-result/checkin-result.page.scss ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".row-text {\n  background: #80808026;\n  width: 100%;\n  height: 40px;\n}\n\n.row-label {\n  margin: 10px 0px 0px 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY2hlY2tpbi1yZXN1bHQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0kscUJBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0kseUJBQUE7QUFDSiIsImZpbGUiOiJjaGVja2luLXJlc3VsdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucm93LXRleHQge1xyXG4gICAgYmFja2dyb3VuZDogIzgwODA4MDI2O1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbn1cclxuXHJcbi5yb3ctbGFiZWwge1xyXG4gICAgbWFyZ2luOiAxMHB4IDBweCAwcHggMTBweDtcclxufSJdfQ== */");

/***/ }),

/***/ "uaBc":
/*!*************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/checkin/checkin-result/checkin-result.page.html ***!
  \*************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" (click)=\"goback()\" [routerLink]=\"['/checkin/course-checkin']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center\">签到结果</ion-title>\r\n      <ion-buttons slot=\"end\">\r\n          <ion-button color=\"medium\" (click)=\"showCheck()\">{{checkText}}</ion-button>\r\n      </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <!-- <ion-item-divider>\r\n      <ion-searchbar style=\"width: 80%;float: left;\"></ion-searchbar>\r\n      <ion-button style=\"margin: 10px 0 0 10px;float:left;width: 15%;\">搜索</ion-button>\r\n  </ion-item-divider> -->\r\n  <ion-item-divider class=\"row-text\">\r\n      <ion-label>缺勤列表</ion-label>\r\n      <ion-note slot=\"end\" color=\"tertiary\" style=\"padding: 10px 0 0 0;font-size: 15px;margin-right: 10px;\">{{absenceTotal}}人</ion-note>\r\n      <ion-checkbox slot=\"end\" color=\"primary\" (click)=\"selectAllAbsence()\" [(ngModel)]=\"isSelectAllAbsence\" *ngIf=\"show==true&&absenceTotal!=0\" style=\"margin-left:0px;margin-right: 17px;\"></ion-checkbox>\r\n  </ion-item-divider>\r\n  <ion-list can-swipe=\"listCanSwipe\">\r\n      <!-- <ion-item-sliding > -->\r\n      <ion-item *ngFor=\"let item of absenceList\">\r\n          <ion-avatar slot=\"start\" (click)=\"presentActionSheet(item)\">\r\n              <img src=\"../../../../assets/icon/person.png\">\r\n          </ion-avatar>\r\n          <ion-label (click)=\"presentActionSheet(item)\">\r\n              <h2>{{item.name}}</h2>\r\n              <h3>{{item.sno}}</h3>\r\n          </ion-label>\r\n          <ion-note slot=\"end\" color=\"danger\" style=\"font-size: 15px;margin-top: 4px;\" (click)=\"presentActionSheet(item)\">{{item.type}}</ion-note>\r\n          <ion-checkbox slot=\"end\" color=\"primary\" (click)=\"checkAbsence(item)\" *ngIf=\"show==true\" style=\"margin-left:10px\" [(ngModel)]=\"item.checked\" [id]=\"item.id\"></ion-checkbox>\r\n      </ion-item>\r\n\r\n  </ion-list>\r\n\r\n  <ion-item-divider class=\"row-text\">\r\n      <ion-label>出勤列表</ion-label>\r\n      <ion-note slot=\"end\" color=\"tertiary\" style=\"padding: 10px 0 0 0;font-size: 15px;margin-right: 10px;\">{{attendanceTotal}}人</ion-note>\r\n      <ion-checkbox slot=\"end\" color=\"primary\" (click)=\"selectAllAttendance()\" [(ngModel)]=\"isSelectAllAttendance\" *ngIf=\"show==true&&attendanceTotal!=0\" style=\"margin-left:0px;margin-right: 17px;\"></ion-checkbox>\r\n  </ion-item-divider>\r\n  <ion-list can-swipe=\"listCanSwipe\">\r\n      <!-- <ion-item-sliding > -->\r\n      <ion-item *ngFor=\"let item of attendanceList\">\r\n          <ion-avatar slot=\"start\" (click)=\"presentActionSheet(item)\">\r\n              <img src=\"../../../../assets/icon/person.png\">\r\n          </ion-avatar>\r\n          <ion-label (click)=\"presentActionSheet(item)\">\r\n              <h2>{{item.name}}</h2>\r\n              <h3>{{item.sno}}</h3>\r\n          </ion-label>\r\n          <!-- <ion-note slot=\"end\" color=\"danger\" style=\"font-size: 15px;margin-top: 4px;\" (click)=\"presentActionSheet(item)\">缺勤</ion-note> -->\r\n          <ion-checkbox slot=\"end\" color=\"primary\" (click)=\"checkAttendance(item)\" *ngIf=\"show==true\" style=\"margin-left:10px\" [(ngModel)]=\"item.checked\" [id]=\"item.id\"></ion-checkbox>\r\n      </ion-item>\r\n\r\n  </ion-list>\r\n\r\n</ion-content>\r\n<ion-footer *ngIf=\"show==true\">\r\n  <p style=\"color: #3685d8;text-align: center;\" (click)=\"setAllState()\">设置状态</p>\r\n</ion-footer>");

/***/ })

}]);
//# sourceMappingURL=checkin-result-checkin-result-module.js.map