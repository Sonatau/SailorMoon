(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["create-course-create-course-module"],{

/***/ "4nSL":
/*!********************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course.module.ts ***!
  \********************************************************************/
/*! exports provided: CreateCoursePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCoursePageModule", function() { return CreateCoursePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "ofXK");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "3Pt+");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var _create_course_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./create-course-routing.module */ "sfRM");
/* harmony import */ var _create_course_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./create-course.page */ "c2xb");







let CreateCoursePageModule = class CreateCoursePageModule {
};
CreateCoursePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _create_course_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreateCoursePageRoutingModule"]
        ],
        declarations: [_create_course_page__WEBPACK_IMPORTED_MODULE_6__["CreateCoursePage"]]
    })
], CreateCoursePageModule);



/***/ }),

/***/ "KEsy":
/*!********************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course.page.scss ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".add_img {\n  width: 50px;\n  height: 50px;\n}\n\n.show_cover {\n  width: 100%;\n  height: 40%;\n}\n\n.cover {\n  margin: auto;\n  line-height: 85px;\n  font-size: 30px;\n  width: 85px;\n  height: 85px;\n  border-radius: 8px;\n}\n\n.icon {\n  width: 80%;\n  height: 100%;\n}\n\n.my_textarea {\n  width: 90%;\n  height: 100px;\n  overflow: visible;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uXFwuLlxcLi5cXC4uXFwuLlxcY3JlYXRlLWNvdXJzZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsWUFBQTtBQUNKOztBQUVBO0VBQ0ksV0FBQTtFQUNBLFdBQUE7QUFDSjs7QUFDQTtFQUNJLFlBQUE7RUFDQSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBRUo7O0FBQ0E7RUFDSSxVQUFBO0VBQ0EsWUFBQTtBQUVKOztBQUNBO0VBQ0ksVUFBQTtFQUNBLGFBQUE7RUFDQSxpQkFBQTtBQUVKIiwiZmlsZSI6ImNyZWF0ZS1jb3Vyc2UucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmFkZF9pbWd7XHJcbiAgICB3aWR0aDo1MHB4O1xyXG4gICAgaGVpZ2h0OiA1MHB4O1xyXG59XHJcblxyXG4uc2hvd19jb3ZlcntcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiA0MCU7XHJcbn1cclxuLmNvdmVye1xyXG4gICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgbGluZS1oZWlnaHQ6IDg1cHg7XHJcbiAgICBmb250LXNpemU6IDMwcHg7XHJcbiAgICB3aWR0aDogODVweDtcclxuICAgIGhlaWdodDogODVweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDhweDtcclxufVxyXG5cclxuLmljb257XHJcbiAgICB3aWR0aDogODAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG59XHJcblxyXG4ubXlfdGV4dGFyZWF7XHJcbiAgICB3aWR0aDogOTAlO1xyXG4gICAgaGVpZ2h0OiAxMDBweDtcclxuICAgIG92ZXJmbG93OiB2aXNpYmxlO1xyXG59Il19 */");

/***/ }),

/***/ "c2xb":
/*!******************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course.page.ts ***!
  \******************************************************************/
/*! exports provided: CreateCoursePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCoursePage", function() { return CreateCoursePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _raw_loader_create_course_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! raw-loader!./create-course.page.html */ "ovBZ");
/* harmony import */ var _create_course_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./create-course.page.scss */ "KEsy");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "tk/3");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "TEn/");
/* harmony import */ var src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/shared/services/http.service */ "Tdnt");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "a/9d");
/* harmony import */ var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ionic-native/image-picker/ngx */ "tAfe");










let CreateCoursePage = class CreateCoursePage {
    constructor(router, activatedRoute, actionSheetCtrl, camera, imagePicker, httpService, http, alertController, toastController, pickerController, platform) {
        this.router = router;
        this.activatedRoute = activatedRoute;
        this.actionSheetCtrl = actionSheetCtrl;
        this.camera = camera;
        this.imagePicker = imagePicker;
        this.httpService = httpService;
        this.http = http;
        this.alertController = alertController;
        this.toastController = toastController;
        this.pickerController = pickerController;
        this.platform = platform;
        this.course_cover = "image_null";
        this.schoolList = {
            total: 0,
            schools: []
        };
        this.academyList = {
            total: 0,
            academies: []
        };
        this.majorList = {
            total: 0,
            majors: []
        };
        this.schoolChoosed = {
            name: "请选择",
            id: -1
        };
        this.academyChoosed = {
            name: "请选择",
            id: -1
        };
        this.majorChoosed = {
            name: "请选择",
            id: -1
        };
    }
    ngOnInit() { }
    ionViewWillEnter() {
        this.setSchoolList();
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //------------------------------------------------请求学校/学院/专业列表------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    openPicker(type) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (type == 2 && this.schoolChoosed.id == -1) {
                const alert = yield this.alertController.create({
                    header: '警告',
                    message: '请先选择学校！',
                    buttons: ['确认']
                });
                yield alert.present();
            }
            else if (type == 3 && this.academyChoosed.id == -1) {
                const alert = yield this.alertController.create({
                    header: '警告',
                    message: '请先选择院系！',
                    buttons: ['确认']
                });
                yield alert.present();
            }
            else {
                const picker = yield this.pickerController.create({
                    columns: this.getColumns(type),
                    buttons: [
                        {
                            text: '取消',
                            role: 'cancel'
                        },
                        {
                            text: '确认',
                            handler: (value) => {
                                var selected = this.getColumns(type);
                                //console.log(value);
                                if (type == 1) {
                                    this.schoolChoosed.name = selected[0].options[value.daoyun108.value].text;
                                    this.schoolChoosed.id = selected[0].options[value.daoyun108.value].id;
                                    this.setNextOptions(type);
                                }
                                else if (type == 2) {
                                    this.academyChoosed.name = selected[0].options[value.daoyun108.value].text;
                                    this.academyChoosed.id = selected[0].options[value.daoyun108.value].id;
                                    this.setNextOptions(type);
                                }
                                else {
                                    this.majorChoosed.name = selected[0].options[value.daoyun108.value].text;
                                    this.majorChoosed.id = selected[0].options[value.daoyun108.value].id;
                                }
                            }
                        }
                    ]
                });
                yield picker.present();
            }
        });
    }
    getColumns(type) {
        let options = [];
        if (type == 1) {
            for (let i = 0; i < this.schoolList.total; i++) {
                options.push({
                    text: this.schoolList.schools[i].schoolName,
                    id: this.schoolList.schools[i].schoolId,
                    value: i
                });
            }
        }
        else if (type == 2) {
            for (let i = 0; i < this.academyList.total; i++) {
                options.push({
                    text: this.academyList.academies[i].academyName,
                    id: this.academyList.academies[i].academyId,
                    value: i
                });
            }
        }
        else {
            for (let i = 0; i < this.majorList.total; i++) {
                options.push({
                    text: this.majorList.majors[i].majorName,
                    id: this.majorList.majors[i].majorId,
                    value: i
                });
            }
        }
        let columns = [];
        columns.push({
            name: `daoyun108`,
            options: options
        });
        //console.log(options);
        return columns;
    }
    setNextOptions(type) {
        if (type == 1) {
            this.academyList.academies = [];
            this.academyList.total = 0;
            this.academyChoosed = {
                name: "请选择",
                id: -1
            };
            this.setAcademyList();
        }
        this.majorList.majors = [];
        this.majorList.total = 0;
        this.majorChoosed = {
            name: "请选择",
            id: -1
        };
        if (type == 2) {
            this.setMajorList();
        }
    }
    setSchoolList() {
        var param = {
            page: 1
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.schoolList.schools.push({
                    schoolId: response.data.data.list[i].id,
                    schoolName: response.data.data.list[i].name
                });
            }
            this.schoolList.total = response.data.data.total;
            //console.log(this.schoolList);
        }));
    }
    setAcademyList() {
        var param = {
            page: 1,
            parentId: this.schoolChoosed.id
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.academyList.academies.push({
                    academyId: response.data.data.list[i].id,
                    academyName: response.data.data.list[i].name
                });
            }
            this.academyList.total = response.data.data.total;
        }));
    }
    setMajorList() {
        var param = {
            page: 1,
            parentId: this.academyChoosed.id
        };
        var api = '/school';
        this.httpService.get(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            //console.log(response);
            for (let i = 0; i < response.data.data.total; i++) {
                this.majorList.majors.push({
                    majorId: response.data.data.list[i].id,
                    majorName: response.data.data.list[i].name
                });
            }
            this.majorList.total = response.data.data.total;
        }));
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //-----------------------------------------------------上传课程封面-----------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    /**
     * 上传图片
     * @returns {Promise<void>}
     */
    onPresentActiveSheet() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetCtrl.create({
                header: '选择您的操作',
                buttons: [
                    {
                        text: '拍照',
                        role: 'destructive',
                        handler: () => {
                            console.log('进入相机');
                            this.onCamera();
                        }
                    }, {
                        text: '相册',
                        handler: () => {
                            console.log('进入相册');
                            this.onImagePicker();
                        }
                    }, {
                        text: '取消',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    /**
     * 拍照
     */
    onCamera() {
        const options = {
            quality: 10,
            destinationType: this.camera.DestinationType.DATA_URL,
            encodingType: this.camera.EncodingType.JPEG,
            mediaType: this.camera.MediaType.PICTURE
        };
        this.camera.getPicture(options).then((imageData) => {
            this.course_cover = 'data:image/jpeg;base64,' + imageData;
        }, (err) => {
        });
    }
    /**
     * 相册
     */
    onImagePicker() {
        const options = {
            maximumImagesCount: 1,
            quality: 10,
            outputType: 1
        };
        console.log('in imagePicker');
        this.imagePicker.getPictures(options).then((results) => {
            for (let i = 0; i < results.length; i++) {
                //console.log('Image URI: ' + results[i]);
                this.course_cover = 'data:image/jpeg;base64,' + results[i];
            }
        }, (err) => { console.log(err); });
    }
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    //-------------------------------------------------------创建课程------------------------------------------------------------//
    //---------------------------------------------------------------------------------------------------------------------------//
    onCreate(form) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (form.valid) {
                if (this.schoolChoosed.id == -1 || this.academyChoosed.id == -1 || this.majorChoosed.id == -1) {
                    let toast = yield this.toastController.create({
                        message: '请选择学校、学院、专业！',
                        duration: 2000
                    });
                    toast.present();
                }
                else {
                    var param = {
                        image: this.course_cover,
                        name: this.course_name,
                        schoolId: this.schoolChoosed.id,
                        acadeId: this.academyChoosed.id,
                        majorId: this.majorChoosed.id
                    };
                    console.log(param);
                    var api = '/course';
                    this.httpService.post(api, param).then((response) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                        console.log(response);
                        this.course_code = response.data.data.code;
                        console.log(this.course_name);
                        const alert = yield this.alertController.create({
                            message: '课程创建成功！',
                            buttons: [
                                {
                                    text: '确认',
                                    cssClass: 'secondary',
                                    handler: (blah) => {
                                        this.router.navigate(['/course/create-success'], { queryParams: { code: this.course_code } });
                                    }
                                }
                            ]
                        });
                        yield alert.present();
                    }));
                }
            }
        });
    }
};
CreateCoursePage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ActionSheetController"] },
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__["Camera"] },
    { type: _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_9__["ImagePicker"] },
    { type: src_app_shared_services_http_service__WEBPACK_IMPORTED_MODULE_7__["HttpService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["PickerController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["Platform"] }
];
CreateCoursePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Component"])({
        selector: 'app-create-course',
        template: _raw_loader_create_course_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_create_course_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
    })
], CreateCoursePage);



/***/ }),

/***/ "ovBZ":
/*!**********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/course/create-course/create-course.page.html ***!
  \**********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n      <ion-buttons slot=\"start\">\r\n          <ion-button color=\"medium\" expand=\"block\" fill=\"clear\" shape=\"round\" [routerLink]=\"['/tabs/course']\">\r\n              <ion-icon slot=\"start\" name=\"chevron-back-outline\"></ion-icon>\r\n          </ion-button>\r\n      </ion-buttons>\r\n      <ion-title style=\"text-align:center;margin-right: 30px;\">创建课程</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form (ngSubmit)=\"onCreate(createForm)\" #createForm=\"ngForm\" novalidate>\r\n      <ion-list lines=\"full\">\r\n\r\n        <ion-item-divider color=\"light\">\r\n          <ion-thumbnail *ngif=\"course_cover != image_null\">\r\n            <img src={{course_cover}}>\r\n          </ion-thumbnail>\r\n          <ion-thumbnail slot=\"end\" (click)=\"onPresentActiveSheet()\">\r\n            <img src=\"assets/img/course/add.png\">\r\n          </ion-thumbnail>\r\n        </ion-item-divider>\r\n\r\n        <ion-item>\r\n          <ion-label slot=\"start\">课程名称</ion-label>\r\n          <ion-input name=\"name\" type=\"text\" class=\"my_inf\" slot=\"end\"\r\n            placeholder=\"未设置\" [(ngModel)]=\"course_name\" #name=\"ngModel\" required>\r\n          </ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(1)\">\r\n          <ion-label slot=\"start\">开设学校</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{schoolChoosed.name}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(2)\">\r\n          <ion-label slot=\"start\">开设学院</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{academyChoosed.name}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-item (click)=\"openPicker(3)\">\r\n          <ion-label slot=\"start\">开设专业</ion-label>\r\n          <ion-note class=\"my_inf\" slot=\"end\">{{majorChoosed.name}}</ion-note>\r\n        </ion-item>\r\n\r\n        <ion-row style=\"margin: top 30px;\" class=\"row\">\r\n          <ion-button color=\"primary\" type=\"submit\" class=\"btn\"\r\n          [disabled]=\"createForm.invalid\"> 创建课程 </ion-button>\r\n        </ion-row>\r\n      </ion-list>\r\n  </form>\r\n\r\n</ion-content>");

/***/ }),

/***/ "sfRM":
/*!****************************************************************************!*\
  !*** ./src/app/pages/course/create-course/create-course-routing.module.ts ***!
  \****************************************************************************/
/*! exports provided: CreateCoursePageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateCoursePageRoutingModule", function() { return CreateCoursePageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "mrSG");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "fXoL");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "tyNb");
/* harmony import */ var _create_course_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./create-course.page */ "c2xb");




const routes = [
    {
        path: '',
        component: _create_course_page__WEBPACK_IMPORTED_MODULE_3__["CreateCoursePage"]
    }
];
let CreateCoursePageRoutingModule = class CreateCoursePageRoutingModule {
};
CreateCoursePageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreateCoursePageRoutingModule);



/***/ })

}]);
//# sourceMappingURL=create-course-create-course-module.js.map